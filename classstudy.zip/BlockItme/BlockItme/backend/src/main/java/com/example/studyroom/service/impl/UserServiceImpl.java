package com.example.studyroom.service.impl;

import com.example.studyroom.model.User;
import com.example.studyroom.repository.UserRepository;
import com.example.studyroom.service.UserService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAllActiveUsers();
    }

    @Override
    public Optional<User> getUserById(@NonNull Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.filter(u -> !u.getDeleted());
    }

    @Override
    public Optional<User> getUserByUserId(@NonNull String userId) {
        return userRepository.findByUserIdAndDeleted(userId, false);
    }

    @Override
    public Optional<User> getUserByWalletAddress(@NonNull String walletAddress) {
        return userRepository.findByWalletAddressAndDeleted(walletAddress, false);
    }

    @Override
    public Optional<User> getUserByStudentId(@NonNull String studentId) {
        return userRepository.findByStudentIdAndDeleted(studentId, false);
    }

    @Override
    public boolean existsByStudentId(@NonNull String studentId) {
        return userRepository.existsByStudentIdAndDeleted(studentId, false);
    }

    @Override
    public User createUser(@NonNull User user) {
        user.setCreatedAt(LocalDateTime.now());
        user.setDeleted(false);
        // 设置默认状态为enabled
        if (user.getStatus() == null) {
            user.setStatus(User.Status.enabled);
        }
        // 确保role字段不为空
        if (user.getRole() == null) {
            // 默认角色为student
            user.setRole(User.Role.student);
        }
        return userRepository.save(user);
    }

    @Override
    public User updateUser(@NonNull Long id, @NonNull User user) {
        Optional<User> existingUser = userRepository.findById(id);
        if (existingUser.isPresent()) {
            User updatedUser = existingUser.get();
            if (updatedUser.getDeleted()) {
                throw new RuntimeException("User is deleted");
            }
            updatedUser.setUserId(user.getUserId());
            updatedUser.setPassword(user.getPassword());
            updatedUser.setWalletAddress(user.getWalletAddress());
            updatedUser.setRole(user.getRole());
            updatedUser.setName(user.getName());
            updatedUser.setStudentId(user.getStudentId());
            updatedUser.setEmail(user.getEmail());
            updatedUser.setPhone(user.getPhone());
            updatedUser.setStatus(user.getStatus());
            updatedUser.setUpdatedAt(LocalDateTime.now());
            return userRepository.save(updatedUser);
        }
        throw new RuntimeException("User not found with id: " + id);
    }

    @Override
    public User patchUser(@NonNull Long id, @NonNull User user) {
        Optional<User> existingUser = userRepository.findById(id);
        if (existingUser.isPresent()) {
            User updatedUser = existingUser.get();
            if (updatedUser.getDeleted()) {
                throw new RuntimeException("User is deleted");
            }
            // 只更新非null的字段
            if (user.getUserId() != null) {
                updatedUser.setUserId(user.getUserId());
            }
            if (user.getPassword() != null) {
                updatedUser.setPassword(user.getPassword());
            }
            if (user.getWalletAddress() != null) {
                updatedUser.setWalletAddress(user.getWalletAddress());
            }
            if (user.getRole() != null) {
                updatedUser.setRole(user.getRole());
            }
            if (user.getName() != null) {
                updatedUser.setName(user.getName());
            }
            if (user.getStudentId() != null) {
                updatedUser.setStudentId(user.getStudentId());
            }
            if (user.getEmail() != null) {
                updatedUser.setEmail(user.getEmail());
            }
            if (user.getPhone() != null) {
                updatedUser.setPhone(user.getPhone());
            }
            if (user.getStatus() != null) {
                updatedUser.setStatus(user.getStatus());
            }
            updatedUser.setUpdatedAt(LocalDateTime.now());
            return userRepository.save(updatedUser);
        }
        throw new RuntimeException("User not found with id: " + id);
    }

    @Override
    public void deleteUser(@NonNull Long id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            User existingUser = user.get();
            existingUser.setDeleted(true);
            existingUser.setUpdatedAt(LocalDateTime.now());
            userRepository.save(existingUser);
        }
    }

    @Override
    public boolean existsByUserId(@NonNull String userId) {
        return userRepository.existsByUserIdAndDeleted(userId, false);
    }

    @Override
    public boolean existsByWalletAddress(@NonNull String walletAddress) {
        return userRepository.existsByWalletAddressAndDeleted(walletAddress, false);
    }

    @Override
    public boolean existsByEmail(@NonNull String email) {
        return userRepository.existsByEmailAndDeleted(email, false);
    }

    @Override
    public boolean existsByPhone(@NonNull String phone) {
        return userRepository.existsByPhoneAndDeleted(phone, false);
    }

    @Override
    public long getUsersCountByRole(@NonNull User.Role role) {
        return userRepository.countByRoleAndDeleted(role);
    }

    @Override
    public Optional<User> login(String userId, String password, String role) {
        Optional<User> optionalUser = userRepository.findByUserIdAndDeleted(userId, false);
        
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // 验证密码和角色
            if (user.getPassword().equals(password) && user.getRole().name().equals(role)) {
                return Optional.of(user);
            }
        }
        
        return Optional.empty();
    }

    @Override
    public User rechargeUser(Long id, Double amount) {
        if (amount == null || amount <= 0) {
            throw new IllegalArgumentException("充值金额必须为正数");
        }
        
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("用户不存在");
        }
        
        User user = optionalUser.get();
        if (user.getDeleted()) {
            throw new RuntimeException("用户已被删除");
        }
        
        // 更新余额 - 使用BigDecimal进行精确计算
        java.math.BigDecimal currentBalance = user.getBalance() != null ? user.getBalance() : java.math.BigDecimal.ZERO;
        java.math.BigDecimal rechargeAmount = java.math.BigDecimal.valueOf(amount);
        user.setBalance(currentBalance.add(rechargeAmount));
        user.setUpdatedAt(LocalDateTime.now());
        
        return userRepository.save(user);
    }
}