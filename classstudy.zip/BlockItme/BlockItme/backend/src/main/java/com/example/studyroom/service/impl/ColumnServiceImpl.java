package com.example.studyroom.service.impl;

import com.example.studyroom.model.SeatColumn;
import com.example.studyroom.repository.ColumnRepository;
import com.example.studyroom.service.ColumnService;
import com.example.studyroom.repository.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import lombok.AllArgsConstructor;
import lombok.NonNull;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ColumnServiceImpl implements ColumnService {

    private final ColumnRepository columnRepository;
    private final SeatRepository seatRepository;

    @Override
    public List<SeatColumn> getAllColumns() {
        return columnRepository.findAll();
    }

    @Override
    public Page<SeatColumn> getAllColumns(@NonNull Pageable pageable) {
        return columnRepository.findAll(pageable);
    }

    @Override
    public Optional<SeatColumn> getColumnById(@NonNull Long id) {
        return columnRepository.findById(id);
    }

    @Override
    public Optional<SeatColumn> getColumnByColumnNumber(@NonNull Integer columnNumber) {
        return columnRepository.findByColumnNumber(columnNumber);
    }

    @Override
    public SeatColumn saveColumn(@NonNull SeatColumn column) {
        return columnRepository.save(column);
    }

    @Override
    @Transactional
    public void deleteColumn(@NonNull Long id) {
        // 首先获取列信息
        Optional<SeatColumn> columnOptional = columnRepository.findById(id);
        if (columnOptional.isPresent()) {
            SeatColumn column = columnOptional.get();
            // 删除该列对应的所有座位
            seatRepository.deleteByColumn(column.getColumnNumber());
            // 然后删除列
            columnRepository.deleteById(id);
        }
    }

    @Override
    public boolean existsByColumnNumber(@NonNull Integer columnNumber) {
        return columnRepository.existsByColumnNumber(columnNumber);
    }
}