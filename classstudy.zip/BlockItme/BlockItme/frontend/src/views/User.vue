<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>欢迎回来</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 用户欢迎区域 -->
      <section class="welcome-section">
        <div class="welcome-card">
          <h2>您好，{{ userStore.userInfo?.name || '用户' }}！</h2>
          <p>欢迎使用区块链自习室管理系统</p>
          <div class="welcome-actions">
            <button class="primary-btn" @click="router.push('/user/seats')">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="3" y="3" width="7" height="9" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <rect x="14" y="3" width="7" height="5" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <rect x="14" y="12" width="7" height="9" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <rect x="3" y="16" width="7" height="5" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              立即预约座位
            </button>
            <button class="secondary-btn" @click="router.push('/user/reservations')">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              查看预约记录
            </button>
          </div>
        </div>
      </section>

      <!-- 统计卡片区域 -->
      <section class="stats-cards">
        <div class="stat-card">
          <div class="card-icon available-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <polyline points="22 4 12 14.01 9 11.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>可用座位</h3>
            <p class="stat-value">{{ availableSeatsCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon reserved-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>我的预约</h3>
            <p class="stat-value">3</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon active-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M12 8v4l3 3" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>当前在馆</h3>
            <p class="stat-value">{{ usedSeatsCount }}</p>
          </div>
        </div>

      </section>

      <!-- 图表和数据区域 -->
      <section class="charts-section">
        <div class="chart-card">
          <h2>座位使用情况</h2>
          <div class="chart-container" ref="seatsChartRef" style="width: 100%; height: 300px;"></div>
        </div>
        <div class="chart-card">
          <h2>我的最近预约</h2>
          <div class="recent-reservations">
            <table class="reservations-table">
              <thead>
                <tr>
                  <th>预约ID</th>
                  <th>座位号</th>
                  <th>预约时间</th>
                  <th class="status-column">状态</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="userRecentReservations.length === 0">
                  <td colspan="4" style="text-align: center; color: #999;">暂无预约记录</td>
                </tr>
                <tr v-for="reservation in userRecentReservations" :key="reservation.id">
                  <td>{{ reservation.id }}</td>
                  <td>{{ reservation.seatNumber }}</td>
                  <td>{{ formatDateTime(reservation.startTime) }}</td>
                  <td class="status-column"><span class="status" :class="getStatusClass(reservation.status)">{{ getStatusText(reservation.status) }}</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'
import api, { getUsedSeatsCount, getUserRecentReservations, getSeatsStatusDistribution } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)
const availableSeatsCount = ref(85) // 默认值为85，页面加载后会从API获取实际数据
const usedSeatsCount = ref(42) // 默认值为42，页面加载后会从API获取实际数据
const userRecentReservations = ref([]) // 存储用户最近预约记录
const userBalance = ref('0.00') // 用户余额
const seatsChartRef = ref(null) // 座位状态饼图引用
const seatsStatusData = ref({ available: 0, reserved: 0, used: 0 }) // 座位状态数据

// 获取可用座位数量
const fetchAvailableSeatsCount = async () => {
  try {
    const count = await api.get('/seats/count/status/available')
    availableSeatsCount.value = count
  } catch (error) {
    console.error('获取可用座位数量失败:', error)
    // 失败时保持默认值
  }
}

// 获取已占用座位数量
const fetchUsedSeatsCount = async () => {
  try {
    const count = await getUsedSeatsCount()
    usedSeatsCount.value = count
  } catch (error) {
    console.error('获取已占用座位数量失败:', error)
    // 失败时保持默认值
  }
}

// 获取用户最近预约记录
const fetchUserRecentReservations = async () => {
  try {
    const userId = userStore.userInfo?.userId
    if (userId) {
      const reservations = await getUserRecentReservations(userId)
      userRecentReservations.value = reservations
    }
  } catch (error) {
    console.error('获取用户最近预约记录失败:', error)
    // 失败时保持空数组
  }
}

// 获取用户余额
const fetchUserBalance = async () => {
  try {
    const userId = userStore.userInfo?.userId
    if (userId) {
      const response = await api.get(`/users/user-id/${userId}`)
      userBalance.value = response.balance || '0.00'
    }
  } catch (error) {
    console.error('获取用户余额失败:', error)
    // 失败时保持默认值
  }
}

// 获取座位状态分布
const fetchSeatsStatusDistribution = async () => {
  try {
    const distribution = await getSeatsStatusDistribution()
    seatsStatusData.value = distribution
    updateSeatsChart()
  } catch (error) {
    console.error('获取座位状态分布失败:', error)
  }
}

// 更新座位状态饼图
const updateSeatsChart = () => {
  if (!seatsChartRef.value) return
  
  const chart = echarts.init(seatsChartRef.value)
  
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      left: 10,
      data: ['空闲', '已预约', '已使用']
    },
    series: [
      {
        name: '座位状态',
        type: 'pie',
        radius: ['50%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: '18',
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data: [
          { value: seatsStatusData.value.available, name: '空闲', itemStyle: { color: '#52c41a' } },
          { value: seatsStatusData.value.reserved, name: '已预约', itemStyle: { color: '#faad14' } },
          { value: seatsStatusData.value.used, name: '已使用', itemStyle: { color: '#f5222d' } }
        ]
      }
    ]
  }
  
  chart.setOption(option)
  
  // 响应式调整
  window.addEventListener('resize', () => {
    chart.resize()
  })
}

// 组件挂载时获取数据
onMounted(() => {
  fetchAvailableSeatsCount()
  fetchUsedSeatsCount()
  fetchUserRecentReservations()
  fetchUserBalance()
  fetchSeatsStatusDistribution()
})

// 格式化日期时间
const formatDateTime = (dateTime) => {
  if (!dateTime) return ''
  const date = new Date(dateTime)
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  return `${year}-${month}-${day} ${hours}:${minutes}`
}

// 获取状态对应的CSS类
const getStatusClass = (status) => {
  const statusMap = {
    'checked_in': 'active',
    'reserved': 'reserved',
    'completed': 'completed',
    'cancelled': 'cancelled',
    'violated': 'cancelled'
  }
  return statusMap[status] || 'reserved'
}

// 获取状态文本
const getStatusText = (status) => {
  const statusTextMap = {
    'pending': '待确认',
    'reserved': '已预约',
    'confirmed': '已确认',
    'checked_in': '已签到',
    'completed': '已完成',
    'cancelled': '已取消',
    'violated': '已违约',
    'late': '迟到'
  }
  return statusTextMap[status] || status || '未知'
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

/* 用户欢迎区域样式 */
.welcome-section {
  padding: 30px;
}

.welcome-card {
  background-color: white;
  border-radius: 8px;
  padding: 30px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  text-align: center;
}

.welcome-card h2 {
  margin: 0 0 10px 0;
  font-size: 24px;
  color: #2c3e50;
}

.welcome-card p {
  margin: 0 0 20px 0;
  color: #6c757d;
  font-size: 16px;
}

.welcome-actions {
  display: flex;
  gap: 15px;
  justify-content: center;
  flex-wrap: wrap;
}

.primary-btn,
.secondary-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
  border: none;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.secondary-btn {
  background-color: white;
  color: #4CAF50;
  border: 1px solid #4CAF50;
}

.secondary-btn:hover {
  background-color: #f1f8e9;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.2);
}

/* 统计卡片样式 */
.stats-cards {
  display: flex;
  gap: 20px;
  padding: 0 30px 30px 30px;
  flex-wrap: wrap;
}

.stat-card {
  flex: 1;
  min-width: 200px;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  align-items: center;
  gap: 15px;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.available-icon {
  background-color: #2ecc71;
}

.reserved-icon {
  background-color: #3498db;
}

.active-icon {
  background-color: #f39c12;
}

.balance-icon {
  background-color: #9b59b6;
}

.card-content h3 {
  margin: 0 0 5px 0;
  font-size: 14px;
  color: #7f8c8d;
  font-weight: 400;
}

.stat-value {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
}

/* 图表区域样式 */
.charts-section {
  display: flex;
  gap: 20px;
  padding: 0 30px 30px 30px;
  flex-wrap: wrap;
}

.chart-card {
  flex: 1;
  min-width: 300px;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.chart-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.chart-placeholder {
  height: 250px;
  background-color: #f8f9fa;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6c757d;
}

/* 最近预约记录样式 */
.recent-reservations {
  max-height: 300px;
  overflow-y: auto;
}

.reservations-table {
  width: 100%;
  border-collapse: collapse;
}

.reservations-table th,
.reservations-table td {
  padding: 12px;
  text-align: center;
  border-bottom: 1px solid #e0e0e0;
}

.reservations-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
}

/* 状态列样式 */
.status-column {
  min-width: 80px;
  white-space: nowrap;
}

.status {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
}

.status.active {
  background-color: #d4edda;
  color: #155724;
}

.status.reserved {
  background-color: #fff3cd;
  color: #856404;
}

.status.completed {
  background-color: #d1ecf1;
  color: #0c5460;
}

.status.cancelled {
  background-color: #f8d7da;
  color: #721c24;
}

/* 用户信息和下拉菜单样式 */
.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: auto;
  }

  .nav-menu {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    padding: 0;
  }

  .nav-item {
    flex: 0 0 auto;
  }

  .stats-cards,
  .charts-section {
    flex-direction: column;
  }

  .welcome-actions {
    flex-direction: column;
  }

  .primary-btn,
  .secondary-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>