<template>
  <div class="admin-profile-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>仪表盘</span>
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位管理</span>
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15C10.9391 15 9.92172 15.4214 9.17157 16.1716C8.42143 16.9217 8 17.9391 8 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3 21V19C3 17.2091 4.20914 15.6 6 15.12V13C6 11.8954 6.89543 11 8 11H16C17.1046 11 18 11.8954 18 13V15.12C19.7909 15.6 21 17.2091 21 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 8C8 5.79086 9.79086 4 12 4C14.2091 4 16 5.79086 16 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>用户管理</span>
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约管理</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M19.4 15A1.65 1.65 0 0 0 18 13.35A1.65 1.65 0 0 0 16.65 12A1.65 1.65 0 0 0 15 10.65A1.65 1.65 0 0 0 13.35 9A1.65 1.65 0 0 0 12 7.65A1.65 1.65 0 0 0 10.65 9A1.65 1.65 0 0 0 9 10.65A1.65 1.65 0 0 0 7.65 12A1.65 1.65 0 0 0 9 13.35A1.65 1.65 0 0 0 10.65 15A1.65 1.65 0 0 0 12 16.35A1.65 1.65 0 0 0 13.35 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
        <router-link to="/admin/profile" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>
    
    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>个人信息</h1>
        </div>
        <div class="nav-right">
          <!-- 重新设计的悬停框 -->
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">管理员</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/admin/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>
      
      <!-- 个人信息内容 -->
      <section class="profile-content">
        <div class="profile-card">
          <div class="profile-header">
            <div class="avatar">
              <svg width="100" height="100" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <h2>管理员账户</h2>
          </div>
          
          <div class="profile-info">
            <div class="info-item">
              <label>用户名：</label>
              <span>{{ adminInfo.username }}</span>
            </div>
            <div class="info-item">
              <label>角色：</label>
              <span>{{ adminInfo.role }}</span>
            </div>
            <div class="info-item">
              <label>区块链地址：</label>
              <span>{{ adminInfo.walletAddress }}</span>
            </div>
            <div class="info-item">
              <label>创建时间：</label>
              <span>{{ adminInfo.createdAt }}</span>
            </div>
            <div class="info-item">
              <label>最后登录：</label>
              <span>{{ adminInfo.lastLogin }}</span>
            </div>
          </div>
          
          <div class="profile-actions">
            <button class="btn btn-primary" @click="showWithdrawModal = true">提取违约押金</button>
            <button class="btn btn-secondary" @click="router.push('/admin/change-password')">修改密码</button>
          </div>
        </div>
      </section>

      <!-- 提取违约押金模态框 -->
      <div v-if="showWithdrawModal" class="modal-overlay" @click="closeWithdrawModal">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h3>提取违约押金</h3>
            <button class="close-btn" @click="closeWithdrawModal">&times;</button>
          </div>
          <div class="modal-body">
            <!-- 显示当前违约押金总和信息 -->
            <div class="current-deposit-info" v-if="totalDepositInfo">
              <h4>当前违约押金信息</h4>
              <div class="summary-info">
                <div class="summary-item total">
                  <label>总违约金额：</label>
                  <span class="amount">{{ totalDepositInfo.totalAmount }} ETH</span>
                </div>
                <div class="summary-item">
                  <label>违约记录数：</label>
                  <span>{{ totalDepositInfo.violationCount }} 条</span>
                </div>
                <div class="summary-item">
                  <label>涉及用户数：</label>
                  <span>{{ totalDepositInfo.userCount }} 人</span>
                </div>
                <div class="summary-item">
                  <label>最后更新：</label>
                  <span>{{ totalDepositInfo.lastUpdate }}</span>
                </div>
              </div>
              
              <!-- 违约记录列表 -->
              <div class="violations-list" v-if="totalDepositInfo.violations && totalDepositInfo.violations.length > 0">
                <h5>违约记录明细</h5>
                <div class="violations-table">
                  <div class="table-header">
                    <div class="header-cell">违约ID</div>
                    <div class="header-cell">用户ID</div>
                    <div class="header-cell">金额</div>
                    <div class="header-cell">状态</div>
                  </div>
                  <div class="table-body">
                    <div class="table-row" v-for="violation in totalDepositInfo.violations" :key="violation.id">
                      <div class="table-cell">{{ violation.id }}</div>
                      <div class="table-cell">{{ violation.userId }}</div>
                      <div class="table-cell amount">{{ violation.amount }} ETH</div>
                      <div class="table-cell">
                        <span :class="['status-badge', violation.status]">
                          {{ violation.status === 'available' ? '可提取' : '已提取' }}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 查询按钮 -->
            <div class="query-section" v-if="!totalDepositInfo">
              <button class="btn btn-primary btn-block" @click="queryTotalDeposit" :disabled="isQuerying">
                {{ isQuerying ? '查询中...' : '显示当前违约押金' }}
              </button>
            </div>

            <!-- 提取押金表单 -->
            <div class="withdraw-form" v-if="totalDepositInfo">
              <div class="form-group">
                <label for="depositAmount">提取金额（ETH）</label>
                <input 
                  type="text" 
                  id="depositAmount" 
                  v-model="withdrawForm.depositAmount" 
                  placeholder="请输入提取金额"
                  class="form-control"
                >
              </div>
              <div class="form-group">
                <label for="walletAddress">接收地址</label>
                <input 
                  type="text" 
                  id="walletAddress" 
                  v-model="withdrawForm.walletAddress" 
                  placeholder="请输入接收押金的钱包地址"
                  class="form-control"
                >
              </div>
            </div>
            
            <div class="withdraw-info" v-if="withdrawResult">
              <h4>提取结果</h4>
              <div class="result-item">
                <label>总体状态：</label>
                <span :class="['status-badge', withdrawResult.success ? 'success' : 'error']">
                  {{ withdrawResult.success ? '全部成功' : '部分失败' }}
                </span>
              </div>
              <div class="result-item">
                <label>提示信息：</label>
                <span>{{ withdrawResult.message }}</span>
              </div>
              
              <!-- 详细交易结果 -->
              <div class="transaction-details" v-if="withdrawResult.transactionResults && withdrawResult.transactionResults.length > 0">
                <h5>详细交易记录</h5>
                <div class="transaction-table">
                  <div class="table-header">
                    <div class="header-cell">违约ID</div>
                    <div class="header-cell">提取金额</div>
                    <div class="header-cell">状态</div>
                    <div class="header-cell">交易哈希</div>
                    <div class="header-cell">错误信息</div>
                  </div>
                  <div class="table-body">
                    <div class="table-row" v-for="(result, index) in withdrawResult.transactionResults" :key="index">
                      <div class="table-cell">{{ result.violationId }}</div>
                      <div class="table-cell amount">
                        {{ result.amount }} ETH
                      </div>
                      <div class="table-cell">
                        <span :class="['status-badge', result.success ? 'success' : 'error']">
                          {{ result.success ? '成功' : '失败' }}
                        </span>
                      </div>
                      <div class="table-cell hash">
                        {{ result.transactionHash || '-' }}
                      </div>
                      <div class="table-cell error">
                        {{ result.error || '-' }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" @click="closeWithdrawModal">取消</button>
            <button class="btn btn-primary" @click="handleWithdrawDeposit" :disabled="isWithdrawing">
              {{ isWithdrawing ? '提取中...' : '提取押金' }}
            </button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref } from 'vue'
import { getAllViolations, withdrawViolationDeposit, getAllReservationDetails } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
// 重新添加showDropdown变量
const showDropdown = ref(false)

// 提取违约押金模态框相关变量
const showWithdrawModal = ref(false)
const totalDepositInfo = ref(null)
const isQuerying = ref(false)
const withdrawForm = ref({
  depositAmount: '',
  walletAddress: ''
})
const isWithdrawing = ref(false)
const withdrawResult = ref(null)

// 模拟管理员信息数据
const adminInfo = ref({
  username: 'admin',
  role: '管理员',
  walletAddress: '0x1234567890123456789012345678901234567890',
  createdAt: '2024-01-01 10:00:00',
  lastLogin: new Date().toLocaleString()
})

// 关闭提取押金模态框
const closeWithdrawModal = () => {
  showWithdrawModal.value = false
  totalDepositInfo.value = null
  withdrawForm.value = {
    depositAmount: '',
    walletAddress: ''
  }
  withdrawResult.value = null
}

// 从区块链获取合约余额和用户押金信息
const fetchBlockchainData = async () => {
  try {
    // 导入Web3库
    const { Web3 } = await import('web3')
    // 连接到Ganache
    const web3 = new Web3('http://127.0.0.1:7545')
    
    // 合约地址
    const contractAddress = '0x9fEfb53DC3f9170018c7eF660c6b9023736A3CcC'
    
    // 获取合约余额
    const contractBalanceWei = await web3.eth.getBalance(contractAddress)
    const contractBalance = parseFloat(web3.utils.fromWei(contractBalanceWei, 'ether'))
    
    // 获取所有账户
    const accounts = await web3.eth.getAccounts()
    
    // 合约ABI
    const abi = [
      {
        "inputs": [],
        "name": "admin",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [{"internalType": "address", "name": "", "type": "address"}],
        "name": "userDeposits",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function"
      }
    ]
    
    const contract = new web3.eth.Contract(abi, contractAddress)
    
    // 获取管理员地址
    const admin = await contract.methods.admin().call()
    
    // 查询所有用户的押金
    let totalUserDeposits = 0
    for (const account of accounts) {
      const depositWei = await contract.methods.userDeposits(account).call()
      if (depositWei > 0) {
        totalUserDeposits += parseFloat(web3.utils.fromWei(depositWei, 'ether'))
      }
    }
    
    // 计算违约金额（未分配余额）
    const violationAmount = contractBalance - totalUserDeposits
    
    return {
      contractBalance,
      totalUserDeposits,
      violationAmount: violationAmount > 0 ? violationAmount : 0
    }
    
  } catch (error) {
    console.error('从区块链获取数据失败:', error)
    throw error
  }
}

// 查询所有用户的违约押金总和
const queryTotalDeposit = async () => {
  isQuerying.value = true
  
  try {
    // 优先尝试从区块链获取数据
    let blockchainData = null
    try {
      blockchainData = await fetchBlockchainData()
      console.log('从区块链获取数据成功:', blockchainData)
    } catch (blockchainError) {
      console.warn('区块链数据获取失败，使用后端API:', blockchainError.message)
    }
    
    // 获取后端数据（用于违约记录统计）
    let violationsData = []
    let reservationDetails = []
    try {
      const [violations, reservations] = await Promise.all([
        getAllViolations(),
        getAllReservationDetails()
      ])
      violationsData = violations
      reservationDetails = reservations
    } catch (apiError) {
      console.warn('后端API调用失败:', apiError.message)
    }
    
    // 转换违约记录格式
    const formattedViolations = violationsData.map(violation => ({
      id: violation.id,
      userId: violation.userId,
      amount: (violation.depositAmount || 0).toFixed(4),
      status: violation.status.toLowerCase() === 'resolved' ? 'withdrawn' : 'available'
    }))
    
    // 如果有区块链数据，使用区块链的合约余额作为总合约押金
    const totalContractDeposit = blockchainData ? blockchainData.contractBalance : reservationDetails.reduce((sum, reservation) => {
      return sum + (reservation.depositAmount || 0)
    }, 0)
    
    // 计算签到退还的押金（已签到且已退还押金的预约）
    const refundedDeposit = reservationDetails.reduce((sum, reservation) => {
      if (reservation.checkedIn && reservation.depositRefunded) {
        return sum + (reservation.depositAmount || 0)
      }
      return sum
    }, 0)
    
    // 计算预约未签到但未违约的押金
    const nonViolationDeposit = reservationDetails.reduce((sum, reservation) => {
      // 未签到且没有对应的违约记录
      if (!reservation.checkedIn) {
        const hasViolation = violationsData.some(v => v.reservationId === reservation.id)
        if (!hasViolation) {
          return sum + (reservation.depositAmount || 0)
        }
      }
      return sum
    }, 0)
    
    // 使用区块链的违约金额（如果可用），否则使用计算的违约金额
    let totalViolationAmount
    if (blockchainData) {
      totalViolationAmount = blockchainData.violationAmount
    } else {
      // 计算总违约金额 = 智能合约总押金 - 签到退还的押金 - 预约未签到(未违约)的押金
      totalViolationAmount = totalContractDeposit - refundedDeposit - nonViolationDeposit
    }
    
    // 设置总押金信息
    totalDepositInfo.value = {
      totalAmount: totalViolationAmount.toFixed(4),
      violationCount: formattedViolations.length,
      userCount: new Set(formattedViolations.map(v => v.userId)).size,
      lastUpdate: new Date().toLocaleString(),
      violations: formattedViolations,
      // 额外信息用于调试
      contractDeposit: totalContractDeposit.toFixed(4),
      refundedDeposit: refundedDeposit.toFixed(4),
      nonViolationDeposit: nonViolationDeposit.toFixed(4),
      blockchainBalance: blockchainData ? blockchainData.contractBalance.toFixed(4) : 'N/A',
      blockchainViolationAmount: blockchainData ? blockchainData.violationAmount.toFixed(4) : 'N/A'
    }
    
    // 自动填充提取金额为总金额
    withdrawForm.value.depositAmount = totalDepositInfo.value.totalAmount
    
  } catch (error) {
    console.error('查询违约押金总和失败:', error)
    alert('查询失败：' + (error.message || '服务器错误'))
  } finally {
    isQuerying.value = false
  }
}

// 处理提取违约押金
const handleWithdrawDeposit = async () => {
  // 表单验证
  if (!totalDepositInfo.value) {
    alert('请先查询违约押金信息')
    return
  }
  if (!withdrawForm.value.depositAmount) {
    alert('请输入提取金额')
    return
  }
  if (!withdrawForm.value.walletAddress) {
    alert('请输入接收地址')
    return
  }
  
  // 验证金额是否有效
  const withdrawAmount = parseFloat(withdrawForm.value.depositAmount)
  const totalAmount = parseFloat(totalDepositInfo.value.totalAmount)
  
  if (isNaN(withdrawAmount) || withdrawAmount<= 0) {
    alert('请输入有效的提取金额')
    return
  }
  
  // 验证金额是否超过总押金
  if (withdrawAmount >totalAmount) {
    alert('提取金额不能超过总押金金额')
    return
  }

  isWithdrawing.value = true
  
  try {
    // 检查是否有可提取的违约押金
    if (totalAmount<= 0) {
      throw new Error('没有可提取的违约押金')
    }
    
    // 直接调用智能合约提取押金
    const { Web3 } = await import('web3')
    const web3 = new Web3('http://127.0.0.1:7545')
    
    // 获取当前账户（管理员账户）
    const accounts = await web3.eth.getAccounts()
    const adminAccount = accounts[0]
    
    // 合约地址和ABI
    const contractAddress = '0x9fEfb53DC3f9170018c7eF660c6b9023736A3CcC'
    const abi = [
      {
        "inputs": [{"internalType": "address", "name": "recipient", "type": "address"}, {"internalType": "uint256", "name": "amount", "type": "uint256"}],
        "name": "withdrawTo",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      }
    ]
    
    const contract = new web3.eth.Contract(abi, contractAddress)
    
    // 转换金额为wei
    const amountWei = web3.utils.toWei(withdrawAmount.toString(), 'ether')
    
    // 调用合约提取押金
    const transaction = await contract.methods.withdrawTo(withdrawForm.value.walletAddress, amountWei).send({
      from: adminAccount,
      gas: 1000000,
      gasPrice: '20000000000' // 20 Gwei
    })
    
    const result = { transactionHash: transaction.transactionHash }
    
    // 设置提取结果
    withdrawResult.value = {
      success: true,
      message: `成功提取 ${withdrawAmount} ETH`,
      transactionResults: [{
        violationId: 'ALL',
        amount: withdrawAmount,
        success: true,
        transactionHash: result.transactionHash || null
      }]
    }
    
    // 重新查询押金信息以更新状态
    await queryTotalDeposit()
    
  } catch (error) {
    console.error('提取违约押金失败:', error)
    withdrawResult.value = {
      success: false,
      message: '提取失败：' + (error.message || '服务器错误'),
      transactionResults: [{
        violationId: 'ALL',
        amount: withdrawAmount,
        success: false,
        error: error.message || '服务器错误'
      }]
    }
  } finally {
    isWithdrawing.value = false
  }
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.admin-profile-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式（与Admin.vue保持一致） */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 12px;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  display: flex;
  align-items: center;
  justify-content: center;
}

.sidebar-header h2 {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #ecf0f1;
  text-decoration: none;
  transition: all 0.3s;
  gap: 12px;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  width: 20px;
  height: 20px;
}

/* 主内容区域 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

/* 个人信息内容 */
.profile-content {
  padding: 24px;
  flex: 1;
}

.profile-card {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  padding: 24px;
  max-width: 600px;
  margin: 0 auto;
}

.profile-header {
  text-align: center;
  margin-bottom: 24px;
}

.avatar {
  display: inline-block;
  margin-bottom: 16px;
}

.profile-header h2 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.profile-info {
  margin-bottom: 24px;
}

.info-item {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #eee;
}

.info-item:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.info-item label {
  flex: 0 0 120px;
  font-weight: 600;
  color: #555;
}

.info-item span {
  flex: 1;
  color: #333;
  word-break: break-all;
}

.profile-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-primary {
  background-color: #4CAF50;
  color: white;
}

.btn-primary:hover {
  background-color: #45a049;
}

.btn-secondary {
  background-color: #f0f0f0;
  color: #333;
  border: 1px solid #ddd;
}

.btn-secondary:hover {
  background-color: #e0e0e0;
}

/* 用户信息和下拉菜单 */
.user-info {
  display: flex;
  align-items: center;
  gap: 12px;
  position: relative;
}

.username {
  font-weight: 600;
  cursor: pointer;
  color: #333;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  width: 180px;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #6c757d;
  font-size: 24px;
  line-height: 1;
  transition: color 0.3s ease;
}

.close-btn:hover {
  color: #dc3545;
}

.modal-body {
  padding: 20px;
}

/* 当前违约押金信息 */
.current-deposit-info {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  border: 1px solid #e9ecef;
}

.current-deposit-info h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  color: #2c3e50;
  font-weight: 600;
}

.current-deposit-info h5 {
  margin: 20px 0 12px 0;
  font-size: 14px;
  color: #2c3e50;
  font-weight: 600;
}

/* 汇总信息 */
.summary-info {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-bottom: 20px;
}

.summary-item {
  display: flex;
  flex-direction: column;
}

.summary-item.total {
  grid-column: 1 / -1;
  padding: 12px;
  background-color: #e8f5e9;
  border-radius: 6px;
  border: 1px solid #c8e6c9;
}

.summary-item label {
  font-size: 12px;
  color: #6c757d;
  margin-bottom: 4px;
  font-weight: 500;
}

.summary-item span {
  font-size: 14px;
  color: #2c3e50;
  font-weight: 500;
}

.summary-item.total span {
  font-size: 20px;
  color: #4CAF50;
  font-weight: 700;
}

/* 违约记录列表 */
.violations-list {
  margin-top: 20px;
}

.violations-table {
  border: 1px solid #e9ecef;
  border-radius: 6px;
  overflow: hidden;
}

.table-header {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  background-color: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
}

.header-cell {
  padding: 12px 16px;
  font-size: 12px;
  font-weight: 600;
  color: #6c757d;
  text-align: center;
}

.table-body {
  max-height: 200px;
  overflow-y: auto;
}

.table-row {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  border-bottom: 1px solid #f0f0f0;
}

.table-row:last-child {
  border-bottom: none;
}

.table-cell {
  padding: 12px 16px;
  font-size: 14px;
  color: #2c3e50;
  text-align: center;
}

.table-cell.amount {
  color: #4CAF50;
  font-weight: 600;
}

/* 查询区域 */
.query-section {
  margin-bottom: 20px;
  display: flex;
  justify-content: center;
}

.btn-block {
  width: 100%;
  max-width: 300px;
}

/* 提取押金表单 */
.withdraw-form {
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #2c3e50;
}

.form-control {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  outline: none;
  border-color: #4CAF50;
}

.withdraw-info {
  padding: 16px;
  background-color: #f8f9fa;
  border-radius: 4px;
  margin-top: 20px;
}

.withdraw-info h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  color: #2c3e50;
}

.result-item {
  display: flex;
  margin-bottom: 12px;
  align-items: flex-start;
}

.result-item:last-child {
  margin-bottom: 0;
}

.result-item label {
  flex: 0 0 80px;
  font-weight: 600;
  color: #2c3e50;
}

.result-item span {
  flex: 1;
  color: #495057;
}

/* 交易详情表格 */
.transaction-details {
  margin-top: 20px;
  border-top: 1px solid #e9ecef;
  padding-top: 20px;
}

.transaction-details h5 {
  margin: 0 0 12px 0;
  font-size: 14px;
  color: #2c3e50;
  font-weight: 600;
}

.transaction-table {
  border: 1px solid #e9ecef;
  border-radius: 6px;
  overflow: hidden;
}

.transaction-table .table-header {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 2fr 2fr;
  background-color: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
}

.transaction-table .header-cell {
  padding: 12px 16px;
  font-size: 12px;
  font-weight: 600;
  color: #6c757d;
  text-align: center;
}

.transaction-table .table-body {
  max-height: 200px;
  overflow-y: auto;
}

.transaction-table .table-row {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 2fr 2fr;
  border-bottom: 1px solid #f0f0f0;
}

.transaction-table .table-row:last-child {
  border-bottom: none;
}

.transaction-table .table-cell {
  padding: 12px 16px;
  font-size: 14px;
  color: #2c3e50;
  text-align: center;
}

.transaction-table .table-cell.hash {
  font-family: monospace;
  font-size: 12px;
  word-break: break-all;
  text-align: left;
}

.transaction-table .table-cell.error {
  color: #dc3545;
  font-size: 12px;
  text-align: left;
  word-break: break-word;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.success {
  background-color: #d4edda;
  color: #155724;
}

.status-badge.error {
  background-color: #f8d7da;
  color: #721c24;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 20px;
  border-top: 1px solid #e0e0e0;
}</style>