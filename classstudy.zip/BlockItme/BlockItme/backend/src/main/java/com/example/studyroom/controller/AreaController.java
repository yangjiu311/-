package com.example.studyroom.controller;

import com.example.studyroom.model.Area;
import com.example.studyroom.service.AreaService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/areas") // 移除/api前缀，因为context-path已经配置了
@AllArgsConstructor
public class AreaController {
    private final AreaService areaService;

    @GetMapping
    public ResponseEntity<List<Area>> getAllAreas() {
        List<Area> areas = areaService.getAllAreas();
        return new ResponseEntity<>(areas, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Area> getAreaById(@PathVariable Long id) {
        Optional<Area> area = areaService.getAreaById(id);
        return area.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Area> createArea(@RequestBody Area area) {
        Area createdArea = areaService.createArea(area);
        return new ResponseEntity<>(createdArea, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Area> updateArea(@PathVariable Long id, @RequestBody Area area) {
        try {
            Area updatedArea = areaService.updateArea(id, area);
            return new ResponseEntity<>(updatedArea, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArea(@PathVariable Long id) {
        areaService.deleteArea(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/classroom-name/{classroomName}")
    public ResponseEntity<Boolean> existsByClassroomName(@PathVariable String classroomName) {
        boolean exists = areaService.existsByClassroomName(classroomName);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }
}

// 新增一个Controller来处理webviewClick请求
@RestController
@AllArgsConstructor
class WebviewClickController {
    @PostMapping("/webviewClick")
    public ResponseEntity<String> handleWebviewClick() {
        // 简单返回成功响应，避免请求超时
        return ResponseEntity.ok("Webview click handled successfully");
    }
}