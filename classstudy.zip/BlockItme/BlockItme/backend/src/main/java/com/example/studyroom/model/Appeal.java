package com.example.studyroom.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "appeal")
public class Appeal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "stu_admin_id", length = 50, nullable = true)
    private String stuAdminId;

    @Column(name = "violation_id", nullable = false)
    private Long violationId;

    @Column(name = "appeal_content", columnDefinition = "TEXT")
    private String appealContent;

    @Enumerated(EnumType.STRING)
    @Column(name = "appeal_status", nullable = false)
    private AppealStatus appealStatus;

    @Column(name = "processing_result", columnDefinition = "TEXT")
    private String processingResult;

    @Column(name = "processed_by", length = 50)
    private String processedBy;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "transaction_hash", unique = true, length = 255)
    private String transactionHash;

    @Column(name = "block_height")
    private Long blockHeight;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum AppealStatus {
        pending, processing, approved, rejected
    }
}