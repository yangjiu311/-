package com.example.studyroom.repository;

import com.example.studyroom.model.Violation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ViolationRepository extends JpaRepository<Violation, Long> {
    List<Violation> findByUserId(String userId);
    Optional<Violation> findByReservationId(Long reservationId);
    List<Violation> findByStatus(Violation.Status status);
    List<Violation> findByViolationType(Violation.ViolationType violationType);
    Optional<Violation> findByTransactionHash(String transactionHash);
    List<Violation> findByUserIdAndStatus(String userId, Violation.Status status);
    boolean existsByReservationId(Long reservationId);
}