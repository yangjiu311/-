package com.example.studyroom.service;

import com.example.studyroom.model.User;
import java.util.List;
import java.util.Optional;

public interface UserService {
    List<User> getAllUsers();
    Optional<User> getUserById(Long id);
    Optional<User> getUserByUserId(String userId);
    Optional<User> getUserByWalletAddress(String walletAddress);
    Optional<User> getUserByStudentId(String studentId);
    User createUser(User user);
    User updateUser(Long id, User user);
    User patchUser(Long id, User user);
    void deleteUser(Long id);
    boolean existsByUserId(String userId);
    boolean existsByWalletAddress(String walletAddress);
    boolean existsByEmail(String email);
    boolean existsByPhone(String phone);
    boolean existsByStudentId(String studentId);
    
    /**
     * 获取指定角色的用户数量
     * @param role 角色
     * @return 用户数量
     */
    long getUsersCountByRole(User.Role role);
    
    /**
     * 验证用户登录信息
     * @param userId 用户ID
     * @param password 密码
     * @param role 角色
     * @return 验证成功的用户信息，失败则返回null
     */
    Optional<User> login(String userId, String password, String role);
    
    /**
     * 用户充值
     * @param id 用户ID
     * @param amount 充值金额
     * @return 更新后的用户信息
     */
    User rechargeUser(Long id, Double amount);
}