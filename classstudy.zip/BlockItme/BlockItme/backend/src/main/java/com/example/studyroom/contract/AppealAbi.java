package com.example.studyroom.contract;

import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.gas.ContractGasProvider;

public class AppealAbi extends Contract {
    protected AppealAbi(String contractBinary, String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(contractBinary, contractAddress, web3j, credentials, contractGasProvider);
    }

    public static AppealAbi load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new AppealAbi(null, contractAddress, web3j, credentials, contractGasProvider);
    }

    public TransactionReceipt createAppeal(String appealId, String userId, String violationId, String content) throws Exception {
        final Function function = new Function(
                "createAppeal",
                Arrays.asList(new Utf8String(appealId), new Utf8String(userId), new Utf8String(violationId), new Utf8String(content)),
                Collections.emptyList()
        );
        return executeRemoteCallTransaction(function).send();
    }
}
