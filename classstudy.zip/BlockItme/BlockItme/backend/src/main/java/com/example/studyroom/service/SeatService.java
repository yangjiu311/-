package com.example.studyroom.service;

import com.example.studyroom.model.Seat;
import java.util.List;
import java.util.Optional;

public interface SeatService {
    List<Seat> getAllSeats();
    Optional<Seat> getSeatById(Long id);
    Optional<Seat> getSeatBySeatNumber(String seatNumber);
    List<Seat> getSeatsByClassroomId(String classroomId);
    List<Seat> getSeatsByStatus(Seat.Status status);
    List<Seat> getSeatsByClassroomIdAndStatus(String classroomId, Seat.Status status);
    Seat createSeat(Seat seat);
    Seat updateSeat(Long id, Seat seat);
    void deleteSeat(Long id);
    boolean existsBySeatNumber(String seatNumber);
}