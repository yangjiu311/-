package com.example.studyroom.controller;

import com.example.studyroom.model.Violation;
import com.example.studyroom.service.ViolationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/violations")
@AllArgsConstructor
public class ViolationController {
    private final ViolationService violationService;

    @GetMapping
    public ResponseEntity<List<Violation>> getAllViolations() {
        List<Violation> violations = violationService.getAllViolations();
        return new ResponseEntity<>(violations, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Violation> getViolationById(@PathVariable Long id) {
        Optional<Violation> violation = violationService.getViolationById(id);
        return violation.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Violation>> getViolationsByUserId(@PathVariable String userId) {
        List<Violation> violations = violationService.getViolationsByUserId(userId);
        return new ResponseEntity<>(violations, HttpStatus.OK);
    }

    @GetMapping("/reservation/{reservationId}")
    public ResponseEntity<Violation> getViolationByReservationId(@PathVariable Long reservationId) {
        Optional<Violation> violation = violationService.getViolationByReservationId(reservationId);
        return violation.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Violation>> getViolationsByStatus(@PathVariable Violation.Status status) {
        List<Violation> violations = violationService.getViolationsByStatus(status);
        return new ResponseEntity<>(violations, HttpStatus.OK);
    }

    @GetMapping("/type/{violationType}")
    public ResponseEntity<List<Violation>> getViolationsByViolationType(@PathVariable Violation.ViolationType violationType) {
        List<Violation> violations = violationService.getViolationsByViolationType(violationType);
        return new ResponseEntity<>(violations, HttpStatus.OK);
    }

    @GetMapping("/user/{userId}/status/{status}")
    public ResponseEntity<List<Violation>> getViolationsByUserIdAndStatus(
            @PathVariable String userId,
            @PathVariable Violation.Status status) {
        List<Violation> violations = violationService.getViolationsByUserIdAndStatus(userId, status);
        return new ResponseEntity<>(violations, HttpStatus.OK);
    }

    @GetMapping("/transaction/{transactionHash}")
    public ResponseEntity<Violation> getViolationByTransactionHash(@PathVariable String transactionHash) {
        Optional<Violation> violation = violationService.getViolationByTransactionHash(transactionHash);
        return violation.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Violation> createViolation(@RequestBody Violation violation) {
        Violation createdViolation = violationService.createViolation(violation);
        return new ResponseEntity<>(createdViolation, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Violation> updateViolation(@PathVariable Long id, @RequestBody Violation violation) {
        try {
            Violation updatedViolation = violationService.updateViolation(id, violation);
            return new ResponseEntity<>(updatedViolation, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteViolation(@PathVariable Long id) {
        violationService.deleteViolation(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/reservation/{reservationId}")
    public ResponseEntity<Boolean> existsByReservationId(@PathVariable Long reservationId) {
        boolean exists = violationService.existsByReservationId(reservationId);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    /**
     * 提取违约押金
     */
    @PostMapping("/{id}/withdraw-deposit")
    public ResponseEntity<String> withdrawDeposit(@PathVariable Long id, @RequestBody WithdrawRequest request) {
        try {
            String transactionHash = violationService.withdrawDeposit(id, request.getAmount(), request.getWalletAddress());
            return new ResponseEntity<>(transactionHash, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    /**
     * 提取押金请求参数
     */
    static class WithdrawRequest {
        private String amount;
        private String walletAddress;

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getWalletAddress() {
            return walletAddress;
        }

        public void setWalletAddress(String walletAddress) {
            this.walletAddress = walletAddress;
        }
    }
}