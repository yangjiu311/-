package com.example.studyroom.repository;

import com.example.studyroom.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    List<Reservation> findByUserId(String userId);
    List<Reservation> findByUserIdAndDisplay(String userId, Reservation.DisplayStatus display);
    List<Reservation> findBySeatId(Long seatId);
    List<Reservation> findByStatus(Reservation.Status status);
    List<Reservation> findByUserIdAndStatus(String userId, Reservation.Status status);
    List<Reservation> findBySeatIdAndStatus(Long seatId, Reservation.Status status);
    Optional<Reservation> findByTransactionHash(String transactionHash);
    List<Reservation> findByStartTimeBetween(LocalDateTime start, LocalDateTime end);
    List<Reservation> findByEndTimeBetween(LocalDateTime start, LocalDateTime end);
    List<Reservation> findBySeatIdAndStartTimeBetween(Long seatId, LocalDateTime start, LocalDateTime end);
    // 添加获取最近预约记录的方法
    List<Reservation> findTop5ByOrderByStartTimeDesc();
    
    // 添加查询指定用户最新5条预约记录的方法
    List<Reservation> findTop5ByUserIdOrderByStartTimeDesc(String userId);
    
    // 添加查询已签到且结束时间小于当前时间的预约
    List<Reservation> findByStatusAndEndTimeBefore(Reservation.Status status, LocalDateTime endTime);
    
    // 更新预约记录的display字段（软删除）
    @Modifying
    @Query("UPDATE Reservation r SET r.display = ?2 WHERE r.id = ?1")
    void updateDisplayByReservationId(Long reservationId, boolean display);
}