package com.example.studyroom.model;

import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "check_in")
public class CheckIn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reservation_id", unique = true, nullable = false)
    private Long reservationId;

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "stu_admin_id", nullable = false, length = 50)
    private String stuAdminId;

    @Column(name = "actual_check_in_time", nullable = false)
    private LocalDateTime actualCheckInTime;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private Status status;

    @Column(name = "transaction_hash", unique = true, length = 255)
    private String transactionHash;

    @Column(name = "block_height")
    private Long blockHeight;
    
    @Column(name = "deposit_refund_tx_hash", length = 255)
    private String depositRefundTxHash;

    @Column(name = "classroom_name", length = 255)
    private String classroomName;

    @Column(name = "seat_number", length = 50)
    private String seatNumber;

    @Column(name = "reservation_start_time")
    private LocalDateTime reservationStartTime;

    @Column(name = "reservation_end_time")
    private LocalDateTime reservationEndTime;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "display", nullable = false, length = 10)
    private DisplayStatus display = DisplayStatus.TRUE;

    @Column(name = "check_in_id", unique = true, nullable = false, length = 100)
    private String checkInId;

    public enum Status {
        checked_in, late, missed
    }

    public enum DisplayStatus {
        TRUE("true"),
        FALSE("false");

        private final String value;

        DisplayStatus(String value) {
            this.value = value;
        }

        @JsonValue
        public String getValue() {
            return value;
        }

        public static DisplayStatus fromValue(String value) {
            for (DisplayStatus status : DisplayStatus.values()) {
                if (status.value.equals(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown DisplayStatus value: " + value);
        }
    }
}