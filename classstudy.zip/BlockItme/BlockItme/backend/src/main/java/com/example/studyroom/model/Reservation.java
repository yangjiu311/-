package com.example.studyroom.model;

import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "reservation")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "stu_admin_id", nullable = false, length = 50)
    private String stuAdminId;

    @Column(name = "seat_id", nullable = false)
    private Long seatId;

    @Column(name = "seat_number", nullable = false, length = 50)
    private String seatNumber;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "reservation_date", nullable = false)
    private LocalDate reservationDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status;

    @Column(name = "transaction_hash", unique = true, length = 255)
    private String transactionHash;

    @Column(name = "block_height")
    private Long blockHeight;

    @Column(name = "classroom_name", nullable = false, length = 50)
    private String classroomName;
    
    @Column(name = "deposit_amount")
    private String depositAmount;
    
    @Column(name = "deposit_tx_hash", length = 255)
    private String depositTxHash;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    // 非数据库字段，用于存储用户姓名
    @Transient
    private String userName;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "display", nullable = false, length = 10)
    private DisplayStatus display = DisplayStatus.TRUE;

    public enum Status {
        pending, reserved, confirmed, checked_in, completed, late, cancelled, violated
    }

    public enum DisplayStatus {
        TRUE("true"),
        FALSE("false");

        private final String value;

        DisplayStatus(String value) {
            this.value = value;
        }

        @JsonValue
        public String getValue() {
            return this.value;
        }

        public static DisplayStatus fromValue(String value) {
            for (DisplayStatus status : DisplayStatus.values()) {
                if (status.value.equals(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown DisplayStatus value: " + value);
        }
    }
}