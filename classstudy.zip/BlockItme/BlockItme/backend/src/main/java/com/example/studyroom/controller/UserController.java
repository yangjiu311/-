package com.example.studyroom.controller;

import com.example.studyroom.model.User;
import com.example.studyroom.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
@AllArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/user-id/{userId}")
    public ResponseEntity<User> getUserByUserId(@PathVariable String userId) {
        Optional<User> user = userService.getUserByUserId(userId);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/wallet/{walletAddress}")
    public ResponseEntity<User> getUserByWalletAddress(@PathVariable String walletAddress) {
        Optional<User> user = userService.getUserByWalletAddress(walletAddress);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.createUser(user);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User updatedUser = userService.updateUser(id, user);
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<User> patchUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User updatedUser = userService.patchUser(id, user);
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/user-id/{userId}")
    public ResponseEntity<Boolean> existsByUserId(@PathVariable String userId) {
        boolean exists = userService.existsByUserId(userId);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    @GetMapping("/exists/wallet/{walletAddress}")
    public ResponseEntity<Boolean> existsByWalletAddress(@PathVariable String walletAddress) {
        boolean exists = userService.existsByWalletAddress(walletAddress);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    @GetMapping("/exists/email/{email}")
    public ResponseEntity<Boolean> existsByEmail(@PathVariable String email) {
        boolean exists = userService.existsByEmail(email);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    @GetMapping("/exists/phone/{phone}")
    public ResponseEntity<Boolean> existsByPhone(@PathVariable String phone) {
        boolean exists = userService.existsByPhone(phone);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    // 添加获取学生用户数的API接口
    @GetMapping("/count/role/{role}")
    public ResponseEntity<Long> getUsersCountByRole(@PathVariable User.Role role) {
        long count = userService.getUsersCountByRole(role);
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    // 添加用户充值API接口
    @PostMapping("/{id}/recharge")
    public ResponseEntity<User> rechargeUser(@PathVariable Long id, @RequestBody java.util.Map<String, Double> request) {
        try {
            Double amount = request.get("amount");
            if (amount == null || amount <= 0) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            User updatedUser = userService.rechargeUser(id, amount);
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}