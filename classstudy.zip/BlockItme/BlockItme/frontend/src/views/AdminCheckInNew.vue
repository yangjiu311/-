<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <div class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>仪表盘</span>
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位管理</span>
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15C10.9391 15 9.92172 15.4214 9.17157 16.1716C8.42143 16.9217 8 17.9391 8 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>用户管理</span>
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </div>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <h1>签到记录管理</h1>
        <div class="user-info" @click="showDropdown = !showDropdown">
          <span class="username">管理员</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <!-- 用户下拉菜单 -->
          <div class="user-dropdown" v-if="showDropdown">
            <button class="dropdown-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              修改密码
            </button>
            <button class="dropdown-item" @click="logout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M15 15L21 12L15 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              退出登录
            </button>
          </div>
        </div>
      </header>

      <!-- 签到记录管理内容区域 -->
      <section class="checkins-management">
        <!-- 统计卡片 -->
        <div class="stats-cards">
          <div class="stat-card">
            <div class="stat-icon total">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">总签到数</div>
              <div class="stat-value">{{ stats.total }}</div>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-icon normal">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 11.08V12C21.9988 14.1564 21.3005 16.2547 20.0093 17.9818C18.7182 19.709 16.9033 20.9725 14.8354 21.5839C12.7674 22.1953 10.5573 22.1219 8.53447 21.3746C6.51168 20.6273 4.78465 19.2461 3.61096 17.4371C2.43727 15.628 1.87979 13.4881 2.02168 11.3363C2.16356 9.18455 2.99721 7.13631 4.39828 5.49706C5.79935 3.85781 7.69279 2.71537 9.79619 2.24013C11.8996 1.7649 14.1003 1.98232 16.07 2.85999" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M22 4L12 14.01L9 11.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">正常签到</div>
              <div class="stat-value">{{ stats.normal }}</div>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-icon late">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">迟到签到</div>
              <div class="stat-value">{{ stats.late }}</div>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-icon violated">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">违约签到</div>
              <div class="stat-value">{{ stats.violated }}</div>
            </div>
          </div>
        </div>

        <!-- 功能按钮和搜索区域 -->
        <div class="actions-search-container">
          <!-- 功能按钮 -->
          <div class="action-buttons">
            <button class="action-btn export" @click="exportCheckIns">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <polyline points="7 10 12 15 17 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              导出数据
            </button>
            <button class="action-btn delete" @click="batchDelete" :disabled="selectedCheckIns.length === 0">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              批量删除
            </button>
          </div>

          <!-- 搜索栏 -->
          <div class="search-bar">
            <select v-model="searchType" class="search-select">
              <option value="userId">用户ID</option>
              <option value="classroomName">教室名称</option>
              <option value="seatNumber">座位号</option>
              <option value="status">状态</option>
              <option value="reservationId">预约ID</option>
            </select>
            <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索签到记录...">
            <button class="search-btn" @click="handleSearch">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.74948 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              搜索
            </button>
            <button class="reset-btn" @click="resetSearch">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M3 3v5h5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              重置
            </button>
          </div>
        </div>

        <!-- 加载状态 -->
        <div v-if="loading" class="loading-overlay">
          <div class="loading-spinner"></div>
        </div>

        <!-- 签到记录列表 -->
        <div class="checkins-list">
          <table class="checkins-table">
            <thead>
              <tr>
                <th><input type="checkbox" v-model="selectAll" @change="handleSelectAll"></th>
                <th>签到ID</th>
                <th>用户ID</th>
                <th>预约ID</th>
                <th>教室</th>
                <th>座位号</th>
                <th>签到时间</th>
                <th>状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="checkin in paginatedCheckins" :key="checkin.id">
                <td><input type="checkbox" v-model="selectedCheckIns" :value="checkin.id" @change="handleSelectOne"></td>
                <td>{{ checkin.check_in_id }}</td>
                <td>{{ checkin.user_id }}</td>
                <td>{{ checkin.reservation_id }}</td>
                <td>{{ checkin.classroom_name }}</td>
                <td>{{ checkin.seat_number }}</td>
                <td>{{ formatDateTime(checkin.actual_check_in_time) }}</td>
                <td>
                  <span :class="['status', checkin.status]">
                    {{ statusText[checkin.status] || checkin.status }}
                  </span>
                </td>
                <td>
                  <button class="btn-view" @click="viewCheckin(checkin)">查看</button>
                  <button class="btn-delete" @click="deleteCheckin(checkin.id)">删除</button>
                </td>
              </tr>
              <tr v-if="paginatedCheckins.length === 0">
                <td colspan="9" style="text-align: center; padding: 40px; color: #999;">
                  暂无签到记录数据
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 分页 -->
        <div v-if="totalPages > 1" class="pagination">
          <button class="page-btn prev-btn" @click="handlePageChange(currentPage - 1)" :disabled="currentPage === 1">上一页</button>
          <button 
            v-for="page in Math.min(totalPages, 5)" 
            :key="page" 
            class="page-btn" 
            :class="{ current: page === currentPage }"
            @click="handlePageChange(page)"
          >
            {{ page }}
          </button>
          <button class="page-btn next-btn" @click="handlePageChange(currentPage + 1)" :disabled="currentPage === totalPages">下一页</button>
        </div>
      </section>

      <!-- 查看签到详情对话框 -->
      <div v-if="showViewModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>签到详情</h3>
            <button class="close-btn" @click="showViewModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>签到ID</label>
              <input type="text" :value="selectedCheckin.check_in_id" readonly />
            </div>
            <div class="form-group">
              <label>用户ID</label>
              <input type="text" :value="selectedCheckin.user_id" readonly />
            </div>
            <div class="form-group">
              <label>预约ID</label>
              <input type="text" :value="selectedCheckin.reservation_id" readonly />
            </div>
            <div class="form-group">
              <label>教室</label>
              <input type="text" :value="selectedCheckin.classroom_name" readonly />
            </div>
            <div class="form-group">
              <label>座位号</label>
              <input type="text" :value="selectedCheckin.seat_number" readonly />
            </div>
            <div class="form-group">
              <label>签到时间</label>
              <input type="text" :value="formatDateTime(selectedCheckin.actual_check_in_time)" readonly />
            </div>
            <div class="form-group">
              <label>预约开始时间</label>
              <input type="text" :value="formatDateTime(selectedCheckin.reservation_start_time)" readonly />
            </div>
            <div class="form-group">
              <label>预约结束时间</label>
              <input type="text" :value="formatDateTime(selectedCheckin.reservation_end_time)" readonly />
            </div>
            <div class="form-group">
              <label>状态</label>
              <input type="text" :value="statusText[selectedCheckin.status] || selectedCheckin.status" readonly />
            </div>
            <div class="form-group">
              <label>交易哈希</label>
              <input type="text" :value="selectedCheckin.transaction_hash" readonly />
            </div>
            <div class="form-group">
              <label>区块高度</label>
              <input type="text" :value="selectedCheckin.block_height" readonly />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-confirm" @click="showViewModal = false">确定</button>
          </div>
        </div>
      </div>

      <!-- 批量删除确认对话框 -->
      <div v-if="showDeleteModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>确认删除</h3>
            <button class="close-btn" @click="showDeleteModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <p>确定要删除选中的{{ selectedCheckIns.length }}条签到记录吗？</p>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showDeleteModal = false">取消</button>
            <button class="btn-confirm delete" @click="confirmBatchDelete">确定删除</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { getAllCheckIns, deleteCheckIn, batchDeleteCheckIns } from '../services/api'

export default {
  name: 'AdminCheckIn',
  setup() {
    const checkins = ref([])
    const loading = ref(false)
    const showDropdown = ref(false)
    const selectedCheckIns = ref([])
    const selectAll = ref(false)
    const currentPage = ref(1)
    const pageSize = ref(10)
    const searchType = ref('userId')
    const searchKeyword = ref('')
    const showViewModal = ref(false)
    const showDeleteModal = ref(false)
    const selectedCheckin = ref({})

    // 状态文本映射
    const statusText = {
      checked_in: '正常签到',
      late: '迟到',
      violated: '违约'
    }

    // 统计数据
    const stats = ref({
      total: 0,
      normal: 0,
      late: 0,
      violated: 0
    })

    // 计算分页后的签到记录
    const paginatedCheckins = computed(() => {
      const startIndex = (currentPage.value - 1) * pageSize.value
      return checkins.value.slice(startIndex, startIndex + pageSize.value)
    })

    // 计算总页数
    const totalPages = computed(() => {
      return Math.ceil(checkins.value.length / pageSize.value)
    })

    // 格式化日期时间
    const formatDateTime = (dateTime) => {
      if (!dateTime) return '-'
      const date = new Date(dateTime)
      return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      })
    }

    // 计算统计数据
    const calculateStats = () => {
      stats.value = {
        total: checkins.value.length,
        normal: checkins.value.filter(c => c.status === 'checked_in').length,
        late: checkins.value.filter(c => c.status === 'late').length,
        violated: checkins.value.filter(c => c.status === 'violated').length
      }
    }

    // 获取签到记录数据
    const fetchCheckInData = async () => {
      loading.value = true
      try {
        const data = await getAllCheckIns()
        checkins.value = data
        calculateStats()
      } catch (error) {
        console.error('获取签到记录失败:', error)
        // 使用模拟数据
        checkins.value = [
          {
            id: 1,
            check_in_id: 'CI202401070001',
            user_id: 'user123',
            reservation_id: 101,
            classroom_name: 'A区',
            seat_number: 'A1-01',
            actual_check_in_time: new Date().toISOString(),
            status: 'checked_in',
            transaction_hash: '0x1234567890abcdef',
            block_height: 12345,
            reservation_start_time: new Date().toISOString(),
            reservation_end_time: new Date(Date.now() + 3600000).toISOString()
          },
          {
            id: 2,
            check_in_id: 'CI202401070002',
            user_id: 'user456',
            reservation_id: 102,
            classroom_name: 'B区',
            seat_number: 'B2-03',
            actual_check_in_time: new Date().toISOString(),
            status: 'late',
            transaction_hash: '0x0987654321fedcba',
            block_height: 12346,
            reservation_start_time: new Date().toISOString(),
            reservation_end_time: new Date(Date.now() + 3600000).toISOString()
          }
        ]
        calculateStats()
      } finally {
        loading.value = false
      }
    }

    // 处理全选
    const handleSelectAll = () => {
      if (selectAll.value) {
        selectedCheckIns.value = checkins.value.map(checkin => checkin.id)
      } else {
        selectedCheckIns.value = []
      }
    }

    // 处理单个选择
    const handleSelectOne = () => {
      selectAll.value = selectedCheckIns.value.length === checkins.value.length
    }

    // 处理分页变化
    const handlePageChange = (page) => {
      if (page >= 1 && page <= totalPages.value) {
        currentPage.value = page
      }
    }

    // 处理搜索
    const handleSearch = () => {
      // 这里可以实现搜索逻辑
      console.log('搜索类型:', searchType.value)
      console.log('搜索关键字:', searchKeyword.value)
      // 实际项目中，这里应该调用API进行搜索
    }

    // 重置搜索
    const resetSearch = () => {
      searchType.value = 'userId'
      searchKeyword.value = ''
    }

    // 导出签到记录
    const exportCheckIns = () => {
      // 这里可以实现导出逻辑
      console.log('导出签到记录')
      // 实际项目中，这里应该调用API进行导出
    }

    // 查看签到详情
    const viewCheckin = (checkin) => {
      selectedCheckin.value = checkin
      showViewModal.value = true
    }

    // 删除单个签到记录
    const deleteCheckin = async (id) => {
      try {
        await deleteCheckIn(id)
        checkins.value = checkins.value.filter(checkin => checkin.id !== id)
        calculateStats()
      } catch (error) {
        console.error('删除签到记录失败:', error)
      }
    }

    // 批量删除
    const batchDelete = () => {
      if (selectedCheckIns.value.length > 0) {
        showDeleteModal.value = true
      }
    }

    // 确认批量删除
    const confirmBatchDelete = async () => {
      try {
        await batchDeleteCheckIns(selectedCheckIns.value)
        checkins.value = checkins.value.filter(checkin => !selectedCheckIns.value.includes(checkin.id))
        selectedCheckIns.value = []
        selectAll.value = false
        calculateStats()
        showDeleteModal.value = false
      } catch (error) {
        console.error('批量删除签到记录失败:', error)
      }
    }

    // 退出登录
    const logout = () => {
      // 这里可以实现退出登录逻辑
      console.log('退出登录')
    }

    // 组件挂载时获取数据
    onMounted(() => {
      fetchCheckInData()
    })

    return {
      checkins,
      loading,
      showDropdown,
      selectedCheckIns,
      selectAll,
      currentPage,
      pageSize,
      searchType,
      searchKeyword,
      showViewModal,
      showDeleteModal,
      selectedCheckin,
      statusText,
      stats,
      paginatedCheckins,
      totalPages,
      formatDateTime,
      handleSelectAll,
      handleSelectOne,
      handlePageChange,
      handleSearch,
      resetSearch,
      exportCheckIns,
      viewCheckin,
      deleteCheckin,
      batchDelete,
      confirmBatchDelete,
      logout
    }
  }
}
</script>

<style scoped>
.admin-container {
  display: flex;
  min-height: 100vh;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  box-shadow: 2px 0 10px rgba(0,0,0,0.1);
  min-height: 100vh;
}

.sidebar-header {
  display: flex;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.blockchain-icon {
  margin-right: 12px;
}

.sidebar-header h2 {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
}

.nav-menu {
  padding: 10px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  transition: all 0.3s ease;
  text-decoration: none;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  color: white;
  background-color: rgba(255, 255, 255, 0.1);
}

.nav-item.active {
  color: white;
  background-color: rgba(76, 175, 80, 0.2);
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
  width: 20px;
  height: 20px;
}

.nav-item span {
  font-size: 14px;
  font-weight: 500;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  min-height: 100vh;
  padding: 20px;
  overflow-y: auto;
}

/* 顶部导航栏样式 */
.top-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 15px;
  border-bottom: 1px solid #ebeef5;
}

.top-nav h1 {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
  margin: 0;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative;
}

.username {
  margin-right: 8px;
  font-size: 14px;
  color: #606266;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 5px;
  background-color: white;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  min-width: 120px;
  z-index: 100;
}

.dropdown-item {
  display: flex;
  align-items: center;
  padding: 10px 15px;
  font-size: 14px;
  color: #606266;
  cursor: pointer;
  transition: all 0.3s;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f7fa;
  color: #409eff;
}

.dropdown-item svg {
  margin-right: 8px;
  width: 16px;
  height: 16px;
}

/* 签到记录管理内容区域样式 */
.checkins-management {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  padding: 30px;
}

/* 统计卡片样式 */
.stats-cards {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  flex: 1;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-icon.total {
  background-color: rgba(76, 175, 80, 0.1);
  color: #4CAF50;
}

.stat-icon.normal {
  background-color: rgba(64, 158, 255, 0.1);
  color: #409eff;
}

.stat-icon.late {
  background-color: rgba(230, 162, 60, 0.1);
  color: #e6a23c;
}

.stat-icon.violated {
  background-color: rgba(245, 108, 108, 0.1);
  color: #f56c6c;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
}

/* 功能按钮和搜索区域样式 */
.actions-search-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.action-buttons {
  display: flex;
  gap: 10px;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 8px 16px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: white;
  color: #606266;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.action-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.action-btn.export {
  background-color: #f5f7fa;
  border-color: #dcdfe6;
}

.action-btn.delete {
  color: #f56c6c;
  border-color: #fbc4c4;
}

.action-btn.delete:hover {
  background-color: #fef0f0;
  border-color: #f56c6c;
}

.action-btn:disabled {
  color: #c0c4cc;
  border-color: #ebeef5;
  background-color: #f5f7fa;
  cursor: not-allowed;
}

.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-select {
  padding: 8px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  font-size: 14px;
  color: #606266;
  background-color: white;
}

.search-input {
  padding: 8px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  font-size: 14px;
  width: 200px;
}

.search-input:focus {
  outline: none;
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}

.search-btn {
  padding: 8px 16px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: white;
  color: #606266;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 5px;
}

.search-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.reset-btn {
  padding: 8px 16px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: white;
  color: #606266;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 5px;
}

.reset-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

/* 加载状态样式 */
.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(255, 255, 255, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  border-radius: 8px;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #409eff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 签到记录列表样式 */
.checkins-list {
  margin-bottom: 20px;
}

.checkins-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
  table-layout: fixed;
}

.checkins-table th,
.checkins-table td {
  padding: 12px 15px;
  text-align: left;
  border-bottom: 1px solid #ebeef5;
}

.checkins-table th {
  background-color: #f5f7fa;
  font-weight: 600;
  color: #303133;
}

.checkins-table tr:hover {
  background-color: #f5f7fa;
}

.status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status.checked_in {
  background-color: rgba(76, 175, 80, 0.1);
  color: #4CAF50;
}

.status.late {
  background-color: rgba(230, 162, 60, 0.1);
  color: #e6a23c;
}

.status.violated {
  background-color: rgba(245, 108, 108, 0.1);
  color: #f56c6c;
}

.btn-view,
.btn-delete {
  padding: 4px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: white;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 12px;
  margin-right: 5px;
}

.btn-view {
  color: #409eff;
  border-color: #c6e2ff;
}

.btn-view:hover {
  background-color: #ecf5ff;
}

.btn-delete {
  color: #f56c6c;
  border-color: #fbc4c4;
}

.btn-delete:hover {
  background-color: #fef0f0;
}

/* 分页样式 */
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 30px;
  gap: 5px;
}

.page-btn {
  padding: 5px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: #fff;
  color: #606266;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.page-btn:hover {
  color: #409eff;
  border-color: #409eff;
}

.page-btn.current {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}

.page-btn:disabled {
  color: #c0c4cc;
  border-color: #ebeef5;
  background-color: #f5f7fa;
  cursor: not-allowed;
}

/* 对话框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.modal-content {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  width: 500px;
  max-width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #ebeef5;
}

.modal-header h3 {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
  margin: 0;
}

.close-btn {
  background: none;
  border: none;
  font-size: 16px;
  color: #909399;
  cursor: pointer;
  padding: 0;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  color: #606266;
}

.modal-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  font-size: 14px;
  color: #606266;
  margin-bottom: 5px;
}

.form-group input {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  font-size: 14px;
  color: #303133;
}

.form-group input:focus {
  outline: none;
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}

.required {
  color: #f56c6c;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 15px 20px;
  border-top: 1px solid #ebeef5;
  gap: 10px;
}

.btn-cancel,
.btn-confirm {
  padding: 8px 16px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.btn-cancel {
  background-color: #fff;
  color: #606266;
}

.btn-cancel:hover {
  color: #409eff;
  border-color: #409eff;
}

.btn-confirm {
  background-color: #409eff;
  color: #fff;
  border-color: #409eff;
}

.btn-confirm:hover {
  background-color: #66b1ff;
  border-color: #66b1ff;
}

.btn-confirm.delete {
  background-color: #f56c6c;
  border-color: #f56c6c;
}

.btn-confirm.delete:hover {
  background-color: #f78989;
  border-color: #f78989;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .stats-cards {
    flex-wrap: wrap;
  }
  
  .stat-card {
    flex: 1 1 calc(50% - 10px);
  }
  
  .actions-search-container {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .action-buttons {
    width: 100%;
  }
  
  .search-bar {
    width: 100%;
  }
  
  .search-input {
    flex: 1;
  }
}

@media (max-width: 768px) {
  .admin-container {
    flex-direction: column;
  }
  
  .sidebar {
    width: 100%;
    border-right: none;
    border-bottom: 1px solid #e4e7ed;
  }
  
  .checkins-management {
    padding: 20px;
  }
  
  .stat-card {
    flex: 1 1 100%;
  }
  
  .checkins-table th, .checkins-table td {
    padding: 8px 10px;
    font-size: 12px;
  }
  
  .action-btn {
    padding: 6px 12px;
    font-size: 12px;
  }
}
</style>