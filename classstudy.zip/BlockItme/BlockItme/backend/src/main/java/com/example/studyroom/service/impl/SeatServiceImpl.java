package com.example.studyroom.service.impl;

import com.example.studyroom.model.Seat;
import com.example.studyroom.repository.SeatRepository;
import com.example.studyroom.service.SeatService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class SeatServiceImpl implements SeatService {

    private final SeatRepository seatRepository;

    @Override
    public List<Seat> getAllSeats() {
        return seatRepository.findAll();
    }

    @Override
    public Optional<Seat> getSeatById(@NonNull Long id) {
        return seatRepository.findById(id);
    }

    @Override
    public Optional<Seat> getSeatBySeatNumber(@NonNull String seatNumber) {
        return seatRepository.findBySeatNumber(seatNumber);
    }

    @Override
    public List<Seat> getSeatsByClassroomId(@NonNull String classroomId) {
        // 因为数据库中已经没有classroomId字段，所以这个方法不再使用
        // 可以考虑改为按classroomName查询
        return seatRepository.findAll();
    }

    @Override
    public List<Seat> getSeatsByStatus(@NonNull Seat.Status status) {
        return seatRepository.findByStatus(status);
    }

    @Override
    public List<Seat> getSeatsByClassroomIdAndStatus(@NonNull String classroomId, @NonNull Seat.Status status) {
        // 因为数据库中已经没有classroomId字段，所以这个方法不再使用
        // 可以考虑改为按classroomName和status查询
        return seatRepository.findByStatus(status);
    }

    @Override
    public Seat createSeat(@NonNull Seat seat) {
        seat.setCreatedAt(LocalDateTime.now());
        return seatRepository.save(seat);
    }

    @Override
    public Seat updateSeat(@NonNull Long id, @NonNull Seat seat) {
        Optional<Seat> existingSeat = seatRepository.findById(id);
        if (existingSeat.isPresent()) {
            Seat updatedSeat = existingSeat.get();
            updatedSeat.setSeatNumber(seat.getSeatNumber());
            updatedSeat.setClassroomName(seat.getClassroomName());
            updatedSeat.setRow(seat.getRow());
            updatedSeat.setColumn(seat.getColumn());
            updatedSeat.setStatus(seat.getStatus());
            updatedSeat.setDescription(seat.getDescription());
            updatedSeat.setUpdatedAt(LocalDateTime.now());
            return seatRepository.save(updatedSeat);
        }
        throw new RuntimeException("Seat not found with id: " + id);
    }

    @Override
    public void deleteSeat(@NonNull Long id) {
        seatRepository.deleteById(id);
    }

    @Override
    public boolean existsBySeatNumber(@NonNull String seatNumber) {
        return seatRepository.existsBySeatNumber(seatNumber);
    }
}