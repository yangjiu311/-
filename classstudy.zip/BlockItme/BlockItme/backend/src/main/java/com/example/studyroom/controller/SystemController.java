package com.example.studyroom.controller;

import com.example.studyroom.service.impl.BlockchainUploader;
import com.example.studyroom.service.impl.TestViolationGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/") // 使用根路径，因为前端请求的是/api/getThemeColors等
public class SystemController {
    private final TestViolationGenerator testViolationGenerator;
    private final BlockchainUploader blockchainUploader;
    
    public SystemController(TestViolationGenerator testViolationGenerator, BlockchainUploader blockchainUploader) {
        this.testViolationGenerator = testViolationGenerator;
        this.blockchainUploader = blockchainUploader;
    }

    @GetMapping("/getThemeColors")
    public ResponseEntity<Map<String, String>> getThemeColors() {
        // 返回默认的主题颜色
        Map<String, String> themeColors = new HashMap<>();
        themeColors.put("primary", "#409EFF");
        themeColors.put("success", "#67C23A");
        themeColors.put("warning", "#E6A23C");
        themeColors.put("danger", "#F56C6C");
        themeColors.put("info", "#909399");
        return new ResponseEntity<>(themeColors, HttpStatus.OK);
    }

    @GetMapping("/getLanguageText")
    public ResponseEntity<Map<String, String>> getLanguageText() {
        // 返回默认的语言文本
        Map<String, String> languageText = new HashMap<>();
        languageText.put("title", "自习室座位预约系统");
        languageText.put("welcome", "欢迎使用自习室座位预约系统");
        languageText.put("seat", "座位");
        languageText.put("area", "区域");
        languageText.put("date", "日期");
        languageText.put("time", "时间");
        return new ResponseEntity<>(languageText, HttpStatus.OK);
    }

    @GetMapping("/getWorkspacePath")
    public ResponseEntity<Map<String, String>> getWorkspacePath() {
        // 返回默认的工作区路径
        Map<String, String> workspacePath = new HashMap<>();
        workspacePath.put("path", "/workspace");
        return new ResponseEntity<>(workspacePath, HttpStatus.OK);
    }

    @PostMapping("/setIsSelect")
    public ResponseEntity<Map<String, Boolean>> setIsSelect(@RequestBody Map<String, Boolean> request) {
        // 处理设置选择状态的请求
        Boolean isSelect = request.getOrDefault("isSelect", false);
        Map<String, Boolean> response = new HashMap<>();
        response.put("success", true);
        response.put("isSelect", isSelect);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @PostMapping("/generate-test-violations")
    public ResponseEntity<Map<String, String>> generateTestViolations() {
        testViolationGenerator.generateTestViolations();
        Map<String, String> response = new HashMap<>();
        response.put("success", "true");
        response.put("message", "Test violation records generated successfully!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @PostMapping("/upload-violations-to-blockchain")
    public ResponseEntity<Map<String, String>> uploadViolationsToBlockchain() {
        blockchainUploader.uploadViolationsToBlockchain();
        Map<String, String> response = new HashMap<>();
        response.put("success", "true");
        response.put("message", "Violations uploaded to blockchain successfully!");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
