/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80028 (8.0.28)
 Source Host           : localhost:3306
 Source Schema         : studyroom

 Target Server Type    : MySQL
 Target Server Version : 80028 (8.0.28)
 File Encoding         : 65001

 Date: 27/06/2026 18:13:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for appeal
-- ----------------------------
DROP TABLE IF EXISTS `appeal`;
CREATE TABLE `appeal`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '学号/工号',
  `violation_id` bigint NOT NULL COMMENT '违约ID（关联violation.id）',
  `appeal_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '申诉内容',
  `appeal_status` enum('pending','processing','approved','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'pending' COMMENT '申诉状态（待处理/处理中/已通过/已拒绝）',
  `processing_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '处理结果',
  `processed_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '处理人（管理员ID）',
  `processed_at` datetime NULL DEFAULT NULL COMMENT '处理时间',
  `transaction_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区块链交易哈希（处理结果上链）',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户id（user.id）',
  `block_height` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_appeal_user_id`(`stu_admin_id` ASC) USING BTREE,
  INDEX `appeal_ibfk_2`(`violation_id` ASC) USING BTREE,
  CONSTRAINT `appeal_ibfk_1` FOREIGN KEY (`stu_admin_id`) REFERENCES `user` (`stu_admin_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `appeal_ibfk_2` FOREIGN KEY (`violation_id`) REFERENCES `violation` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '申诉表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for area
-- ----------------------------
DROP TABLE IF EXISTS `area`;
CREATE TABLE `area`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `classroom_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '区域名称',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_classroom_id`(`classroom_name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '座位区域表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for blockchain_log
-- ----------------------------
DROP TABLE IF EXISTS `blockchain_log`;
CREATE TABLE `blockchain_log`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `operation_type` enum('reservation','check_in','release','violation','appeal','admin_operation') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型（预约/签到/释放座位/违约/申诉/管理员操作）',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `target_id` bigint NULL DEFAULT NULL COMMENT '操作目标ID（如预约ID、违约ID等）',
  `transaction_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '区块链交易哈希',
  `block_height` bigint NULL DEFAULT NULL COMMENT '区块高度',
  `operation_data` json NULL COMMENT '操作数据（JSON格式）',
  `status` enum('success','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'success' COMMENT '操作状态（成功/失败）',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户id（user.id）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_blockchain_log_transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_blockchain_log_operation_type`(`operation_type` ASC) USING BTREE,
  INDEX `blockchain_log_ibfk_1`(`stu_admin_id` ASC) USING BTREE,
  CONSTRAINT `blockchain_log_ibfk_1` FOREIGN KEY (`stu_admin_id`) REFERENCES `user` (`stu_admin_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 428 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '区块链操作日志表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for check_in
-- ----------------------------
DROP TABLE IF EXISTS `check_in`;
CREATE TABLE `check_in`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `reservation_id` bigint NOT NULL COMMENT '预约ID（关联reservation.id）',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '学号/工号（关联user.stu_admin_id）',
  `actual_check_in_time` datetime NOT NULL COMMENT '实际签到时间',
  `status` enum('checked_in','late','violated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'checked_in' COMMENT '签到状态（已签到/迟到/未签到）',
  `transaction_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区块链交易哈希',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户id（user.id）',
  `classroom_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区域名称',
  `seat_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '座位号',
  `block_height` bigint NULL DEFAULT NULL COMMENT '区块高度',
  `reservation_end_time` datetime(6) NULL DEFAULT NULL,
  `reservation_start_time` datetime(6) NULL DEFAULT NULL,
  `display` enum('TRUE','FALSE') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TRUE' COMMENT '是否显示：true-显示，false-不显示',
  `is_late` bit(1) NULL DEFAULT NULL,
  `check_in_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int NULL DEFAULT NULL,
  `deposit_refund_tx_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `reservation_id`(`reservation_id` ASC) USING BTREE,
  UNIQUE INDEX `UK_naw7ia6c13l7x8tklt1xjjjkh`(`check_in_id` ASC) USING BTREE,
  UNIQUE INDEX `transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_check_in_reservation_id`(`reservation_id` ASC) USING BTREE,
  INDEX `check_in_ibfk_2`(`stu_admin_id` ASC) USING BTREE,
  CONSTRAINT `check_in_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `check_in_ibfk_2` FOREIGN KEY (`stu_admin_id`) REFERENCES `user` (`stu_admin_id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 92 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '签到表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for event_log
-- ----------------------------
DROP TABLE IF EXISTS `event_log`;
CREATE TABLE `event_log`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `execution_time` datetime(6) NULL DEFAULT NULL,
  `affected_rows` int NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_execution_time`(`execution_time` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8165053 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for reservation
-- ----------------------------
DROP TABLE IF EXISTS `reservation`;
CREATE TABLE `reservation`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '学号/工号（关联user.stu_admin_id）',
  `seat_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '座位编号（关联seat.seat_number）',
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) NOT NULL,
  `status` enum('pending','reserved','confirmed','checked_in','completed','late','cancelled','violated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区块链预约交易哈希',
  `block_height` bigint NULL DEFAULT NULL COMMENT '区块高度',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `seat_id` bigint NOT NULL COMMENT '座位id（seat.id）',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户id（user.id）',
  `classroom_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区域号',
  `reservation_date` date NOT NULL COMMENT '预约日期',
  `display` enum('TRUE','FALSE') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TRUE' COMMENT '是否显示：true-显示，false-不显示',
  `deposit_amount` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `deposit_tx_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_reservation_user_id`(`stu_admin_id` ASC) USING BTREE,
  INDEX `idx_reservation_seat_id`(`seat_number` ASC) USING BTREE,
  INDEX `idx_reservation_start_time`(`start_time` ASC) USING BTREE,
  INDEX `idx_reservation_end_time`(`end_time` ASC) USING BTREE,
  INDEX `FKewd3sohjspqf2sjjvdcmcefpb`(`seat_id` ASC) USING BTREE,
  CONSTRAINT `fk_reservation_1` FOREIGN KEY (`stu_admin_id`) REFERENCES `user` (`stu_admin_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_reservation_2` FOREIGN KEY (`seat_number`) REFERENCES `seat` (`seat_number`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKewd3sohjspqf2sjjvdcmcefpb` FOREIGN KEY (`seat_id`) REFERENCES `seat` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 230 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '预约表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for seat
-- ----------------------------
DROP TABLE IF EXISTS `seat`;
CREATE TABLE `seat`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `seat_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '座位编号',
  `classroom_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '区域',
  `row` int NOT NULL COMMENT '行号(关联row.row_number)',
  `column` int NOT NULL COMMENT '列号(关联column.column_number)',
  `status` enum('available','reserved','used','maintenance') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '座位描述',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `classroom_id` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `seat_number`(`seat_number` ASC) USING BTREE,
  INDEX `idx_seat_status`(`status` ASC) USING BTREE,
  INDEX `fk_seat_row`(`row` ASC) USING BTREE,
  INDEX `fk_seat_column`(`column` ASC) USING BTREE,
  INDEX `fk_seat_area`(`classroom_name` ASC) USING BTREE,
  CONSTRAINT `fk_seat_area` FOREIGN KEY (`classroom_name`) REFERENCES `area` (`classroom_name`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_seat_column` FOREIGN KEY (`column`) REFERENCES `seat_column` (`column_number`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_seat_row` FOREIGN KEY (`row`) REFERENCES `seat_row` (`row_number`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 268 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '座位表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for seat_column
-- ----------------------------
DROP TABLE IF EXISTS `seat_column`;
CREATE TABLE `seat_column`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `column_number` int NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_column_number`(`column_number` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 62 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '座位列号表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for seat_row
-- ----------------------------
DROP TABLE IF EXISTS `seat_row`;
CREATE TABLE `seat_row`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '行号id',
  `row_number` int NOT NULL COMMENT '座位行号',
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_row_number`(`row_number` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '座位行号表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户唯一标识（用户学号或管理员账号）',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码（加密存储）',
  `role` enum('student','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '角色（学生/管理员）',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '学号/工号',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  `wallet_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '钱包地址（学生可选）',
  `status` enum('enabled','disabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `balance` decimal(10, 2) NULL DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `user_id`(`user_id` ASC) USING BTREE,
  UNIQUE INDEX `wallet_address`(`wallet_address` ASC) USING BTREE,
  INDEX `idx_user_role`(`role` ASC) USING BTREE,
  INDEX `stu_admin_id`(`stu_admin_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for violation
-- ----------------------------
DROP TABLE IF EXISTS `violation`;
CREATE TABLE `violation`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stu_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户学号/工号（关联user.stu_admin_id）',
  `reservation_id` bigint NOT NULL COMMENT '预约ID（关联reservation.id）',
  `violation_type` enum('long_late','no_show','early_leave','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区块链违约哈希',
  `created_at` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `status` enum('unpaid','paid','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户id（user.id）',
  `violation_time` datetime(6) NOT NULL,
  `classroom_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '区域',
  `seat_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '座位号',
  `block_height` bigint NULL DEFAULT NULL COMMENT '区块高度',
  `deposit_amount` enum('1','3','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '1',
  `penalty_amount` decimal(10, 2) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `transaction_hash`(`transaction_hash` ASC) USING BTREE,
  INDEX `idx_violation_user_id`(`stu_admin_id` ASC) USING BTREE,
  INDEX `violation_ibfk_2`(`reservation_id` ASC) USING BTREE,
  CONSTRAINT `violation_ibfk_1` FOREIGN KEY (`stu_admin_id`) REFERENCES `user` (`stu_admin_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `violation_ibfk_2` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 72 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '违约记录表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Event structure for event_auto_update_reservation_and_record_violation
-- ----------------------------
DROP EVENT IF EXISTS `event_auto_update_reservation_and_record_violation`;
delimiter ;;
CREATE EVENT `event_auto_update_reservation_and_record_violation`
ON SCHEDULE
EVERY '1' SECOND STARTS '2026-01-08 20:51:22'
DO BEGIN
    DECLARE update_count INT DEFAULT 0;
    DECLARE log_message VARCHAR(255);
    
    -- ========================================================================
    -- 第一部分：将过期的预约状态从 reserved 更新为 late
    -- 条件：预约开始时间 < 当前时间 < 预约开始时间 + 30分钟
    -- ========================================================================
    UPDATE reservation
    SET status = 'late',
        updated_at = NOW(6)
    WHERE status = 'reserved'
      AND start_time < NOW(6)
      AND DATE_ADD(start_time, INTERVAL 30 MINUTE) > NOW(6);
    
    SET update_count = ROW_COUNT();
    SET log_message = CONCAT('第一部分: reserved→late, 影响行数=', update_count);
    
    INSERT INTO event_log (event_name, execution_time, affected_rows, message)
    VALUES ('event_auto_update_reservation_and_record_violation', NOW(6), update_count, log_message);
    
    -- ========================================================================
    -- 第二部分：将超时的预约状态从 late 更新为 violated，并记录违约
    -- 条件：当前时间 > 预约开始时间 + 30分钟
    -- ========================================================================
    
    -- 创建临时表存储需要处理的预约
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_violated_reservations (
        reservation_id BIGINT,
        user_id VARCHAR(50),
        stu_admin_id VARCHAR(50),
        seat_number VARCHAR(50),
        classroom_name VARCHAR(100),
        violation_time DATETIME(6),
        deposit_amount ENUM('1', '3', '5')
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    
    -- 清空临时表
    TRUNCATE TABLE temp_violated_reservations;
    
    -- 插入需要处理的预约到临时表
    INSERT INTO temp_violated_reservations (
        reservation_id,
        user_id,
        stu_admin_id,
        seat_number,
        classroom_name,
        violation_time,
        deposit_amount
    )
    SELECT 
        id AS reservation_id,
        user_id,
        stu_admin_id,
        seat_number,
        classroom_name,
        start_time AS violation_time,
        deposit_amount
    FROM reservation
    WHERE status = 'late'
      AND DATE_ADD(start_time, INTERVAL 30 MINUTE) <= NOW(6);
    
    -- 更新预约状态为 violated
    UPDATE reservation r
    INNER JOIN temp_violated_reservations t ON r.id = t.reservation_id
    SET r.status = 'violated',
        r.updated_at = NOW(6);
    
    SET update_count = ROW_COUNT();
    SET log_message = CONCAT('第二部分: late→violated, 影响行数=', update_count);
    
    INSERT INTO event_log (event_name, execution_time, affected_rows, message)
    VALUES ('event_auto_update_reservation_and_record_violation', NOW(6), update_count, log_message);
    
    -- 向violation表插入违约记录
    INSERT INTO violation (
        user_id,
        reservation_id,
        violation_type,
        violation_time,
        status,
        seat_number,
        classroom_name,
        stu_admin_id,
        deposit_amount,
        created_at,
        penalty_amount
    )
    SELECT 
        user_id,
        reservation_id,
        'long_late' AS violation_type,
        violation_time,
        'unpaid' AS status,
        seat_number,
        classroom_name,
        stu_admin_id,
        deposit_amount,
        NOW(6) AS created_at,
        CAST(deposit_amount AS DECIMAL(10,2)) AS penalty_amount
    FROM temp_violated_reservations;
    
    SET update_count = ROW_COUNT();
    SET log_message = CONCAT('第二部分: 插入违约记录, 影响行数=', update_count);
    
    INSERT INTO event_log (event_name, execution_time, affected_rows, message)
    VALUES ('event_auto_update_reservation_and_record_violation', NOW(6), update_count, log_message);
    
    -- 删除临时表
    DROP TEMPORARY TABLE IF EXISTS temp_violated_reservations;
    
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table reservation
-- ----------------------------
DROP TRIGGER IF EXISTS `after_reservation_reserved`;
delimiter ;;
CREATE TRIGGER `after_reservation_reserved` AFTER INSERT ON `reservation` FOR EACH ROW BEGIN
    -- 检查预约状态是否为'reserved'(已预约)
    IF NEW.status = 'reserved' THEN
        -- 更新对应座位状态为'reserved'(已预约)
        UPDATE seat 
        SET status = 'reserved' 
        WHERE id = NEW.seat_id;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table reservation
-- ----------------------------
DROP TRIGGER IF EXISTS `after_reservation_1`;
delimiter ;;
CREATE TRIGGER `after_reservation_1` AFTER UPDATE ON `reservation` FOR EACH ROW BEGIN
    -- 检查状态是否从非completed状态变为completed状态
    IF OLD.status != 'completed' AND NEW.status = 'completed' THEN
        -- 更新对应座位状态为available
        UPDATE seat 
        SET status = 'available' 
        WHERE id = NEW.seat_id;
    END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table reservation
-- ----------------------------
DROP TRIGGER IF EXISTS `after_reservation_status_to_reserved`;
delimiter ;;
CREATE TRIGGER `after_reservation_status_to_reserved` AFTER UPDATE ON `reservation` FOR EACH ROW BEGIN
    -- 检查状态是否从非reserved状态变为reserved状态
    IF OLD.status != 'reserved' AND NEW.status = 'reserved' THEN
        -- 更新对应座位状态为'reserved'(已预约)
        UPDATE seat 
        SET status = 'reserved' 
        WHERE id = NEW.seat_id;
    END IF;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
