package com.example.studyroom.service;

import com.example.studyroom.model.Violation;
import java.util.List;
import java.util.Optional;

public interface ViolationService {
    List<Violation> getAllViolations();
    Optional<Violation> getViolationById(Long id);
    Optional<Violation> getViolationByReservationId(Long reservationId);
    List<Violation> getViolationsByUserId(String userId);
    List<Violation> getViolationsByStatus(Violation.Status status);
    List<Violation> getViolationsByViolationType(Violation.ViolationType violationType);
    List<Violation> getViolationsByUserIdAndStatus(String userId, Violation.Status status);
    Optional<Violation> getViolationByTransactionHash(String transactionHash);
    Violation createViolation(Violation violation);
    Violation updateViolation(Long id, Violation violation);
    void deleteViolation(Long id);
    boolean existsByReservationId(Long reservationId);
    void deleteViolationByReservationId(Long reservationId);
    
    /**
     * 提取违约押金
     * @param violationId 违约记录ID
     * @param amount 提取金额
     * @param walletAddress 接收地址
     * @return 交易哈希
     */
    String withdrawDeposit(Long violationId, String amount, String walletAddress);
}