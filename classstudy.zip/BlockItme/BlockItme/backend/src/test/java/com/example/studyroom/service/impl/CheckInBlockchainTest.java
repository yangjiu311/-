package com.example.studyroom.service.impl;

import com.example.studyroom.model.*;
import com.example.studyroom.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class CheckInBlockchainTest {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private CheckInService checkInService;

    @Autowired
    private UserService userService;

    @Autowired
    private SeatService seatService;

    @Autowired
    private AreaService areaService;

    private User testUser;
    private Reservation testReservation;
    private Seat testSeat;

    @BeforeEach
    void setUp() {
        // 创建测试用户
        testUser = User.builder()
                .userId("test_user_" + System.currentTimeMillis())
                .password("password123")
                .name("Test User")
                .studentId("20240001")
                .balance(new BigDecimal(100))
                .status(User.Status.enabled)
                .role(User.Role.student)
                .createdAt(LocalDateTime.now())
                .build();
        testUser = userService.createUser(testUser);

        // 创建测试区域（教室）
        Area testArea = new Area();
        testArea.setClassroomName("A1教室");
        testArea = areaService.createArea(testArea);

        // 创建测试座位
        testSeat = new Seat();
        testSeat.setClassroomId(testArea.getId());
        testSeat.setClassroomName(testArea.getClassroomName());
        testSeat.setRow(1);
        testSeat.setColumn(1);
        testSeat.setSeatNumber("A1-01");
        testSeat.setStatus(Seat.Status.available);
        testSeat.setCreatedAt(LocalDateTime.now());
        testSeat = seatService.createSeat(testSeat);

        // 创建测试预约
        LocalDateTime now = LocalDateTime.now();
        testReservation = new Reservation();
        testReservation.setUserId(testUser.getUserId());
        testReservation.setStuAdminId(testUser.getStudentId());
        testReservation.setSeatId(testSeat.getId()); // 使用创建的座位ID
        testReservation.setSeatNumber(testSeat.getSeatNumber());
        testReservation.setStartTime(now.minusHours(1));
        testReservation.setEndTime(now.plusHours(2));
        testReservation.setReservationDate(LocalDate.now());
        testReservation.setStatus(Reservation.Status.confirmed);
        testReservation.setClassroomName(testSeat.getClassroomName());
        testReservation.setDepositAmount("50"); // 设置押金为50
        testReservation.setCreatedAt(LocalDateTime.now());
        testReservation = reservationService.createReservation(testReservation);
    }

    @Test
    void testCheckInWithBlockchainAndDepositRefund() {
        // 执行签到
        Reservation checkedInReservation = reservationService.checkInReservation(testReservation.getId());

        // 验证预约状态已更新为已签到
        assertEquals(Reservation.Status.checked_in, checkedInReservation.getStatus());

        // 验证签到记录已创建
        Optional<CheckIn> checkInOptional = checkInService.getCheckInByReservationId(testReservation.getId());
        assertTrue(checkInOptional.isPresent());

        CheckIn checkIn = checkInOptional.get();
        // 验证签到记录的基本信息
        assertEquals(testReservation.getId(), checkIn.getReservationId());
        assertEquals(testUser.getUserId(), checkIn.getUserId());
        assertEquals(testUser.getStudentId(), checkIn.getStuAdminId());

        // 验证区块链上链信息
        assertNotNull(checkIn.getTransactionHash());
        assertNotNull(checkIn.getBlockHeight());
        assertTrue(checkIn.getTransactionHash().length() > 0);
        assertTrue(checkIn.getBlockHeight() > 0);

        // 验证押金已退还
        Optional<User> updatedUserOptional = userService.getUserByUserId(testUser.getUserId());
        assertTrue(updatedUserOptional.isPresent());

        User updatedUser = updatedUserOptional.get();
        // 初始余额100，预约时扣除50，签到时退还50，所以最终余额应该是100
        assertEquals(new BigDecimal(100), updatedUser.getBalance());

        System.out.println("签到上链和押金退还测试成功！");
        System.out.println("签到记录ID: " + checkIn.getId());
        System.out.println("交易哈希: " + checkIn.getTransactionHash());
        System.out.println("区块高度: " + checkIn.getBlockHeight());
        System.out.println("用户余额: " + updatedUser.getBalance());
    }
}
