package com.example.studyroom.service.impl;

import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.model.Violation;
import com.example.studyroom.repository.ViolationRepository;
import com.example.studyroom.repository.ReservationRepository;
import com.example.studyroom.service.BlockchainService;
import com.example.studyroom.service.ViolationService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ViolationServiceImpl implements ViolationService {
    private final ViolationRepository violationRepository;
    private final ReservationRepository reservationRepository;
    private final BlockchainService blockchainService;

    @Override
    public List<Violation> getAllViolations() {
        return violationRepository.findAll();
    }

    @Override
    public Optional<Violation> getViolationById(@NonNull Long id) {
        return violationRepository.findById(id);
    }

    @Override
    public Optional<Violation> getViolationByReservationId(@NonNull Long reservationId) {
        return violationRepository.findByReservationId(reservationId);
    }

    @Override
    public List<Violation> getViolationsByUserId(@NonNull String userId) {
        return violationRepository.findByUserId(userId);
    }

    @Override
    public List<Violation> getViolationsByStatus(@NonNull Violation.Status status) {
        return violationRepository.findByStatus(status);
    }

    @Override
    public List<Violation> getViolationsByViolationType(@NonNull Violation.ViolationType violationType) {
        return violationRepository.findByViolationType(violationType);
    }

    @Override
    public List<Violation> getViolationsByUserIdAndStatus(@NonNull String userId, @NonNull Violation.Status status) {
        return violationRepository.findByUserIdAndStatus(userId, status);
    }

    @Override
    public Optional<Violation> getViolationByTransactionHash(@NonNull String transactionHash) {
        return violationRepository.findByTransactionHash(transactionHash);
    }

    @Override
    public Violation createViolation(@NonNull Violation violation) {
        try {
            System.out.println("Creating violation: " + violation);
            // 设置默认值
            if (violation.getCreatedAt() == null) {
                violation.setCreatedAt(LocalDateTime.now());
            }
            if (violation.getUpdatedAt() == null) {
                violation.setUpdatedAt(LocalDateTime.now());
            }
            if (violation.getStuAdminId() == null) {
            // 如果stu_admin_id为null，使用现有的管理员ID
            violation.setStuAdminId("202211000");
        }
            
            // 先生成临时ID用于上链
            String tempId = "temp_" + System.currentTimeMillis();
            String stuAdminId = violation.getStuAdminId() != null ? violation.getStuAdminId() : "system";
            String userId = violation.getUserId() != null ? violation.getUserId() : "unknown";
            
            System.out.println("Uploading to blockchain first...");
            BlockchainLog log = blockchainService.uploadToBlockchain(
                    violation,
                    userId,
                    stuAdminId,
                    0L, // 使用临时ID
                    BlockchainLog.OperationType.violation
            );
            System.out.println("Blockchain upload result: " + log);
            
            // 上链成功后再保存到数据库
            violation.setTransactionHash(log.getTransactionHash());
            violation.setBlockHeight(log.getBlockHeight());
            Violation saved = violationRepository.save(violation);
            System.out.println("Violation saved to database with blockchain info: " + saved);
            
            return saved;
        } catch (Exception e) {
            System.out.println("Violation creation failed: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public Violation updateViolation(@NonNull Long id, @NonNull Violation violation) {
        Optional<Violation> existingViolationOpt = violationRepository.findById(id);
        if (existingViolationOpt.isPresent()) {
            Violation existingViolation = existingViolationOpt.get();
            violation.setId(id);
            
            // 保留原有的字段值
            if (violation.getUserId() == null) {
                violation.setUserId(existingViolation.getUserId());
            }
            if (violation.getStuAdminId() == null) {
                violation.setStuAdminId(existingViolation.getStuAdminId());
            }
            if (violation.getReservationId() == null) {
                violation.setReservationId(existingViolation.getReservationId());
            }
            if (violation.getViolationType() == null) {
                violation.setViolationType(existingViolation.getViolationType());
            }
            if (violation.getViolationTime() == null) {
                violation.setViolationTime(existingViolation.getViolationTime());
            }
            if (violation.getStatus() == null) {
                violation.setStatus(existingViolation.getStatus());
            }
            if (violation.getPenaltyAmount() == null) {
                violation.setPenaltyAmount(existingViolation.getPenaltyAmount());
            }
            if (violation.getSeatNumber() == null) {
                violation.setSeatNumber(existingViolation.getSeatNumber());
            }
            if (violation.getClassroomName() == null) {
                violation.setClassroomName(existingViolation.getClassroomName());
            }
            if (violation.getCreatedAt() == null) {
                violation.setCreatedAt(existingViolation.getCreatedAt());
            }
            if (violation.getUpdatedAt() == null) {
                violation.setUpdatedAt(existingViolation.getUpdatedAt());
            }
            if (violation.getTransactionHash() == null) {
                violation.setTransactionHash(existingViolation.getTransactionHash());
            }
            if (violation.getBlockHeight() == null) {
                violation.setBlockHeight(existingViolation.getBlockHeight());
            }
            
            // 检查是否需要上链
            if (violation.getUploadToBlockchain() != null && violation.getUploadToBlockchain()) {
                // 检查是否已经上链
                if (existingViolation.getTransactionHash() != null && existingViolation.getBlockHeight() != null) {
                    System.out.println("Violation already uploaded to blockchain, skipping upload: " + existingViolation.getTransactionHash());
                    // 保留原有的上链信息
                    violation.setTransactionHash(existingViolation.getTransactionHash());
                    violation.setBlockHeight(existingViolation.getBlockHeight());
                } else {
                    System.out.println("Uploading violation to blockchain...");
                    // 确保stuAdminId不为null
                    String stuAdminId = violation.getStuAdminId() != null ? violation.getStuAdminId() : violation.getUserId();
                    // 确保userId不为null
                    String userId = violation.getUserId() != null ? violation.getUserId() : "unknown";
                    try {
                        BlockchainLog blockchainLog = blockchainService.uploadToBlockchain(
                            violation,
                            userId,
                            stuAdminId,
                            violation.getId(),
                            BlockchainLog.OperationType.violation
                        );
                        
                        // 保存上链结果到violation对象
                        violation.setTransactionHash(blockchainLog.getTransactionHash());
                        violation.setBlockHeight(blockchainLog.getBlockHeight());
                        System.out.println("Blockchain upload completed: " + blockchainLog.getTransactionHash());
                    } catch (Exception e) {
                        System.out.println("Blockchain upload failed: " + e.getMessage());
                        e.printStackTrace();
                        // 上链失败但继续更新操作
                    }
                }
            }
            
            return violationRepository.save(violation);
        } else {
            throw new RuntimeException("Violation not found with id: " + id);
        }
    }

    @Override
    public void deleteViolation(@NonNull Long id) {
        // 获取违约记录以找到关联的预约ID
        Optional<Violation> violationOpt = violationRepository.findById(id);
        if (violationOpt.isPresent()) {
            Violation violation = violationOpt.get();
            Long reservationId = violation.getReservationId();
            
            // 删除违约记录
            violationRepository.deleteById(id);
            
            // 如果有关联的预约记录，将预约记录软删除（display字段改为false）
            if (reservationId != null) {
                reservationRepository.updateDisplayByReservationId(reservationId, false);
            }
        }
    }

    @Override
    public boolean existsByReservationId(@NonNull Long reservationId) {
        return violationRepository.existsByReservationId(reservationId);
    }

    @Override
    public void deleteViolationByReservationId(@NonNull Long reservationId) {
        Optional<Violation> violation = violationRepository.findByReservationId(reservationId);
        if (violation.isPresent()) {
            violationRepository.delete(violation.get());
        }
    }

    @Override
    public String withdrawDeposit(Long violationId, String amount, String walletAddress) {
        Optional<Violation> violationOpt = violationRepository.findById(violationId);
        if (violationOpt.isPresent()) {
            Violation violation = violationOpt.get();
            
            // 创建提取押金的交易数据
            String transactionData = String.format(
                "Withdraw deposit: violationId=%d, amount=%s ETH, wallet=%s",
                violationId, amount, walletAddress
            );
            
            // 生成交易哈希
            String transactionHash = blockchainService.generateTransactionHash(transactionData);
            
            // 更新违约记录状态为已提取
            violation.setStatus(Violation.Status.paid);
            violation.setUpdatedAt(LocalDateTime.now());
            
            // 保存更新后的违约记录
            violationRepository.save(violation);
            
            return transactionHash;
        } else {
            throw new RuntimeException("Violation not found with id: " + violationId);
        }
    }
}
