<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>签到记录</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 统计卡片区域 -->
      <section class="stats-cards">
        <div class="stat-card">
          <div class="card-icon checked-in-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <polyline points="22 4 12 14.01 9 11.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>准时签到</h3>
            <p class="stat-value">{{ stats.onTimeCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon late-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="10" stroke="white" stroke-width="2"/>
              <path d="M12 8v4l3 3" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>迟到记录</h3>
            <p class="stat-value">{{ stats.lateCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon total-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="12" cy="12" r="10" stroke="white" stroke-width="2"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>总签到次数</h3>
            <p class="stat-value">{{ stats.totalCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon rate-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2v20M2 12h20" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>准时率</h3>
            <p class="stat-value">{{ stats.onTimeRate }}%</p>
          </div>
        </div>
      </section>

      <!-- 过滤栏区域 -->
      <section class="filter-section">
        <div class="filter-bar">
          <div class="filter-group">
            <label for="status-filter">签到状态</label>
            <select id="status-filter" class="form-control status-select" v-model="statusFilter">
              <option value="">全部状态</option>
              <option value="checked_in">准时签到</option>
              <option value="late">迟到</option>
              <option value="missed">未签到</option>
            </select>
          </div>
          <div class="filter-group">
            <label for="date-filter">日期范围</label>
            <input type="date" id="date-filter" class="form-control" v-model="dateFilter" />
          </div>
          <div class="filter-actions">
            <button class="primary-btn filter-btn" @click="searchCheckIns">查询</button>
            <button class="secondary-btn reset-btn" @click="resetFilters">重置</button>
          </div>
        </div>
      </section>

      <!-- 签到记录列表区域 -->
      <section class="checkins-section">
        <div class="checkins-card">
          <h2>我的签到记录</h2>
          <div class="checkins-list">
            <table class="checkins-table">
              <thead>
                <tr>
                  <th>签到ID</th>
                  <th>预约ID</th>
                  <th>座位号</th>
                  <th>签到时间</th>
                  <th>预约开始时间</th>
                  <th>预约结束时间</th>
                  <th class="hash-column">签到哈希</th>
                  <th class="hash-column">区块高度</th>
                  <th class="status-column">状态</th>
                  <th class="actions-column">操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="loading">
                  <td colspan="10" class="loading-text">加载中...</td>
                </tr>
                <tr v-else-if="error">
                  <td colspan="10" class="error-text">{{ error }}</td>
                </tr>
                <tr v-else-if="checkins.length === 0">
                  <td colspan="10" class="empty-text">暂无签到记录</td>
                </tr>
                <tr v-for="checkin in checkins" :key="checkin.id">
                  <td>{{ checkin.id }}</td>
                  <td>{{ checkin.reservationId }}</td>
                  <td>{{ checkin.seatNumber }}</td>
                  <td>{{ formatDateTime(checkin.actualCheckInTime) }}</td>
                  <td>{{ formatDateTime(checkin.reservationStartTime) }}</td>
                  <td>{{ formatDateTime(checkin.reservationEndTime) }}</td>
                  <td class="hash-text">{{ checkin.transactionHash }}</td>
                  <td>{{ checkin.blockHeight }}</td>
                  <td class="status-column">
                    <span :class="['status', checkin.status.toLowerCase()]">
                      {{ checkin.status === 'checked_in' ? '准时签到' : 
                         checkin.status === 'late' ? '迟到' : 
                         checkin.status === 'missed' ? '未签到' : checkin.status }}
                    </span>
                  </td>
                  <td class="actions-column">
                    <button class="btn-view" @click="viewCheckIn(checkin.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      查看
                    </button>
                    <button class="btn-delete" @click="confirmDeleteCheckIn(checkin.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10 11v6M14 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      删除
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- 签到查看功能框 -->
      <div v-if="showViewModal" class="modal-overlay">
        <div class="view-modal">
          <div class="modal-header">
            <h3>签到记录详情</h3>
            <button class="close-btn" @click="showViewModal = false">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
          <div class="modal-body" v-if="selectedCheckIn">
            <div class="checkin-detail-item">
              <span class="detail-label">签到ID:</span>
              <span class="detail-value">{{ selectedCheckIn.id }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">预约ID:</span>
              <span class="detail-value">{{ selectedCheckIn.reservationId }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">座位号:</span>
              <span class="detail-value">{{ selectedCheckIn.seatNumber }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">签到时间:</span>
              <span class="detail-value">{{ formatDateTime(selectedCheckIn.actualCheckInTime) }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">预约开始时间:</span>
              <span class="detail-value">{{ formatDateTime(selectedCheckIn.reservationStartTime) }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">预约结束时间:</span>
              <span class="detail-value">{{ formatDateTime(selectedCheckIn.reservationEndTime) }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">签到状态:</span>
              <span class="detail-value">
                <span :class="['status', selectedCheckIn.status.toLowerCase()]">
                  {{ selectedCheckIn.status === 'checked_in' ? '准时签到' : 
                     selectedCheckIn.status === 'late' ? '迟到' : 
                     selectedCheckIn.status === 'missed' ? '未签到' : selectedCheckIn.status }}
                </span>
              </span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">押金退还哈希:</span>
              <span class="detail-value hash-text">{{ selectedCheckIn.depositRefundTxHash || '无' }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">签到哈希:</span>
              <span class="detail-value hash-text">{{ selectedCheckIn.transactionHash }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">区块高度:</span>
              <span class="detail-value">{{ selectedCheckIn.blockHeight }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">教室名称:</span>
              <span class="detail-value">{{ selectedCheckIn.classroomName }}</span>
            </div>
            <div class="checkin-detail-item">
              <span class="detail-label">创建时间:</span>
              <span class="detail-value">{{ formatDateTime(selectedCheckIn.createdAt) }}</span>
            </div>
            
            <!-- 区块链日志信息 -->
            <div v-if="selectedCheckIn.transactionHash">
              <div class="blockchain-log-info">
                <div class="log-item">
                  <span class="log-label">交易哈希:</span>
                  <span class="log-value" style="word-break: break-all; font-family: monospace; font-size: 12px;">{{ selectedCheckIn.transactionHash }}</span>
                </div>
                <div v-if="blockchainLogLoading" class="loading-info">
                  加载区块链日志中...
                </div>
                <div v-else-if="blockchainLogError" class="error-info">
                  {{ blockchainLogError }}
                </div>
                <div v-else-if="blockchainLogData" class="blockchain-log-details">
                  <div class="log-item">
                    <span class="log-label">区块高度:</span>
                    <span class="log-value">{{ blockchainLogData.blockHeight || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">操作类型:</span>
                    <span class="log-value">{{ blockchainLogData.operationType || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">状态:</span>
                    <span class="log-value">{{ blockchainLogData.status || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">创建时间:</span>
                    <span class="log-value">{{ blockchainLogData.createdAt ? new Date(blockchainLogData.createdAt).toLocaleString('zh-CN') : '-' }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="primary-btn" @click="showViewModal = false">关闭</button>
          </div>
        </div>
      </div>


    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import axios from 'axios'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)



// 过滤条件
const statusFilter = ref('')
const dateFilter = ref('')

// 加载状态
const loading = ref(false)
const error = ref('')

// 签到记录列表
const checkins = ref([])

// 统计数据
const stats = ref({
  onTimeCount: 0,
  lateCount: 0,
  totalCount: 0,
  onTimeRate: 0
})



// 查看详情相关
const showViewModal = ref(false)
const selectedCheckIn = ref(null)
const blockchainLogLoading = ref(false)
const blockchainLogError = ref('')
const blockchainLogData = ref(null)

// 组件挂载时获取签到记录
onMounted(() => {
  fetchUserCheckIns()
})

// 获取用户签到记录
const fetchUserCheckIns = async () => {
  loading.value = true
  error.value = ''
  
  try {
    // 使用userId字段（字符串类型）来获取用户签到记录
    const userId = userStore.userInfo?.userId
    if (!userId) {
      error.value = '用户信息不完整，请重新登录'
      loading.value = false
      return
    }
    
    // 调用新的API，只获取display为true的签到记录（使用查询参数）
    const response = await axios.get(`/api/check-ins/user/${userId}/display?display=true`)
    
    let allCheckIns = response.data || []
    
    // 应用过滤条件
    if (statusFilter.value) {
      allCheckIns = allCheckIns.filter(c => c.status === statusFilter.value)
    }
    
    if (dateFilter.value) {
      allCheckIns = allCheckIns.filter(c => {
        const checkInDate = new Date(c.actualCheckInTime).toISOString().split('T')[0]
        return checkInDate === dateFilter.value
      })
    }
    
    // 计算统计数据
    const totalCount = allCheckIns.length
    const onTimeCount = allCheckIns.filter(c => c.status === 'checked_in').length
    const lateCount = allCheckIns.filter(c => c.status === 'late').length
    const onTimeRate = totalCount > 0 ? Math.round((onTimeCount / totalCount) * 100) : 0
    
    stats.value = {
      onTimeCount,
      lateCount,
      totalCount,
      onTimeRate
    }
    
    // 直接显示所有数据，移除分页
    checkins.value = allCheckIns
  } catch (err) {
    console.error('获取签到记录失败:', err)
    error.value = '获取签到记录失败，请稍后重试'
  } finally {
    loading.value = false
  }
}

// 查询签到记录
const searchCheckIns = () => {
  fetchUserCheckIns()
}

// 重置过滤条件
const resetFilters = () => {
  statusFilter.value = ''
  dateFilter.value = ''
  fetchUserCheckIns()
}

// 查看签到详情
const viewCheckIn = async (checkInId) => {
  selectedCheckIn.value = checkins.value.find(c => c.id === checkInId)
  showViewModal.value = true
  
  // 加载区块链日志
  if (selectedCheckIn.value && selectedCheckIn.value.transactionHash) {
    blockchainLogLoading.value = true
    blockchainLogError.value = ''
    blockchainLogData.value = null
    
    try {
      const response = await axios.get(`/api/blockchain-logs/transaction/${selectedCheckIn.value.transactionHash}`)
      blockchainLogData.value = response.data
    } catch (err) {
      console.error('获取区块链日志失败:', err)
      blockchainLogError.value = '获取区块链日志失败'
    } finally {
      blockchainLogLoading.value = false
    }
  }
}

// 确认删除签到记录
const confirmDeleteCheckIn = async (checkInId) => {
  if (confirm('确定要删除这条签到记录吗？此操作不可恢复。')) {
    try {
      // 调用新的API，将display字段设置为FALSE
      await axios.put(`/api/check-ins/${checkInId}/display`, 'false', {
        headers: {
          'Content-Type': 'text/plain'
        }
      })
      // 刷新签到记录列表
      fetchUserCheckIns()
      alert('删除成功！')
    } catch (err) {
      console.error('删除签到记录失败:', err)
      alert('删除失败，请稍后重试')
    }
  }
}



// 格式化日期时间
const formatDateTime = (dateTime) => {
  if (!dateTime) return '-'
  const date = new Date(dateTime)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

/* 用户下拉菜单样式 */
.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 统计卡片样式 */
.stats-cards {
  display: flex;
  gap: 20px;
  padding: 30px;
  flex-wrap: wrap;
}

.stat-card {
  flex: 1;
  min-width: 200px;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  align-items: center;
  gap: 15px;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.checked-in-icon {
  background-color: #4CAF50;
}

.late-icon {
  background-color: #FFC107;
}

.total-icon {
  background-color: #2196F3;
}

.rate-icon {
  background-color: #9C27B0;
}

.card-content h3 {
  margin: 0 0 5px 0;
  font-size: 14px;
  color: #7f8c8d;
  font-weight: 400;
}

.stat-value {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
}

/* 过滤栏样式 */
.filter-section {
  padding: 0 30px 20px 30px;
}

.filter-bar {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  gap: 20px;
  align-items: flex-end;
  flex-wrap: wrap;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.filter-group label {
  font-size: 14px;
  color: #495057;
  font-weight: 500;
}

.form-control {
  padding: 8px 12px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  outline: none;
  border-color: #4CAF50;
}

.status-select {
  min-width: 150px;
}

.filter-actions {
  display: flex;
  gap: 10px;
  margin-left: auto;
}

.filter-btn,
.reset-btn {
  padding: 8px 20px;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  border: none;
}

.filter-btn {
  background-color: #4CAF50;
  color: white;
}

.filter-btn:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.reset-btn {
  background-color: white;
  color: #6c757d;
  border: 1px solid #ced4da;
}

.reset-btn:hover {
  background-color: #f8f9fa;
  border-color: #adb5bd;
}

/* 签到记录列表样式 */
.checkins-section {
  padding: 0 30px 20px 30px;
}

.checkins-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.checkins-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.checkins-list {
  overflow-x: auto;
}

.checkins-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

.checkins-table th,
.checkins-table td {
  padding: 12px;
  text-align: center;
  border-bottom: 1px solid #e0e0e0;
}

.checkins-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
  white-space: nowrap;
}

.checkins-table tbody tr:hover {
  background-color: #f8f9fa;
}

.loading-text,
.error-text,
.empty-text {
  text-align: center;
  padding: 40px;
  color: #6c757d;
}

.error-text {
  color: #dc3545;
}

.hash-text {
  font-family: 'Courier New', monospace;
  font-size: 12px;
  color: #6c757d;
  max-width: 150px;
  word-break: break-all;
  white-space: normal;
  line-height: 1.4;
  text-align: center;
  display: block;
  margin: 0 auto;
}

.hash-column {
  min-width: 150px;
}

/* 状态列样式 */
.status-column {
  min-width: 100px;
  white-space: nowrap;
}

.status {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
}

.status.checked_in {
  background-color: #d4edda;
  color: #155724;
}

.status.late {
  background-color: #fff3cd;
  color: #856404;
}

.status.missed {
  background-color: #f8d7da;
  color: #721c24;
}

/* 操作列样式 */
.actions-column {
  min-width: 80px;
  white-space: nowrap;
}

.btn-view {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-view:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.btn-delete {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-left: 4px;
}

.btn-delete:hover {
  background-color: #c82333;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.view-modal {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #6c757d;
  transition: color 0.3s ease;
}

.close-btn:hover {
  color: #dc3545;
}

.modal-body {
  padding: 20px;
}

.checkin-detail-item {
  display: flex;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.checkin-detail-item:last-child {
  border-bottom: none;
}

.detail-label {
  width: 120px;
  font-weight: 600;
  color: #495057;
}

.detail-value {
  flex: 1;
  color: #6c757d;
}

/* 区块链日志样式 */
.loading-info,
.error-info {
  padding: 10px;
  border-radius: 4px;
  font-size: 14px;
}

.loading-info {
  background-color: #e3f2fd;
  color: #1976d2;
}

.error-info {
  background-color: #ffebee;
  color: #d32f2f;
}

.blockchain-log-info {
  margin-top: 15px;
  padding: 15px;
  background-color: white;
  border-radius: 4px;
  text-align: left;
}

.log-item {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
}

.log-item:last-child {
  border-bottom: none;
}

.log-label {
  font-weight: 600;
  color: #495057;
}

.log-value {
  color: #6c757d;
}

.modal-footer {
  padding: 20px;
  border-top: 1px solid #e0e0e0;
  text-align: right;
}



/* 响应式设计 */
@media (max-width: 768px) {
  .user-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: auto;
  }

  .nav-menu {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    padding: 0;
  }

  .nav-item {
    flex: 0 0 auto;
  }

  .stats-cards {
    flex-direction: column;
  }

  .filter-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .filter-actions {
    margin-left: 0;
  }

  .checkins-table {
    font-size: 12px;
  }

  .hash-column {
    min-width: 100px;
  }

  .hash-text {
    max-width: 80px;
  }
}
</style>


















