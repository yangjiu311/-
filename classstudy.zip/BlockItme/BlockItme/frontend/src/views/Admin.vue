<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>仪表盘</span>
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位管理</span>
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>用户管理</span>
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>仪表盘</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">管理员</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/admin/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/admin/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 统计卡片区域 -->
      <section class="stats-cards">
        <div class="stat-card">
          <div class="card-icon seats-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="4" width="8" height="3" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <rect x="4" y="10" width="8" height="10" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M9 2v2" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M14 2v6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M20 2v6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <rect x="13" y="10" width="3" height="10" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <rect x="18" y="10" width="3" height="10" rx="1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>总座位数</h3>
            <p class="stat-value">{{ totalSeatsCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon available-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <polyline points="22 4 12 14.01 9 11.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>可用座位</h3>
            <p class="stat-value">{{ availableSeatsCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon reserved-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>已预约</h3>
            <p class="stat-value">{{ reservedSeatsCount }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="card-icon users-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="9" cy="7" r="4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>总用户数</h3>
            <p class="stat-value">{{ studentUsersCount }}</p>
          </div>
        </div>
      </section>

      <!-- 图表和数据区域 -->
      <section class="charts-section">
        <div class="chart-card">
          <h2>座位使用趋势</h2>
          <div class="chart-container">
            <VChart 
              class="chart"
              :option="seatUsageChartOption"
              autoresize
              :init-options="{ renderer: 'canvas' }"
            />
          </div>
        </div>
        <div class="chart-card">
          <h2>记录趋势</h2>
          <div class="chart-container">
            <VChart 
              class="chart"
              :option="checkInTrendChartOption"
              autoresize
              :init-options="{ renderer: 'canvas' }"
            />
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted, onUnmounted, watch } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import {
  BarChart,
  LineChart
} from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DatasetComponent,
  TransformComponent,
  LegendComponent,
  DataZoomComponent
} from 'echarts/components'
import { LabelLayout, UniversalTransition } from 'echarts/features'
import { CanvasRenderer } from 'echarts/renderers'
import { getTotalSeatsCount, getAvailableSeatsCount, getReservedSeatsCount, getUsedSeatsCount, getStudentUsersCount, getAllCheckIns, getAllReservations, getAllViolations, getAllAppeals } from '../services/api'

use([
  BarChart,
  LineChart,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DatasetComponent,
  TransformComponent,
  LegendComponent,
  DataZoomComponent,
  LabelLayout,
  UniversalTransition,
  CanvasRenderer
])

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const showDropdown = ref(false)
const totalSeatsCount = ref(120) // 默认值为120，与之前的静态值保持一致
const availableSeatsCount = ref(85) // 默认值为85，与之前的静态值保持一致
const reservedSeatsCount = ref(25) // 默认值为25，与之前的静态值保持一致
const usedSeatsCount = ref(10) // 默认值为10，与之前的静态值保持一致
const studentUsersCount = ref(500) // 默认值为500，与之前的静态值保持一致

// 图表配置
const seatUsageChartOption = ref({
  title: {
    text: '座位使用趋势',
    left: 'center'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'cross'
    }
  },
  legend: {
    data: ['可用座位', '已预约座位', '使用中座位'],
    bottom: 10
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '15%',
    top: '15%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: [],
    name: '时间'
  },
  yAxis: [
    {
      type: 'value',
      name: '座位数量',
      min: 0
    },
    {
      type: 'value',
      name: '使用率(%)',
      min: 0,
      max: 100,
      axisLabel: {
        formatter: '{value}%'
      }
    }
  ],
  series: [
    {
      name: '可用座位',
      type: 'bar',
      data: [],
      itemStyle: {
        color: '#52c41a'
      }
    },
    {
      name: '已预约座位',
      type: 'bar',
      data: [],
      itemStyle: {
        color: '#1890ff'
      }
    },
    {
      name: '使用中座位',
      type: 'bar',
      data: [],
      itemStyle: {
        color: '#faad14'
      }
    },
    {
      name: '使用率',
      type: 'line',
      data: [],
      yAxisIndex: 1,
      itemStyle: {
        color: '#f5222d'
      },
      lineStyle: {
        width: 2
      },
      symbol: 'circle',
      symbolSize: 6
    }
  ],
  dataZoom: [
    {
      type: 'inside',
      start: 0,
      end: 100
    },
    {
      start: 0,
      end: 100,
      bottom: 5
    }
  ]
})

// 图表数据
const timeData = ref([])
const availableData = ref([])
const reservedData = ref([])
const usedData = ref([])
const usageRateData = ref([])
const maxDataPoints = 20
let updateInterval = null

// 签到记录图表配置
const checkInTrendChartOption = ref({
  title: {
    text: '记录趋势',
    left: 'center'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'cross'
    }
  },
  legend: {
    data: ['签到次数', '预约次数', '违约次数', '申诉次数'],
    bottom: 10
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '15%',
    top: '15%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: [],
    name: '时间'
  },
  yAxis: {
    type: 'value',
    name: '次数',
    min: 0
  },
  series: [
    {
      name: '签到次数',
      type: 'line',
      data: [],
      itemStyle: {
        color: '#52c41a'
      },
      lineStyle: {
        width: 3
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [{
            offset: 0,
            color: 'rgba(82, 196, 26, 0.3)'
          }, {
            offset: 1,
            color: 'rgba(82, 196, 26, 0.1)'
          }]
        }
      },
      symbol: 'circle',
      symbolSize: 8
    },
    {
      name: '预约次数',
      type: 'line',
      data: [],
      itemStyle: {
        color: '#1890ff'
      },
      lineStyle: {
        width: 3
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [{
            offset: 0,
            color: 'rgba(24, 144, 255, 0.3)'
          }, {
            offset: 1,
            color: 'rgba(24, 144, 255, 0.1)'
          }]
        }
      },
      symbol: 'circle',
      symbolSize: 8
    },
    {
      name: '违约次数',
      type: 'line',
      data: [],
      itemStyle: {
        color: '#f5222d'
      },
      lineStyle: {
        width: 3
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [{
            offset: 0,
            color: 'rgba(245, 34, 45, 0.3)'
          }, {
            offset: 1,
            color: 'rgba(245, 34, 45, 0.1)'
          }]
        }
      },
      symbol: 'circle',
      symbolSize: 8
    },
    {
      name: '申诉次数',
      type: 'line',
      data: [],
      itemStyle: {
        color: '#722ed1'
      },
      lineStyle: {
        width: 3
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [{
            offset: 0,
            color: 'rgba(114, 46, 209, 0.3)'
          }, {
            offset: 1,
            color: 'rgba(114, 46, 209, 0.1)'
          }]
        }
      },
      symbol: 'circle',
      symbolSize: 8
    }
  ],
  dataZoom: [
    {
      type: 'inside',
      start: 0,
      end: 100
    },
    {
      start: 0,
      end: 100,
      bottom: 5
    }
  ]
})

// 签到记录图表数据
const checkInTimeData = ref([])
const checkInCountData = ref([])
const recentCheckIns = ref([])
const reservationCountData = ref([])
const recentReservations = ref([])
const violationCountData = ref([])
const recentViolations = ref([])
const appealCountData = ref([])
const recentAppeals = ref([])

// 获取总座位数
const fetchTotalSeatsCount = async () => {
  try {
    const count = await getTotalSeatsCount()
    totalSeatsCount.value = count
    console.log('总座位数:', count)
  } catch (error) {
    console.error('获取总座位数失败:', error)
    // 保持默认值
  }
}

// 获取可用座位数
const fetchAvailableSeatsCount = async () => {
  try {
    const count = await getAvailableSeatsCount()
    availableSeatsCount.value = count
    console.log('可用座位数:', count)
  } catch (error) {
    console.error('获取可用座位数失败:', error)
    // 保持默认值
  }
}

// 获取已预约座位数
const fetchReservedSeatsCount = async () => {
  try {
    const count = await getReservedSeatsCount()
    reservedSeatsCount.value = count
    console.log('已预约座位数:', count)
  } catch (error) {
    console.error('获取已预约座位数失败:', error)
    // 保持默认值
  }
}

// 获取使用中座位数
const fetchUsedSeatsCount = async () => {
  try {
    const count = await getUsedSeatsCount()
    usedSeatsCount.value = count
    console.log('使用中座位数:', count)
  } catch (error) {
    console.error('获取使用中座位数失败:', error)
    // 保持默认值
  }
}

// 获取学生用户数
const fetchStudentUsersCount = async () => {
  try {
    const count = await getStudentUsersCount()
    studentUsersCount.value = count
    console.log('学生用户数:', count)
  } catch (error) {
    console.error('获取学生用户数失败:', error)
    // 保持默认值
  }
}

// 获取签到记录
const fetchCheckIns = async () => {
  try {
    const checkIns = await getAllCheckIns()
    recentCheckIns.value = checkIns
    console.log('签到记录:', checkIns)
  } catch (error) {
    console.error('获取签到记录失败:', error)
    // 保持空数组
  }
}

// 获取预约记录
const fetchReservations = async () => {
  try {
    const reservations = await getAllReservations()
    recentReservations.value = reservations
    console.log('预约记录:', reservations)
  } catch (error) {
    console.error('获取预约记录失败:', error)
    // 保持空数组
  }
}

// 获取违约记录
const fetchViolations = async () => {
  try {
    const violations = await getAllViolations()
    recentViolations.value = violations
    console.log('违约记录:', violations)
  } catch (error) {
    console.error('获取违约记录失败:', error)
    // 保持空数组
  }
}

// 获取申诉记录
const fetchAppeals = async () => {
  try {
    const appeals = await getAllAppeals()
    recentAppeals.value = appeals
    console.log('申诉记录:', appeals)
  } catch (error) {
    console.error('获取申诉记录失败:', error)
    // 保持空数组
  }
}

// 更新签到记录图表数据
const updateCheckInChartData = () => {
  const now = new Date()
  const timeStr = now.getHours() + ':' + (now.getMinutes() < 10 ? '0' : '') + now.getMinutes() + ':' + (now.getSeconds() < 10 ? '0' : '') + now.getSeconds()
  
  checkInTimeData.value.push(timeStr)
  // 使用真实签到记录数据，从recentCheckIns中统计签到次数
  const checkInCount = recentCheckIns.value ? recentCheckIns.value.length : 0
  checkInCountData.value.push(checkInCount)
  
  // 使用真实预约记录数据，从recentReservations中统计预约次数
  const reservationCount = recentReservations.value ? recentReservations.value.length : 0
  reservationCountData.value.push(reservationCount)
  
  // 使用真实违约记录数据，从recentViolations中统计违约次数
  const violationCount = recentViolations.value ? recentViolations.value.length : 0
  violationCountData.value.push(violationCount)
  
  // 使用真实申诉记录数据，从recentAppeals中统计申诉次数
  const appealCount = recentAppeals.value ? recentAppeals.value.length : 0
  appealCountData.value.push(appealCount)
  
  // 保持数据点数量在合理范围内
  if (checkInTimeData.value.length > maxDataPoints) {
    checkInTimeData.value.shift()
    checkInCountData.value.shift()
    reservationCountData.value.shift()
    violationCountData.value.shift()
    appealCountData.value.shift()
  }
  
  // 更新图表配置
  checkInTrendChartOption.value.xAxis.data = checkInTimeData.value
  checkInTrendChartOption.value.series[0].data = checkInCountData.value
  checkInTrendChartOption.value.series[1].data = reservationCountData.value
  checkInTrendChartOption.value.series[2].data = violationCountData.value
  checkInTrendChartOption.value.series[3].data = appealCountData.value
}

// 重新获取所有数据
const refreshAllData = async () => {
  await fetchTotalSeatsCount()
  await fetchAvailableSeatsCount()
  await fetchReservedSeatsCount()
  await fetchUsedSeatsCount()
  await fetchStudentUsersCount()
  await fetchCheckIns()
  await fetchReservations()
  await fetchViolations()
  await fetchAppeals()
  
  // 更新图表数据
  updateChartData()
  updateCheckInChartData()
}

// 在组件挂载时获取总座位数
onMounted(() => {
  refreshAllData()
  
  // 每30秒更新一次数据，提供更实时的信息
  updateInterval = setInterval(async () => {
    await fetchTotalSeatsCount()
    await fetchAvailableSeatsCount()
    await fetchReservedSeatsCount()
    await fetchUsedSeatsCount()
    await fetchCheckIns()
    await fetchReservations()
    await fetchViolations()
    await fetchAppeals()
    updateChartData()
    updateCheckInChartData()
  }, 30000)
})

// 监听路由变化，确保从其他页面跳转到管理员页面时重新获取数据
watch(
  () => route.path,
  (newPath) => {
    if (newPath === '/admin') {
      refreshAllData()
    }
  },
  { immediate: true }
)

// 组件卸载时清除定时器
onUnmounted(() => {
  if (updateInterval) {
    clearInterval(updateInterval)
  }
})

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 更新图表数据
const updateChartData = () => {
  const now = new Date()
  const timeStr = now.getHours() + ':' + (now.getMinutes() < 10 ? '0' : '') + now.getMinutes() + ':' + (now.getSeconds() < 10 ? '0' : '') + now.getSeconds()
  
  timeData.value.push(timeStr)
  availableData.value.push(availableSeatsCount.value)
  reservedData.value.push(reservedSeatsCount.value)
  usedData.value.push(usedSeatsCount.value)
  
  // 计算使用率
  const usageRate = totalSeatsCount.value > 0 ? (usedSeatsCount.value / totalSeatsCount.value * 100).toFixed(1) : 0
  usageRateData.value.push(parseFloat(usageRate))
  
  // 保持数据点数量在合理范围内
  if (timeData.value.length > maxDataPoints) {
    timeData.value.shift()
    availableData.value.shift()
    reservedData.value.shift()
    usedData.value.shift()
    usageRateData.value.shift()
  }
  
  // 更新图表配置
  seatUsageChartOption.value.xAxis.data = timeData.value
  seatUsageChartOption.value.series[0].data = availableData.value
  seatUsageChartOption.value.series[1].data = reservedData.value
  seatUsageChartOption.value.series[2].data = usedData.value
  seatUsageChartOption.value.series[3].data = usageRateData.value
}
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
}

.logout-btn {
  display: flex;
  align-items: center;
  gap: 5px;
  background: none;
  border: 1px solid #e74c3c;
  color: #e74c3c;
  padding: 6px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s ease;
}

.logout-btn:hover {
  background-color: #e74c3c;
  color: white;
}

/* 统计卡片样式 */
.stats-cards {
  display: flex;
  gap: 20px;
  padding: 30px;
  flex-wrap: wrap;
}

.stat-card {
  flex: 1;
  min-width: 200px;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  align-items: center;
  gap: 15px;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.seats-icon {
  background-color: #3498db;
}

.available-icon {
  background-color: #2ecc71;
}

.reserved-icon {
  background-color: #f39c12;
}

.users-icon {
  background-color: #9b59b6;
}

.card-content h3 {
  margin: 0 0 5px 0;
  font-size: 14px;
  color: #7f8c8d;
  font-weight: 400;
}

.stat-value {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
}

/* 图表区域样式 */
.charts-section {
  display: flex;
  gap: 20px;
  padding: 0 30px 30px 30px;
  flex-wrap: wrap;
}

.chart-card {
  flex: 1;
  min-width: 300px;
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.chart-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.chart-placeholder {
  height: 250px;
  background-color: #f8f9fa;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6c757d;
}

.chart-container {
  height: 400px;
  position: relative;
}

.chart {
  width: 100%;
  height: 100%;
}

/* 最近预约记录样式 */
.recent-reservations {
  max-height: 300px;
  overflow-y: auto;
}

.reservations-table {
  width: 100%;
  border-collapse: collapse;
}

.reservations-table th,
.reservations-table td {
  padding: 12px;
  text-align: center;
  border-bottom: 1px solid #e0e0e0;
}

.reservations-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
}

/* 状态列样式 */
.status-column {
  min-width: 80px;
  white-space: nowrap;
}

.status {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
}

.status.active {
  background-color: #d4edda;
  color: #155724;
}

.status.reserved {
  background-color: #fff3cd;
  color: #856404;
}

.status.cancelled {
  background-color: #f8d7da;
  color: #721c24;
}

/* 用户信息和下拉菜单样式 */
.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

.username {
  font-weight: 600;
  cursor: pointer;
  color: #333;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 移除原有的logout-btn样式，因为我们已经用新的下拉菜单替换了它 */
.logout-btn {
  display: none;
}
</style>