package com.example.studyroom.controller;

import com.example.studyroom.model.Seat;
import com.example.studyroom.service.SeatService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/seats") // 移除/api前缀，因为context-path已经配置了
@AllArgsConstructor
public class SeatController {
    private final SeatService seatService;

    @GetMapping
    public ResponseEntity<List<Seat>> getAllSeats() {
        List<Seat> seats = seatService.getAllSeats();
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Seat> getSeatById(@PathVariable Long id) {
        Optional<Seat> seat = seatService.getSeatById(id);
        return seat.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/seat-number/{seatNumber}")
    public ResponseEntity<Seat> getSeatBySeatNumber(@PathVariable String seatNumber) {
        Optional<Seat> seat = seatService.getSeatBySeatNumber(seatNumber);
        return seat.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/classroom/{classroomId}")
    public ResponseEntity<List<Seat>> getSeatsByClassroomId(@PathVariable String classroomId) {
        List<Seat> seats = seatService.getSeatsByClassroomId(classroomId);
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Seat>> getSeatsByStatus(@PathVariable Seat.Status status) {
        List<Seat> seats = seatService.getSeatsByStatus(status);
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }

    // 添加获取指定状态座位数量的接口
    @GetMapping("/count/status/{status}")
    public ResponseEntity<Integer> getSeatsCountByStatus(@PathVariable Seat.Status status) {
        List<Seat> seats = seatService.getSeatsByStatus(status);
        return new ResponseEntity<>(seats.size(), HttpStatus.OK);
    }

    // 添加获取总座位数的接口
    @GetMapping("/count/total")
    public ResponseEntity<Integer> getTotalSeatsCount() {
        List<Seat> seats = seatService.getAllSeats();
        return new ResponseEntity<>(seats.size(), HttpStatus.OK);
    }

    @GetMapping("/classroom/{classroomId}/status/{status}")
    public ResponseEntity<List<Seat>> getSeatsByClassroomIdAndStatus(
            @PathVariable String classroomId,
            @PathVariable Seat.Status status) {
        List<Seat> seats = seatService.getSeatsByClassroomIdAndStatus(classroomId, status);
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Seat> createSeat(@RequestBody Seat seat) {
        Seat createdSeat = seatService.createSeat(seat);
        return new ResponseEntity<>(createdSeat, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Seat> updateSeat(@PathVariable Long id, @RequestBody Seat seat) {
        try {
            Seat updatedSeat = seatService.updateSeat(id, seat);
            return new ResponseEntity<>(updatedSeat, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeat(@PathVariable Long id) {
        seatService.deleteSeat(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/seat-number/{seatNumber}")
    public ResponseEntity<Boolean> existsBySeatNumber(@PathVariable String seatNumber) {
        boolean exists = seatService.existsBySeatNumber(seatNumber);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }
}