package com.example.studyroom.service.impl;

import com.example.studyroom.model.Appeal;
import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.model.Violation;
import com.example.studyroom.model.User;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.repository.AppealRepository;
import com.example.studyroom.service.AppealService;
import com.example.studyroom.service.BlockchainService;
import com.example.studyroom.service.ViolationService;
import com.example.studyroom.service.UserService;
import com.example.studyroom.service.ReservationService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class AppealServiceImpl implements AppealService {
    private final AppealRepository appealRepository;
    private final BlockchainService blockchainService;
    private final ViolationService violationService;
    private final UserService userService;
    private final ReservationService reservationService;

    @Override
    public List<Appeal> getAllAppeals() {
        return appealRepository.findAll();
    }

    @Override
    public Optional<Appeal> getAppealById(@NonNull Long id) {
        return appealRepository.findById(id);
    }

    @Override
    public Optional<Appeal> getAppealByViolationId(@NonNull Long violationId) {
        return appealRepository.findByViolationId(violationId);
    }

    @Override
    public List<Appeal> getAppealsByUserId(@NonNull String userId) {
        return appealRepository.findByUserId(userId);
    }

    @Override
    public List<Appeal> getAppealsByAppealStatus(@NonNull Appeal.AppealStatus status) {
        return appealRepository.findByAppealStatus(status);
    }

    @Override
    public List<Appeal> getAppealsByUserIdAndAppealStatus(@NonNull String userId, @NonNull Appeal.AppealStatus status) {
        return appealRepository.findByUserIdAndAppealStatus(userId, status);
    }

    @Override
    public Optional<Appeal> getAppealByTransactionHash(@NonNull String transactionHash) {
        return appealRepository.findByTransactionHash(transactionHash);
    }

    @Override
    public Appeal createAppeal(@NonNull Appeal appeal) {
        // 设置默认状态和创建时间
        if (appeal.getAppealStatus() == null) {
            appeal.setAppealStatus(Appeal.AppealStatus.pending);
        }
        if (appeal.getCreatedAt() == null) {
            appeal.setCreatedAt(LocalDateTime.now());
        }
        
        // 将申诉信息上链到区块链
        BlockchainLog blockchainLog = blockchainService.uploadToBlockchain(
            appeal, 
            appeal.getUserId(), 
            appeal.getStuAdminId(), // 传递学生/管理员ID
            appeal.getViolationId(), 
            BlockchainLog.OperationType.appeal
        );
        if (blockchainLog == null || blockchainLog.getStatus() != BlockchainLog.Status.success || blockchainLog.getTransactionHash() == null) {
            throw new RuntimeException("Blockchain upload failed for appeal");
        }
        
        // 保存区块链返回的交易哈希和区块高度
        appeal.setTransactionHash(blockchainLog.getTransactionHash());
        appeal.setBlockHeight(blockchainLog.getBlockHeight());
        
        // 保存申诉信息到数据库
        return appealRepository.save(appeal);
    }

    @Override
    public Appeal updateAppeal(@NonNull Long id, @NonNull Appeal appeal) {
        Optional<Appeal> existingAppealOpt = appealRepository.findById(id);
        if (existingAppealOpt.isPresent()) {
            Appeal existingAppeal = existingAppealOpt.get();
            appeal.setId(id);
            
            // 检查申诉状态是否从其他状态变为approved
            if (existingAppeal.getAppealStatus() != Appeal.AppealStatus.approved && 
                appeal.getAppealStatus() == Appeal.AppealStatus.approved) {
                
                // 获取对应的违约记录
                Optional<Violation> violationOpt = violationService.getViolationById(appeal.getViolationId());
                if (violationOpt.isPresent()) {
                    Violation violation = violationOpt.get();
                    
                    // 获取用户ID
                    String userId = violation.getUserId();
                    if (userId != null) {
                        // 获取用户信息以获取用户钱包地址
                        Optional<User> userOpt = userService.getUserByUserId(userId);
                        if (userOpt.isPresent()) {
                            User user = userOpt.get();
                            String walletAddress = user.getWalletAddress();
                            if (walletAddress != null && !walletAddress.isEmpty()) {
                                // 调用DepositManager合约向用户转账1ETH
                                String transactionHash = blockchainService.refundEthAfterAppeal(walletAddress);
                                if (transactionHash != null) {
                                    System.out.println("申诉通过，已向用户钱包 " + walletAddress + " 转账1ETH，交易哈希：" + transactionHash);
                                    
                                    // 转账成功后，再进行申诉通过的流程
                                    // 上链记录管理员审批操作
                                    try {
                                        BlockchainLog adminLog = blockchainService.uploadToBlockchain(
                                                appeal,
                                                userId,
                                                appeal.getStuAdminId(),
                                                appeal.getId(),
                                                BlockchainLog.OperationType.admin_operation
                                        );
                                        appeal.setTransactionHash(adminLog.getTransactionHash());
                                        appeal.setBlockHeight(adminLog.getBlockHeight());
                                    } catch (Exception ex) {
                                        System.err.println("上链记录失败：" + ex.getMessage());
                                    }
                                } else {
                                    System.out.println("调用DepositManager合约失败，申诉状态不会变更");
                                    // 转账失败，保持原状态
                                    appeal.setAppealStatus(existingAppeal.getAppealStatus());
                                    return appealRepository.save(appeal);
                                }
                            } else {
                                System.out.println("用户没有绑定钱包地址，无法转账，申诉状态不会变更");
                                // 没有钱包地址，保持原状态
                                appeal.setAppealStatus(existingAppeal.getAppealStatus());
                                return appealRepository.save(appeal);
                            }
                        } else {
                            System.out.println("用户不存在，无法转账，申诉状态不会变更");
                            // 用户不存在，保持原状态
                            appeal.setAppealStatus(existingAppeal.getAppealStatus());
                            return appealRepository.save(appeal);
                        }
                    } else {
                        System.out.println("用户ID为空，无法转账，申诉状态不会变更");
                        // 用户ID为空，保持原状态
                        appeal.setAppealStatus(existingAppeal.getAppealStatus());
                        return appealRepository.save(appeal);
                    }
                } else {
                    System.out.println("找不到对应的违约记录，申诉状态不会变更");
                    // 找不到违约记录，保持原状态
                    appeal.setAppealStatus(existingAppeal.getAppealStatus());
                    return appealRepository.save(appeal);
                }
            }
            
            return appealRepository.save(appeal);
        } else {
            throw new RuntimeException("Appeal not found with id: " + id);
        }
    }

    @Override
    public void deleteAppeal(@NonNull Long id) {
        appealRepository.deleteById(id);
    }

    @Override
    public boolean existsByViolationId(@NonNull Long violationId) {
        return appealRepository.existsByViolationId(violationId);
    }
}
