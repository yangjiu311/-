<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>仪表盘</span>
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位管理</span>
        </router-link>
        <router-link to="/admin/users" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>用户管理</span>
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
        <router-link to="/admin/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
        <router-link to="/admin/change-password" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>修改密码</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>用户管理</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">管理员</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/admin/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/admin/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 用户管理内容区域 -->
      <section class="users-management">
        <!-- 统计卡片 -->
        <div class="stats-cards">
          <div class="stat-card">
            <div class="stat-icon total">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">总用户数</div>
              <div class="stat-value">{{ users.length }}</div>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-icon active">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <polyline points="22 4 12 14.01 9 11.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">活跃用户</div>
              <div class="stat-value">{{ users.filter(u => u.status === 'enabled').length }}</div>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-icon disabled">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <line x1="15" y1="9" x2="9" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <line x1="9" y1="9" x2="15" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="stat-info">
              <div class="stat-label">禁用用户</div>
              <div class="stat-value">{{ users.filter(u => u.status === 'disabled').length }}</div>
            </div>
          </div>
        </div>

        <!-- 功能按钮区域 -->
        <div class="action-buttons">

        </div>

        <!-- 搜索栏 -->
        <div class="search-bar">
          <select v-model="searchType" class="search-select">
            <option value="stu_admin_id">学号/工号</option>
          </select>
          <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索用户..." @input="handleSearch">
          <button class="search-btn" @click="handleSearch">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.7494 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            搜索
          </button>
        </div>

        <!-- 用户列表表格 -->
        <div class="users-list">
          <table class="users-table">
            <thead>
              <tr>
                <th><input type="checkbox" class="select-all"></th>
                <th>用户ID</th>
                <th>姓名</th>
                <th>学号/工号</th>
                <th>角色</th>
                <th>手机号</th>
                <th>邮箱</th>
                <th>钱包地址</th>
                <th>注册时间</th>
                <th>状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <!-- 加载状态 -->
              <tr v-if="loading">
                <td colspan="11" style="text-align: center; padding: 20px;">加载中...</td>
              </tr>
              <!-- 错误状态 -->
              <tr v-else-if="error">
                <td colspan="11" style="text-align: center; padding: 20px; color: red;">{{ error }}</td>
              </tr>
              <!-- 空数据状态 -->
              <tr v-else-if="filteredUsers.length === 0">
                <td colspan="11" style="text-align: center; padding: 20px;">暂无匹配的用户数据</td>
              </tr>
              <!-- 用户数据列表 -->
              <tr v-for="user in filteredUsers" :key="user.id">
                <td><input type="checkbox" class="select-user"></td>
                <td>{{ formatUserId(user.id) }}</td>
                <td>{{ user.name }}</td>
                <td>{{ user.stu_admin_id || '无' }}</td>
                <td><span :class="['role', getRoleClass(user.role)]">{{ getRoleDisplay(user.role) }}</span></td>
                <td>{{ user.phone || '无' }}</td>
                <td>{{ user.email || '无' }}</td>
                <td class="wallet-address">{{ formatWalletAddress(user.wallet_address) }}</td>
                <td>{{ formatRegisterTime(user.createdAt) }}</td>
                <td><span :class="['status', getStatusClass(user.status)]">{{ getStatusDisplay(user.status) }}</span></td>
                <td>
                  <button class="btn-view" @click="handleViewDetail(user)">查看详情</button>
                  <button class="btn-delete" @click="handleDeleteUser(user.id)">删除</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>



        <!-- 用户详情模态框 -->
        <div v-if="showDetailModal" class="modal-overlay" @click="showDetailModal = false">
          <div class="user-detail-modal" @click.stop>
            <div class="modal-header">
              <h3>用户详情</h3>
              <button class="close-btn" @click="showDetailModal = false">&times;</button>
            </div>
            <div class="modal-content" v-if="selectedUser">
              <div class="detail-item">
                <label>用户ID:</label>
                <span>{{ formatUserId(selectedUser.id) }}</span>
              </div>
              <div class="detail-item">
                <label>姓名:</label>
                <span>{{ selectedUser.name }}</span>
              </div>
              <div class="detail-item">
                <label>学号/工号:</label>
                <span>{{ selectedUser.stu_admin_id || '无' }}</span>
              </div>
              <div class="detail-item">
                <label>角色:</label>
                <span :class="['role', getRoleClass(selectedUser.role)]">
                  {{ getRoleDisplay(selectedUser.role) }}
                </span>
              </div>
              <div class="detail-item">
                <label>手机号:</label>
                <span>{{ selectedUser.phone || '无' }}</span>
              </div>
              <div class="detail-item">
                <label>邮箱:</label>
                <span>{{ selectedUser.email || '无' }}</span>
              </div>
              <div class="detail-item">
                <label>钱包地址:</label>
                <span class="wallet-address">{{ formatWalletAddress(selectedUser.wallet_address) }}</span>
              </div>

              <div class="detail-item">
                <label>注册时间:</label>
                <span>{{ formatRegisterTime(selectedUser.createdAt) }}</span>
              </div>
              <div class="detail-item">
                <label>状态:</label>
                <span :class="['status', getStatusClass(selectedUser.status)]">
                  {{ getStatusDisplay(selectedUser.status) }}
                </span>
              </div>
            </div>
            <div class="modal-footer">
              <button class="btn-close" @click="showDetailModal = false">关闭</button>
            </div>
          </div>
        </div>

        <!-- 充值弹窗 -->

      </section>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted, computed } from 'vue'
import { getAllUsers, deleteUser } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 用户数据响应式变量
const users = ref([])
const loading = ref(true)
const error = ref(null)

// 详情模态框相关变量
const showDetailModal = ref(false)
const selectedUser = ref(null)

// 搜索相关变量
const searchType = ref("stu_admin_id") // 默认搜索类型为学号/工号
const searchKeyword = ref("") // 搜索关键词

// 过滤后的用户列表
const filteredUsers = computed(() => {
  let result = users.value

  // 按学号/工号搜索
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    result = result.filter(user => {
      return user.stu_admin_id?.toLowerCase().includes(keyword)
    })
  }

  return result
})

// 搜索处理函数
const handleSearch = () => {
  console.log("搜索类型: " + searchType.value + ", 关键词: " + searchKeyword.value)
  // 搜索逻辑已经在filteredUsers计算属性中实现
}

// 获取所有用户数据
const fetchUsers = async () => {
  try {
    loading.value = true
    const data = await getAllUsers()
    users.value = data
    error.value = null
  } catch (err) {
    console.error('获取用户数据失败:', err)
    error.value = '获取用户数据失败，请稍后重试'
  } finally {
    loading.value = false
  }
}

// 格式化用户ID（U00+数据库主键id）
const formatUserId = (id) => {
  return `U00${id}`
}

// 格式化注册时间
const formatRegisterTime = (time) => {
  if (!time) return ''
  const date = new Date(time)
  return date.toISOString().split('T')[0] // 只显示日期部分 YYYY-MM-DD
}

// 获取用户状态显示
const getStatusDisplay = (status) => {
  return status === 'enabled' ? '活跃' : '禁用'
}

// 获取状态类名
const getStatusClass = (status) => {
  return status === 'enabled' ? 'active' : 'inactive'
}

// 获取角色显示
const getRoleDisplay = (role) => {
  const roleMap = {
    'admin': '管理员',
    'student': '学生',
    'teacher': '教师'
  }
  return roleMap[role] || role || '未知'
}

// 获取角色类名
const getRoleClass = (role) => {
  return role || 'unknown'
}

// 格式化钱包地址（显示前6位和后4位）
const formatWalletAddress = (address) => {
  if (!address) return '无'
  if (address.length <= 10) return address
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
}

// 组件挂载时获取用户数据
onMounted(() => {
  fetchUsers()
})

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 删除用户
const handleDeleteUser = async (userId) => {
  if (confirm('确定要删除这个用户吗？')) {
    try {
      await deleteUser(userId)
      alert('用户删除成功')
    } catch (err) {
      console.error('删除用户失败:', err)
      alert('删除用户失败，请稍后重试')
    }
  }
}

// 查看用户详情
const handleViewDetail = (user) => {
  selectedUser.value = user
  showDetailModal.value = true
}

// 添加用户
const handleAddUser = () => {
  alert('添加用户功能待实现')
}

// 导出用户
const handleExportUsers = () => {
  alert('导出用户功能待实现')
}




</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f5f7fa;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
  font-weight: 600;
}

/* 管理员悬停功能框样式 */
.user-info {
  display: flex;
  align-items: center;
  gap: 12px;
  position: relative;
  padding: 6px 12px;
  border-radius: 4px;
  transition: background-color 0.3s ease;
}

.user-info:hover {
  background-color: #f5f7fa;
}

.username {
  font-weight: 500;
  cursor: pointer;
  color: #333;
  font-size: 14px;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 2px;
  width: 180px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  border: 1px solid #e8e8e8;
  z-index: 1000;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #333;
  background-color: transparent;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-radius: 8px 8px 0 0;
}

.dropdown-item:last-child {
  border-radius: 0 0 8px 8px;
}

/* 图标样式 */
.dropdown-item svg {
  color: #666;
  width: 16px;
  height: 16px;
}

/* 用户详情模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.user-detail-modal {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  width: 90%;
  max-width: 400px;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #e8e8e8;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  color: #999;
  cursor: pointer;
  padding: 0;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.close-btn:hover {
  color: #666;
}

.modal-content {
  padding: 20px;
}

.detail-item {
  display: flex;
  margin-bottom: 16px;
  align-items: center;
}

.detail-item:last-child {
  margin-bottom: 0;
}

.detail-item label {
  width: 120px;
  font-weight: 500;
  color: #666;
  font-size: 14px;
}

.detail-item span {
  flex: 1;
  font-size: 14px;
  color: #333;
  word-break: break-all;
}

.modal-footer {
  padding: 16px 20px;
  border-top: 1px solid #e8e8e8;
  display: flex;
  justify-content: flex-end;
}

.btn-close {
  padding: 8px 16px;
  background-color: #f0f0f0;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  color: #333;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease;
}

.btn-close:hover {
  background-color: #e0e0e0;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 用户管理内容区域 */
.users-management {
  padding: 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

/* 统计卡片 */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.stat-icon.total {
  background-color: #3498db;
}

.stat-icon.active {
  background-color: #2ecc71;
}

.stat-icon.inactive {
  background-color: #e74c3c;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #7f8c8d;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #2c3e50;
}

/* 功能按钮区域 */
.action-buttons {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.action-btn svg {
  color: white;
}

.action-btn.add-user {
  background-color: #2ecc71;
}

.action-btn.add-user:hover {
  background-color: #27ae60;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.action-btn.export-users {
  background-color: #3498db;
}

.action-btn.export-users:hover {
  background-color: #2980b9;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}



/* 搜索栏和按钮样式 */
.search-bar {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.search-select {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px 0 0 4px;
  font-size: 14px;
  background-color: #fff;
  color: #333;
  min-width: 120px;
  cursor: pointer;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-select:focus {
  border-color: #4e73df;
  box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
}

.search-input {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-left: none;
  border-right: none;
  font-size: 14px;
  width: 300px;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-btn {
  padding: 10px 16px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.3s ease;
}

.search-btn:hover {
  background-color: #2980b9;
}

.action-btn {
  padding: 10px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.3s ease;
}

.add-btn {
  background-color: #4CAF50;
  color: white;
}

.add-btn:hover {
  background-color: #45a049;
}

/* 用户列表 */
.users-list {
  flex: 1;
  overflow-y: auto;
  margin-bottom: 20px;
}

/* 用户表格样式 */
.users-table {
  width: 100%;
  border-collapse: collapse;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.users-table th {
  background-color: #f5f7fa;
  padding: 12px 16px;
  text-align: center;
  font-weight: 600;
  color: #2c3e50;
  border-bottom: 1px solid #e8e8e8;
  font-size: 14px;
}

.users-table td {
  padding: 12px 16px;
  border-bottom: 1px solid #f5f5f5;
  color: #333;
  font-size: 14px;
}

.users-table tbody tr {
  transition: background-color 0.3s ease;
}

.users-table tbody tr:hover {
  background-color: #f5f7fa;
}

/* 复选框样式 */
.select-all,
.select-user {
  width: 16px;
  height: 16px;
  cursor: pointer;
}

/* 状态标签样式 */
.status {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
  text-align: center;
  min-width: 60px;
}

.status.active {
  background-color: #e6f7ff;
  color: #1890ff;
}

.status.inactive {
  background-color: #fff1f0;
  color: #ff4d4f;
}

/* 操作按钮样式 */
.btn-view,
.btn-edit,
.btn-delete {
  padding: 4px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  margin-right: 6px;
  transition: all 0.3s ease;
  font-weight: 500;
}

.btn-view {
  background-color: #e6f7ff;
  color: #1890ff;
  border: 1px solid #91d5ff;
}

.btn-view:hover {
  background-color: #91d5ff;
  color: #096dd9;
}



.btn-edit {
  background-color: #fff7e6;
  color: #fa8c16;
  border: 1px solid #ffd591;
}

.btn-edit:hover {
  background-color: #ffd591;
  color: #d46b08;
}

.btn-delete {
  background-color: #fff2f0;
  color: #ff4d4f;
  border: 1px solid #ffccc7;
}

.btn-delete:hover {
  background-color: #ffccc7;
  color: #cf1322;
}



/* 页面过渡动画 */
.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s ease-in;
}

.slide-fade-enter-from {
  opacity: 0;
  transform: translateX(-20px);
}

.slide-fade-leave-to {
  opacity: 0;
  transform: translateX(20px);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .admin-container {
    flex-direction: column;
  }
  
  .sidebar {
    width: 100%;
    height: auto;
  }
  
  .nav-menu {
    display: flex;
    overflow-x: auto;
    padding: 10px;
  }
  
  .nav-item {
    white-space: nowrap;
    padding: 8px 12px;
    margin-right: 10px;
    border-radius: 4px;
    border-left: none;
    border-bottom: 3px solid transparent;
  }
  
  .nav-item:hover,
  .nav-item.active {
    border-left: none;
    border-bottom-color: #3498db;
  }
  
  .top-nav {
    padding: 0 15px;
  }
  
  .top-nav h1 {
    font-size: 18px;
  }
  
  .search-bar {
    flex-direction: column;
    align-items: stretch;
    gap: 8px;
  }
  
  .search-input {
    width: 100%;
  }
  
  .search-btn,
  .add-btn {
    width: 100%;
    justify-content: center;
  }
  
  .users-management {
    padding: 15px;
  }
  
  .users-table {
    font-size: 12px;
  }
  
  .users-table th,
  .users-table td {
    padding: 8px;
  }
  
  /* 在小屏幕上隐藏一些列 */
  .users-table th:nth-child(5), /* 邮箱 */
  .users-table td:nth-child(5) {
    display: none;
  }
  
  .btn-view,
  .btn-edit,
  .btn-delete {
    padding: 2px 6px;
    font-size: 11px;
    margin-right: 2px;
  }
}

@media (max-width: 480px) {
  /* 在更小的屏幕上隐藏更多列 */
  .users-table th:nth-child(4), /* 学号/工号 */
  .users-table td:nth-child(4),
  .users-table th:nth-child(6), /* 注册时间 */
  .users-table td:nth-child(6) {
    display: none;
  }
}
</style>

