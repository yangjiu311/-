package com.example.studyroom.controller;

import com.example.studyroom.dto.ReservationDetailDTO;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.service.ReservationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservations")
@AllArgsConstructor
public class ReservationController {
    private final ReservationService reservationService;

    // 新增：获取所有预约详情（包含签到信息）- 必须放在/{id}之前
    @GetMapping("/details")
    public ResponseEntity<List<ReservationDetailDTO>> getAllReservationDetails() {
        List<ReservationDetailDTO> details = reservationService.getAllReservationDetails();
        return new ResponseEntity<>(details, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservationById(@PathVariable Long id) {
        Optional<Reservation> reservation = reservationService.getReservationById(id);
        return reservation.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Reservation>> getReservationsByUserId(@PathVariable String userId) {
        List<Reservation> reservations = reservationService.getReservationsByUserId(userId);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/seat/{seatId}")
    public ResponseEntity<List<Reservation>> getReservationsBySeatId(@PathVariable Long seatId) {
        List<Reservation> reservations = reservationService.getReservationsBySeatId(seatId);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Reservation>> getReservationsByStatus(@PathVariable Reservation.Status status) {
        List<Reservation> reservations = reservationService.getReservationsByStatus(status);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/user/{userId}/status/{status}")
    public ResponseEntity<List<Reservation>> getReservationsByUserIdAndStatus(
            @PathVariable String userId,
            @PathVariable Reservation.Status status) {
        List<Reservation> reservations = reservationService.getReservationsByUserIdAndStatus(userId, status);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/date-range")
    public ResponseEntity<List<Reservation>> getReservationsByDateTimeRange(
            @RequestParam LocalDateTime startDateTime,
            @RequestParam LocalDateTime endDateTime) {
        List<Reservation> reservations = reservationService.getReservationsByDateTimeRange(startDateTime, endDateTime);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @GetMapping("/seat/{seatId}/date-range")
    public ResponseEntity<List<Reservation>> getReservationsBySeatIdAndDateTimeRange(
            @PathVariable Long seatId,
            @RequestParam LocalDateTime startDateTime,
            @RequestParam LocalDateTime endDateTime) {
        List<Reservation> reservations = reservationService.getReservationsBySeatIdAndDateTimeRange(seatId, startDateTime, endDateTime);
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Reservation> createReservation(@RequestBody Reservation reservation) {
        Reservation createdReservation = reservationService.createReservation(reservation);
        return new ResponseEntity<>(createdReservation, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
        try {
            Reservation updatedReservation = reservationService.updateReservation(id, reservation);
            return new ResponseEntity<>(updatedReservation, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}/hide")
    public ResponseEntity<Reservation> hideReservation(@PathVariable Long id) {
        try {
            Reservation updatedReservation = reservationService.updateDisplayStatus(id, Reservation.DisplayStatus.FALSE);
            return new ResponseEntity<>(updatedReservation, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReservation(@PathVariable Long id) {
        reservationService.deleteReservation(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/is-available")
    public ResponseEntity<Boolean> isSeatAvailable(
            @RequestParam Long seatId,
            @RequestParam LocalDateTime startTime,
            @RequestParam LocalDateTime endTime) {
        boolean isAvailable = reservationService.isSeatAvailable(seatId, startTime, endTime);
        return new ResponseEntity<>(isAvailable, HttpStatus.OK);
    }

    // 添加获取最近预约记录的API端点
    @GetMapping("/recent")
    public ResponseEntity<List<Reservation>> getRecentReservations() {
        List<Reservation> recentReservations = reservationService.getRecentReservations();
        return new ResponseEntity<>(recentReservations, HttpStatus.OK);
    }

    // 添加获取指定用户最近预约记录的API端点
    @GetMapping("/user/{userId}/recent")
    public ResponseEntity<List<Reservation>> getUserRecentReservations(@PathVariable String userId) {
        List<Reservation> recentReservations = reservationService.getUserRecentReservations(userId);
        return new ResponseEntity<>(recentReservations, HttpStatus.OK);
    }
    
    // 添加签到接口
    @PutMapping("/{id}/check-in")
    public ResponseEntity<Reservation> checkInReservation(@PathVariable Long id, @RequestBody Map<String, String> requestBody) {
        try {
            String depositRefundTxHash = requestBody.get("depositRefundTxHash");
            Reservation updatedReservation = reservationService.checkInReservation(id, depositRefundTxHash);
            return new ResponseEntity<>(updatedReservation, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    // 添加取消预约接口
    @PutMapping("/{id}/cancel")
    public ResponseEntity<Reservation> cancelReservation(@PathVariable Long id) {
        try {
            Reservation updatedReservation = reservationService.cancelReservation(id);
            return new ResponseEntity<>(updatedReservation, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    // 添加更新过期预约状态的接口
    @PostMapping("/update-expired")
    public ResponseEntity<String> updateExpiredReservations() {
        int updatedCount = reservationService.updateExpiredReservations();
        return new ResponseEntity<>(String.format("成功更新 %d 条过期预约记录", updatedCount), HttpStatus.OK);
    }
}