package com.example.studyroom.service;

import com.example.studyroom.dto.ReservationDetailDTO;
import com.example.studyroom.model.Reservation;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ReservationService {
    List<Reservation> getAllReservations();
    
    // 新增：获取所有预约详情（包含签到信息）
    List<ReservationDetailDTO> getAllReservationDetails();
    
    Optional<Reservation> getReservationById(Long id);
    List<Reservation> getReservationsByUserId(String userId);
    List<Reservation> getReservationsBySeatId(Long seatId);
    List<Reservation> getReservationsByStatus(Reservation.Status status);
    List<Reservation> getReservationsByUserIdAndStatus(String userId, Reservation.Status status);
    List<Reservation> getReservationsByDateTimeRange(LocalDateTime startDateTime, LocalDateTime endDateTime);
    List<Reservation> getReservationsBySeatIdAndDateTimeRange(Long seatId, LocalDateTime startDateTime, LocalDateTime endDateTime);
    Reservation createReservation(Reservation reservation);
    Reservation updateReservation(Long id, Reservation reservation);
    void deleteReservation(Long id);
    boolean isSeatAvailable(Long seatId, LocalDateTime startTime, LocalDateTime endTime);
    // 添加获取最近预约记录的方法
    List<Reservation> getRecentReservations();
    
    // 添加获取指定用户最近预约记录的方法
    List<Reservation> getUserRecentReservations(String userId);
    
    // 添加签到方法
    Reservation checkInReservation(Long id);
    
    // 添加签到方法（支持押金退还交易哈希）
    Reservation checkInReservation(Long id, String depositRefundTxHash);
    
    // 添加取消预约方法
    Reservation cancelReservation(Long id);
    
    // 添加更新显示状态的方法
    Reservation updateDisplayStatus(Long id, Reservation.DisplayStatus displayStatus);
    
    // 添加更新过期预约状态的方法
    int updateExpiredReservations();
}