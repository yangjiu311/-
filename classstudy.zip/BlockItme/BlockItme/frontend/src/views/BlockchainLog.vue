<template>
  <div class="blockchain-log-page">
    <div class="container">
      <!-- 顶部导航栏 -->
      <header class="header">
        <div class="header-content">
          <div class="header-left">
            <h1 class="page-title">区块链日志</h1>
          </div>
          <div class="header-right">
            <button class="back-btn" @click="goBack">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M12 19L5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              返回
            </button>
          </div>
        </div>
      </header>

      <!-- 主要内容区域 -->
      <main class="main-content">
        <!-- 加载状态 -->
        <div v-if="loading" class="loading-container">
          <div class="loading-spinner"></div>
          <p>加载区块链日志中...</p>
        </div>

        <!-- 错误状态 -->
        <div v-else-if="error" class="error-container">
          <div class="error-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M12 16H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <h3 class="error-title">加载失败</h3>
          <p class="error-message">{{ error }}</p>
          <button class="retry-btn" @click="fetchBlockchainLog">重试</button>
        </div>

        <!-- 成功状态 - 显示区块链日志信息 -->
        <div v-else-if="blockchainLogData" class="log-container">
          <div class="log-header">
            <h2>预约上链信息</h2>
            <div class="log-badge" :class="blockchainLogData.status">
              {{ getStatusText(blockchainLogData.status) }}
            </div>
          </div>

          <div class="log-content">
            <div class="log-section">
              <h3 class="section-title">交易信息</h3>
              <div class="info-grid">
                <div class="info-item">
                  <span class="info-label">交易哈希:</span>
                  <span class="info-value hash-value">{{ transactionHash }}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">区块高度:</span>
                  <span class="info-value">{{ blockchainLogData.blockHeight || '-' }}</span>
                </div>
              </div>
            </div>

            <div class="log-section">
              <h3 class="section-title">操作信息</h3>
              <div class="info-grid">
                <div class="info-item">
                  <span class="info-label">操作类型:</span>
                  <span class="info-value">{{ blockchainLogData.operationType || '-' }}</span>
                </div>
                <div class="info-item">
                  <span class="info-label">状态:</span>
                  <span class="info-value status-value" :class="blockchainLogData.status">
                    {{ getStatusText(blockchainLogData.status) }}
                  </span>
                </div>
              </div>
            </div>

            <div class="log-section">
              <h3 class="section-title">时间信息</h3>
              <div class="info-grid">
                <div class="info-item full-width">
                  <span class="info-label">创建时间:</span>
                  <span class="info-value">
                    {{ blockchainLogData.createdAt ? new Date(blockchainLogData.createdAt).toLocaleString('zh-CN') : '-' }}
                  </span>
                </div>
              </div>
            </div>

            <div class="log-footer">
              <div class="verify-info">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12L11 14L15 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span>此信息已上链存储，可验证真实性</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const route = useRoute()

// 获取交易哈希参数
const transactionHash = ref(route.params.transactionHash || '')

// 状态管理
const loading = ref(false)
const error = ref(null)
const blockchainLogData = ref(null)

// 获取区块链日志
const fetchBlockchainLog = async () => {
  if (!transactionHash.value) {
    error.value = '缺少交易哈希参数'
    return
  }

  loading.value = true
  error.value = null

  try {
    const response = await axios.get(`/api/blockchain-logs/reservation-info/${transactionHash.value}`)
    blockchainLogData.value = response.data
    console.log('区块链日志数据:', response.data)
  } catch (err) {
    console.error('获取区块链日志失败:', err)
    if (err.response?.status === 404) {
      error.value = '未找到该交易哈希对应的区块链日志'
    } else {
      error.value = '获取区块链日志失败，请稍后重试'
    }
  } finally {
    loading.value = false
  }
}

// 返回上一页
const goBack = () => {
  router.back()
}

// 获取状态文本
const getStatusText = (status) => {
  const statusMap = {
    'confirmed': '已确认',
    'pending': '待确认',
    'failed': '失败',
    'completed': '已完成'
  }
  return statusMap[status] || status || '-'
}

// 组件挂载时获取数据
onMounted(() => {
  fetchBlockchainLog()
})
</script>

<style scoped>
.blockchain-log-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 20px;
}

.container {
  max-width: 800px;
  margin: 0 auto;
}

.header {
  background: white;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.page-title {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.back-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: #667eea;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s ease;
}

.back-btn:hover {
  background: #5568d3;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.main-content {
  background: white;
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* 加载状态 */
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  color: #666;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #667eea;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 错误状态 */
.error-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  text-align: center;
}

.error-icon {
  color: #ef4444;
  margin-bottom: 20px;
}

.error-title {
  font-size: 20px;
  font-weight: 600;
  color: #333;
  margin: 0 0 10px 0;
}

.error-message {
  color: #666;
  margin-bottom: 20px;
}

.retry-btn {
  padding: 12px 30px;
  background: #667eea;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s ease;
}

.retry-btn:hover {
  background: #5568d3;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

/* 日志容器 */
.log-container {
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.log-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #f0f0f0;
}

.log-header h2 {
  font-size: 24px;
  font-weight: 600;
  color: #333;
  margin: 0;
}

.log-badge {
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  text-transform: uppercase;
}

.log-badge.confirmed {
  background: #d1fae5;
  color: #065f46;
}

.log-badge.pending {
  background: #fef3c7;
  color: #92400e;
}

.log-badge.failed {
  background: #fee2e2;
  color: #991b1b;
}

.log-badge.completed {
  background: #dbeafe;
  color: #1e40af;
}

.log-content {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

.log-section {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #333;
  margin: 0 0 15px 0;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 15px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.info-item.full-width {
  grid-column: 1 / -1;
}

.info-label {
  font-size: 13px;
  color: #666;
  font-weight: 500;
}

.info-value {
  font-size: 15px;
  color: #333;
  font-weight: 500;
  word-break: break-all;
}

.hash-value {
  font-family: 'Courier New', monospace;
  font-size: 13px;
  color: #667eea;
  background: #f0f4ff;
  padding: 8px 12px;
  border-radius: 6px;
}

.status-value {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 13px;
}

.status-value.confirmed {
  background: #d1fae5;
  color: #065f46;
}

.status-value.pending {
  background: #fef3c7;
  color: #92400e;
}

.status-value.failed {
  background: #fee2e2;
  color: #991b1b;
}

.status-value.completed {
  background: #dbeafe;
  color: #1e40af;
}

.log-footer {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 2px solid #f0f0f0;
}

.verify-info {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #667eea;
  font-size: 14px;
  font-weight: 500;
}

.verify-info svg {
  flex-shrink: 0;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .blockchain-log-page {
    padding: 10px;
  }

  .header {
    padding: 15px;
  }

  .page-title {
    font-size: 20px;
  }

  .back-btn {
    padding: 8px 16px;
    font-size: 13px;
  }

  .main-content {
    padding: 20px;
  }

  .log-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }

  .log-header h2 {
    font-size: 20px;
  }

  .info-grid {
    grid-template-columns: 1fr;
  }

  .section-title {
    font-size: 14px;
  }

  .info-label {
    font-size: 12px;
  }

  .info-value {
    font-size: 14px;
  }
}
</style>

