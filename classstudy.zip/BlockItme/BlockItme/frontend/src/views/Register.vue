<template>
  <div class="register-container">
    <!-- 区块链背景元素 -->
    <div class="blockchain-background">
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
    </div>

    <!-- 顶部装饰区 -->
    <div class="top-decoration">
      <div class="decorative-box"></div>
      <div class="decorative-box"></div>
      <div class="decorative-box"></div>
    </div>

    <div class="register-box">
      <!-- 标题和区块链图标 -->
      <div class="register-header">
        <div class="blockchain-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h1>注册账号</h1>
        <p>加入区块链自习室系统</p>
      </div>

      <!-- 注册表单 -->
      <form @submit.prevent="register" class="register-form">
        <div class="form-group">
          <label for="userId">账号</label>
          <input 
            type="text" 
            id="userId" 
            v-model="form.userId" 
            required 
            placeholder="请输入学号（学生）或管理员账号"
          >
        </div>

        <div class="form-group">
          <label for="name">姓名</label>
          <input 
            type="text" 
            id="name" 
            v-model="form.name" 
            required 
            placeholder="请输入真实姓名"
          >
        </div>

        <div class="form-group">
          <label for="studentId">学号/工号</label>
          <input 
            type="text" 
            id="studentId" 
            v-model="form.studentId" 
            required 
            placeholder="请输入学号（学生）或工号（管理员）"
          >
        </div>

        <div class="form-group">
          <label for="password">密码</label>
          <input 
            type="password" 
            id="password" 
            v-model="form.password" 
            required 
            placeholder="请设置密码"
          >
        </div>

        <div class="form-group">
          <label for="confirmPassword">确认密码</label>
          <input 
            type="password" 
            id="confirmPassword" 
            v-model="form.confirmPassword" 
            required 
            placeholder="请再次输入密码"
          >
        </div>

        <div class="form-group">
          <label for="email">邮箱(选填)</label>
          <input 
            type="email" 
            id="email" 
            v-model="form.email" 
            placeholder="请输入邮箱地址"
          >
        </div>

        <div class="form-group">
          <label for="phone">手机号(选填)</label>
          <input 
            type="tel" 
            id="phone" 
            v-model="form.phone" 
            placeholder="请输入手机号码"
          >
        </div>

        <div class="form-group">
          <label for="walletAddress">钱包地址</label>
          <input 
            type="text" 
            id="walletAddress" 
            v-model="form.walletAddress" 
            placeholder="请输入以太坊钱包地址"
          >
        </div>

        <div class="form-group">
          <label>角色</label>
          <div class="role-selection">
            <label class="role-option">
              <input 
                type="radio" 
                v-model="form.role" 
                value="student" 
                required
              >
              <span>学生</span>
            </label>
            <label class="role-option">
              <input 
                type="radio" 
                v-model="form.role" 
                value="admin" 
                required
              >
              <span>管理员</span>
            </label>
          </div>
        </div>

        <button type="submit" class="register-btn" :disabled="form.password !== form.confirmPassword">
          注册账号
        </button>
      </form>

      <!-- 登录链接 -->
      <div class="login-link">
        <span>已有账号？</span>
        <router-link to="/login">立即登录</router-link>
      </div>
    </div>

    <!-- 底部装饰区 -->
    <div class="bottom-decoration">
      <div class="feature-section">
        <h3>区块链自习室系统特色</h3>
        <div class="features">
          <div class="feature">
            <div class="feature-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <h4>区块链技术</h4>
            <p>基于区块链的自习室管理系统，保证数据安全可靠</p>
          </div>
          <div class="feature">
            <div class="feature-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 11L12 14L22 4" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 12V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H16" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <h4>智能预约</h4>
            <p>智能座位预约系统，轻松管理自习时间</p>
          </div>
          <div class="feature">
            <div class="feature-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="#4CAF50" stroke-width="2"/>
                <path d="M12 16V12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round"/>
                <path d="M12 8H12.01" stroke="#4CAF50" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <h4>实时状态</h4>
            <p>实时查看座位使用情况，避免不必要的等待</p>
          </div>
        </div>
      </div>
      
      <div class="system-info">
        <h3>系统介绍</h3>
        <p>区块链自习室系统是一个基于现代Web技术开发的智能自习室管理平台，采用区块链技术确保数据的安全性和不可篡改性。用户可以轻松预约座位、查看使用状态、管理个人信息等。系统支持学生和管理员两种角色，提供完整的自习室管理解决方案。</p>
        <p>通过该系统，学校可以更好地管理自习室资源，提高资源利用率，为学生提供更加便捷的自习服务。同时，基于区块链的技术架构也为系统提供了更高的安全性和可靠性。</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import api from '../services/api'  // 导入API服务

const router = useRouter()
const userStore = useUserStore()
const form = ref({
  userId: '',
  name: '',
  studentId: '',
  password: '',
  confirmPassword: '',
  email: '',
  phone: '',
  walletAddress: '',
  role: 'student'
})

// 注册方法
const register = async () => {
  try {
    if (form.value.password !== form.value.confirmPassword) {
      alert('两次输入的密码不一致')
      return
    }
    
    // 准备注册请求数据
    const registerData = {
      userId: form.value.userId,
      name: form.value.name,
      studentId: form.value.studentId,
      password: form.value.password,
      email: form.value.email,
      phone: form.value.phone,
      walletAddress: form.value.walletAddress,
      role: form.value.role
    }
    
    // 调用后端注册接口
    await api.post('/users', registerData)
    
    alert('注册成功！请登录')
    
    // 注册成功后跳转到登录页
    router.push('/login')
  } catch (error) {
    console.error('注册失败:', error)
    alert('注册失败，请稍后重试')
  }
}
</script>

<style scoped>
.register-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh; /* 恢复为最小高度以适应内容 */
  max-height: 100vh; /* 添加最大高度限制 */
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow-y: auto; /* 确保垂直滚动 */
  overflow-x: hidden; /* 隐藏水平滚动条 */
  padding: 20px 0;
  box-sizing: border-box; /* 确保内边距不影响高度计算 */
}

/* 区块链背景动画 */
.blockchain-background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.1;
  z-index: 0;
}

.blockchain-line {
  display: flex;
  justify-content: space-around;
  margin: 20px 0;
  animation: blockchainMove 20s linear infinite;
}

.blockchain-line:nth-child(2) {
  animation-delay: -7s;
}

.blockchain-line:nth-child(3) {
  animation-delay: -14s;
}

.block {
  width: 20px;
  height: 20px;
  border: 2px solid #4CAF50;
  border-radius: 4px;
  background: rgba(76, 175, 80, 0.1);
}

@keyframes blockchainMove {
  0% {
    transform: translateY(-100px);
  }
  100% {
    transform: translateY(100vh);
  }
}

/* 顶部装饰区 */
.top-decoration {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 40px;
  z-index: 1;
}

.decorative-box {
  width: 40px;
  height: 40px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  backdrop-filter: blur(10px);
  animation: float 3s ease-in-out infinite;
}

.decorative-box:nth-child(2) {
  animation-delay: 1s;
}

.decorative-box:nth-child(3) {
  animation-delay: 2s;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.register-box {
  background: white;
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  width: 100%;
  max-width: 550px; /* 略微加宽注册框 */
  position: relative;
  z-index: 1;
}

.register-header {
  text-align: center;
  margin-bottom: 30px;
}

.blockchain-icon {
  margin-bottom: 15px;
}

.register-header h1 {
  font-size: 24px;
  color: #333;
  margin: 0;
}

.register-header p {
  color: #666;
  margin: 5px 0 0;
  font-size: 14px;
}

.register-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: center; /* 表单整体居中 */
}

.form-group {
  display: flex;
  align-items: center; /* 标签和输入框垂直居中对齐 */
  gap: 15px; /* 标签与输入框的间距 */
  width: 100%;
  max-width: 450px; /* 限制表单组宽度 */
}

.form-group label {
  font-weight: 600;
  color: #333;
  font-size: 14px;
  min-width: 80px; /* 固定标签宽度 */
  text-align: right;
  line-height: 1.5;
  display: inline-block;
  vertical-align: middle;
}

.form-group input {
  flex: 1;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  height: 44px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}

.form-group input:focus {
  outline: none;
  border-color: #4CAF50;
}

.role-selection {
  display: flex;
  gap: 20px;
  margin-left: 0; /* 与输入框左侧对齐 */
}

.role-option {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 14px;
}

.register-btn {
  padding: 14px;
  background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
  width: 100%;
  max-width: 450px; /* 与表单组宽度一致 */
}

.register-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(76, 175, 80, 0.3);
}

.register-btn:disabled {
  background: #cccccc;
  cursor: not-allowed;
}

.login-link {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
  width: 100%;
}

.login-link a {
  color: #4CAF50;
  text-decoration: none;
  font-weight: 600;
}

.login-link a:hover {
  text-decoration: underline;
}

/* 底部装饰区 */
.bottom-decoration {
  margin-top: 60px;
  margin-bottom: 40px;
  width: 100%;
  max-width: 800px;
  z-index: 1;
}

.feature-section {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 30px;
  margin-bottom: 30px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.feature-section h3 {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 20px;
}

.features {
  display: flex;
  justify-content: space-around;
  gap: 20px;
  flex-wrap: wrap;
}

.feature {
  text-align: center;
  max-width: 200px;
}

.feature-icon {
  width: 60px;
  height: 60px;
  margin: 0 auto 15px;
  background: rgba(76, 175, 80, 0.1);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.feature h4 {
  color: #333;
  margin-bottom: 10px;
  font-size: 16px;
}

.feature p {
  color: #666;
  font-size: 14px;
  line-height: 1.5;
}

.system-info {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.system-info h3 {
  text-align: center;
  color: #333;
  margin-bottom: 20px;
  font-size: 20px;
}

.system-info p {
  color: #666;
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 15px;
  text-align: center;
}
</style>