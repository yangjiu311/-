package com.example.studyroom.contract;

import io.reactivex.Flowable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.BaseEventResponse;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tuples.generated.Tuple5;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.9.8.
 */
@SuppressWarnings("rawtypes")
public class CheckInAbi extends Contract {
    public static final String BINARY = "Bin file was not provided";

    public static final String FUNC_CREATECHECKIN = "createCheckIn";

    public static final String FUNC_GETCHECKIN = "getCheckIn";

    public static final Event CHECKINCREATED_EVENT = new Event("CheckInCreated", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>(true) {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}));
    ;

    @Deprecated
    protected CheckInAbi(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected CheckInAbi(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected CheckInAbi(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected CheckInAbi(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static List<CheckInCreatedEventResponse> getCheckInCreatedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = staticExtractEventParametersWithLog(CHECKINCREATED_EVENT, transactionReceipt);
        ArrayList<CheckInCreatedEventResponse> responses = new ArrayList<CheckInCreatedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            CheckInCreatedEventResponse typedResponse = new CheckInCreatedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.checkInId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.userId = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.seatNumber = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.areaName = (String) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.checkInTime = (BigInteger) eventValues.getNonIndexedValues().get(3).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static CheckInCreatedEventResponse getCheckInCreatedEventFromLog(Log log) {
        Contract.EventValuesWithLog eventValues = staticExtractEventParametersWithLog(CHECKINCREATED_EVENT, log);
        CheckInCreatedEventResponse typedResponse = new CheckInCreatedEventResponse();
        typedResponse.log = log;
        typedResponse.checkInId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
        typedResponse.userId = (String) eventValues.getNonIndexedValues().get(0).getValue();
        typedResponse.seatNumber = (String) eventValues.getNonIndexedValues().get(1).getValue();
        typedResponse.areaName = (String) eventValues.getNonIndexedValues().get(2).getValue();
        typedResponse.checkInTime = (BigInteger) eventValues.getNonIndexedValues().get(3).getValue();
        return typedResponse;
    }

    public Flowable<CheckInCreatedEventResponse> checkInCreatedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(log -> getCheckInCreatedEventFromLog(log));
    }

    public Flowable<CheckInCreatedEventResponse> checkInCreatedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(CHECKINCREATED_EVENT));
        return checkInCreatedEventFlowable(filter);
    }

    public RemoteFunctionCall<TransactionReceipt> createCheckIn(String checkInId, String userId, String seatNumber, String areaName) {
        final Function function = new Function(
                FUNC_CREATECHECKIN, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(checkInId), 
                new org.web3j.abi.datatypes.Utf8String(userId), 
                new org.web3j.abi.datatypes.Utf8String(seatNumber), 
                new org.web3j.abi.datatypes.Utf8String(areaName)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteFunctionCall<Tuple5<String, String, String, String, BigInteger>> getCheckIn(String checkInId) {
        final Function function = new Function(FUNC_GETCHECKIN, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(checkInId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}));
        return new RemoteFunctionCall<Tuple5<String, String, String, String, BigInteger>>(function,
                new Callable<Tuple5<String, String, String, String, BigInteger>>() {
                    @Override
                    public Tuple5<String, String, String, String, BigInteger> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);
                        return new Tuple5<String, String, String, String, BigInteger>(
                                (String) results.get(0).getValue(), 
                                (String) results.get(1).getValue(), 
                                (String) results.get(2).getValue(), 
                                (String) results.get(3).getValue(), 
                                (BigInteger) results.get(4).getValue());
                    }
                });
    }

    @Deprecated
    public static CheckInAbi load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new CheckInAbi(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static CheckInAbi load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new CheckInAbi(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static CheckInAbi load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new CheckInAbi(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static CheckInAbi load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new CheckInAbi(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static class CheckInCreatedEventResponse extends BaseEventResponse {
        public byte[] checkInId;

        public String userId;

        public String seatNumber;

        public String areaName;

        public BigInteger checkInTime;
    }
}
