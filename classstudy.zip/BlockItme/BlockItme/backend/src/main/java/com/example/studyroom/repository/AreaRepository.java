package com.example.studyroom.repository;

import com.example.studyroom.model.Area;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AreaRepository extends JpaRepository<Area, Long> {
    boolean existsByClassroomName(String classroomName);
}
