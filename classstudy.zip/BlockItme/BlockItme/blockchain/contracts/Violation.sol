// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract Violation {
    struct ViolationRecord {
        string violationId;
        string userId;
        string seatNumber;
        string areaName;
        string violationType;
        uint256 timestamp;
    }

    mapping(string => ViolationRecord) private violationRecords;
    string[] private violationIds;

    event ViolationCreated(
        string indexed violationId,
        string indexed userId,
        string seatNumber,
        string areaName,
        string violationType,
        uint256 timestamp
    );

    function createViolation(
        string calldata violationId,
        string calldata userId,
        string calldata seatNumber,
        string calldata areaName,
        string calldata violationType
    ) external returns (bool) {
        require(violationRecords[violationId].timestamp == 0, "Violation exists");

        violationRecords[violationId] = ViolationRecord({
            violationId: violationId,
            userId: userId,
            seatNumber: seatNumber,
            areaName: areaName,
            violationType: violationType,
            timestamp: block.timestamp
        });

        violationIds.push(violationId);

        emit ViolationCreated(
            violationId,
            userId,
            seatNumber,
            areaName,
            violationType,
            block.timestamp
        );

        return true;
    }
}
