package com.example.studyroom.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "blockchain_log")
public class BlockchainLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "operation_type", nullable = false)
    private OperationType operationType;

    @Column(name = "user_id", length = 50)
    private String userId;

    @Column(name = "stu_admin_id", length = 50, nullable = true)
    private String stuAdminId;

    @Column(name = "target_id")
    private Long targetId;

    @Column(name = "transaction_hash", unique = true, length = 255)
    private String transactionHash;

    @Column(name = "block_height")
    private Long blockHeight;

    @Column(name = "operation_data", columnDefinition = "JSON")
    private String operationData;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    public enum OperationType {
        reservation, check_in, release, violation, appeal, admin_operation
    }

    public enum Status {
        success, failed
    }
}