package com.example.studyroom.dto;

import com.example.studyroom.model.User;
import lombok.Data;

/**
 * 登录响应DTO
 */
@Data
public class LoginResponse {
    
    /**
     * 用户信息
     */
    private User user;
    
    /**
     * JWT令牌
     */
    private String token;
    
    /**
     * 响应消息
     */
    private String message;
    
    /**
     * 构造函数
     * @param user 用户信息
     * @param token JWT令牌
     * @param message 响应消息
     */
    public LoginResponse(User user, String token, String message) {
        this.user = user;
        this.token = token;
        this.message = message;
    }
}