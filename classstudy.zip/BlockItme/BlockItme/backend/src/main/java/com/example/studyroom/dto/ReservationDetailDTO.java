package com.example.studyroom.dto;

import com.example.studyroom.model.Reservation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 预约详情DTO，包含预约信息和签到时间
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReservationDetailDTO {
    // 预约基本信息
    private Long id;
    private String userId;
    private String stuAdminId;
    private Long seatId;
    private String seatNumber;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String classroomName;
    private Reservation.Status status;
    private String transactionHash;
    private Long blockHeight;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Reservation.DisplayStatus display;
    
    // 签到信息
    private LocalDateTime checkInTime;
    private String checkInStatus;
    
    /**
     * 从Reservation对象创建DTO
     */
    public static ReservationDetailDTO fromReservation(Reservation reservation, LocalDateTime checkInTime, String checkInStatus) {
        ReservationDetailDTO dto = new ReservationDetailDTO();
        dto.setId(reservation.getId());
        dto.setUserId(reservation.getUserId());
        dto.setStuAdminId(reservation.getStuAdminId());
        dto.setSeatId(reservation.getSeatId());
        dto.setSeatNumber(reservation.getSeatNumber());
        dto.setStartTime(reservation.getStartTime());
        dto.setEndTime(reservation.getEndTime());
        dto.setClassroomName(reservation.getClassroomName());
        dto.setStatus(reservation.getStatus());
        dto.setTransactionHash(reservation.getTransactionHash());
        dto.setBlockHeight(reservation.getBlockHeight());
        dto.setCreatedAt(reservation.getCreatedAt());
        dto.setUpdatedAt(reservation.getUpdatedAt());
        dto.setDisplay(reservation.getDisplay());
        dto.setCheckInTime(checkInTime);
        dto.setCheckInStatus(checkInStatus);
        return dto;
    }
}
