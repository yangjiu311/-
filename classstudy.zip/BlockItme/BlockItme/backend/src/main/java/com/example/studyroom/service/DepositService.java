package com.example.studyroom.service;

import java.math.BigDecimal;

/**
 * 押金管理服务接口
 */
public interface DepositService {
    
    /**
     * 获取合约总余额（ETH）
     * @return 合约总余额
     */
    BigDecimal getContractBalance();
    
    /**
     * 获取系统未判定违约的预约押金总金额（ETH）
     * @return 未违约预约押金总额
     */
    BigDecimal getNonViolatedReservationDeposits();
    
    /**
     * 获取签到退还的押金总金额（ETH）
     * @return 签到退还押金总额
     */
    BigDecimal getCheckInRefundedDeposits();
    
    /**
     * 计算总违约金额
     * 公式：总违约金额 = 合约总金额 - (系统未判定违约的预约押金金额 - 签到退还金额)
     * @return 总违约金额
     */
    BigDecimal calculateTotalViolationAmount();
}
