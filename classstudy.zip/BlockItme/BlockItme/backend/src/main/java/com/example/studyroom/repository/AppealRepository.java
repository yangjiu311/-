package com.example.studyroom.repository;

import com.example.studyroom.model.Appeal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AppealRepository extends JpaRepository<Appeal, Long> {
    List<Appeal> findByUserId(String userId);
    Optional<Appeal> findByViolationId(Long violationId);
    List<Appeal> findByAppealStatus(Appeal.AppealStatus appealStatus);
    Optional<Appeal> findByTransactionHash(String transactionHash);
    List<Appeal> findByUserIdAndAppealStatus(String userId, Appeal.AppealStatus appealStatus);
    boolean existsByViolationId(Long violationId);
}