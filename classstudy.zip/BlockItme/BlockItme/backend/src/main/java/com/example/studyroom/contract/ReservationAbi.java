package com.example.studyroom.contract;

import io.reactivex.Flowable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.DynamicArray;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.abi.datatypes.generated.Uint8;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.BaseEventResponse;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tuples.generated.Tuple9;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.9.8.
 */
@SuppressWarnings("rawtypes")
public class ReservationAbi extends Contract {
    public static final String BINARY = "Bin file was not provided";

    public static final String FUNC_CANCELRESERVATION = "cancelReservation";

    public static final String FUNC_CREATERESERVATION = "createReservation";

    public static final String FUNC_GETALLRESERVATIONIDS = "getAllReservationIds";

    public static final String FUNC_GETRESERVATIONCOUNT = "getReservationCount";

    public static final String FUNC_GETRESERVATIONRECORD = "getReservationRecord";

    public static final Event RESERVATIONCANCELLED_EVENT = new Event("ReservationCancelled", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>(true) {}, new TypeReference<Utf8String>() {}));
    ;

    public static final Event RESERVATIONCREATED_EVENT = new Event("ReservationCreated", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>(true) {}, new TypeReference<Utf8String>(true) {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    public static final Event RESERVATIONUPDATED_EVENT = new Event("ReservationUpdated", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>(true) {}, new TypeReference<Uint8>() {}));
    ;

    @Deprecated
    protected ReservationAbi(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected ReservationAbi(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected ReservationAbi(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected ReservationAbi(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static List<ReservationCancelledEventResponse> getReservationCancelledEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = staticExtractEventParametersWithLog(RESERVATIONCANCELLED_EVENT, transactionReceipt);
        ArrayList<ReservationCancelledEventResponse> responses = new ArrayList<ReservationCancelledEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            ReservationCancelledEventResponse typedResponse = new ReservationCancelledEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.userId = (String) eventValues.getNonIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static ReservationCancelledEventResponse getReservationCancelledEventFromLog(Log log) {
        Contract.EventValuesWithLog eventValues = staticExtractEventParametersWithLog(RESERVATIONCANCELLED_EVENT, log);
        ReservationCancelledEventResponse typedResponse = new ReservationCancelledEventResponse();
        typedResponse.log = log;
        typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
        typedResponse.userId = (String) eventValues.getNonIndexedValues().get(0).getValue();
        return typedResponse;
    }

    public Flowable<ReservationCancelledEventResponse> reservationCancelledEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(log -> getReservationCancelledEventFromLog(log));
    }

    public Flowable<ReservationCancelledEventResponse> reservationCancelledEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(RESERVATIONCANCELLED_EVENT));
        return reservationCancelledEventFlowable(filter);
    }

    public static List<ReservationCreatedEventResponse> getReservationCreatedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = staticExtractEventParametersWithLog(RESERVATIONCREATED_EVENT, transactionReceipt);
        ArrayList<ReservationCreatedEventResponse> responses = new ArrayList<ReservationCreatedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            ReservationCreatedEventResponse typedResponse = new ReservationCreatedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.userId = (byte[]) eventValues.getIndexedValues().get(1).getValue();
            typedResponse.seatNumber = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.areaName = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.startTime = (BigInteger) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.endTime = (BigInteger) eventValues.getNonIndexedValues().get(3).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static ReservationCreatedEventResponse getReservationCreatedEventFromLog(Log log) {
        Contract.EventValuesWithLog eventValues = staticExtractEventParametersWithLog(RESERVATIONCREATED_EVENT, log);
        ReservationCreatedEventResponse typedResponse = new ReservationCreatedEventResponse();
        typedResponse.log = log;
        typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
        typedResponse.userId = (byte[]) eventValues.getIndexedValues().get(1).getValue();
        typedResponse.seatNumber = (String) eventValues.getNonIndexedValues().get(0).getValue();
        typedResponse.areaName = (String) eventValues.getNonIndexedValues().get(1).getValue();
        typedResponse.startTime = (BigInteger) eventValues.getNonIndexedValues().get(2).getValue();
        typedResponse.endTime = (BigInteger) eventValues.getNonIndexedValues().get(3).getValue();
        return typedResponse;
    }

    public Flowable<ReservationCreatedEventResponse> reservationCreatedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(log -> getReservationCreatedEventFromLog(log));
    }

    public Flowable<ReservationCreatedEventResponse> reservationCreatedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(RESERVATIONCREATED_EVENT));
        return reservationCreatedEventFlowable(filter);
    }

    public static List<ReservationUpdatedEventResponse> getReservationUpdatedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = staticExtractEventParametersWithLog(RESERVATIONUPDATED_EVENT, transactionReceipt);
        ArrayList<ReservationUpdatedEventResponse> responses = new ArrayList<ReservationUpdatedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            ReservationUpdatedEventResponse typedResponse = new ReservationUpdatedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.status = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static ReservationUpdatedEventResponse getReservationUpdatedEventFromLog(Log log) {
        Contract.EventValuesWithLog eventValues = staticExtractEventParametersWithLog(RESERVATIONUPDATED_EVENT, log);
        ReservationUpdatedEventResponse typedResponse = new ReservationUpdatedEventResponse();
        typedResponse.log = log;
        typedResponse.reservationId = (byte[]) eventValues.getIndexedValues().get(0).getValue();
        typedResponse.status = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
        return typedResponse;
    }

    public Flowable<ReservationUpdatedEventResponse> reservationUpdatedEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(log -> getReservationUpdatedEventFromLog(log));
    }

    public Flowable<ReservationUpdatedEventResponse> reservationUpdatedEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(RESERVATIONUPDATED_EVENT));
        return reservationUpdatedEventFlowable(filter);
    }

    public RemoteFunctionCall<TransactionReceipt> cancelReservation(String reservationId, String userId) {
        final Function function = new Function(
                FUNC_CANCELRESERVATION, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(reservationId), 
                new org.web3j.abi.datatypes.Utf8String(userId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteFunctionCall<TransactionReceipt> createReservation(String reservationId, String userId, String seatNumber, String areaName, BigInteger startTime, BigInteger endTime) {
        final Function function = new Function(
                FUNC_CREATERESERVATION, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(reservationId), 
                new org.web3j.abi.datatypes.Utf8String(userId), 
                new org.web3j.abi.datatypes.Utf8String(seatNumber), 
                new org.web3j.abi.datatypes.Utf8String(areaName), 
                new org.web3j.abi.datatypes.generated.Uint256(startTime), 
                new org.web3j.abi.datatypes.generated.Uint256(endTime)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteFunctionCall<List> getAllReservationIds() {
        final Function function = new Function(FUNC_GETALLRESERVATIONIDS, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<DynamicArray<Utf8String>>() {}));
        return new RemoteFunctionCall<List>(function,
                new Callable<List>() {
                    @Override
                    @SuppressWarnings("unchecked")
                    public List call() throws Exception {
                        List<Type> result = (List<Type>) executeCallSingleValueReturn(function, List.class);
                        return convertToNative(result);
                    }
                });
    }

    public RemoteFunctionCall<BigInteger> getReservationCount() {
        final Function function = new Function(FUNC_GETRESERVATIONCOUNT, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteFunctionCall<Tuple9<String, String, String, String, BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>> getReservationRecord(String reservationId) {
        final Function function = new Function(FUNC_GETRESERVATIONRECORD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(reservationId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint8>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
        return new RemoteFunctionCall<Tuple9<String, String, String, String, BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>>(function,
                new Callable<Tuple9<String, String, String, String, BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>>() {
                    @Override
                    public Tuple9<String, String, String, String, BigInteger, BigInteger, BigInteger, BigInteger, BigInteger> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);
                        return new Tuple9<String, String, String, String, BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>(
                                (String) results.get(0).getValue(), 
                                (String) results.get(1).getValue(), 
                                (String) results.get(2).getValue(), 
                                (String) results.get(3).getValue(), 
                                (BigInteger) results.get(4).getValue(), 
                                (BigInteger) results.get(5).getValue(), 
                                (BigInteger) results.get(6).getValue(), 
                                (BigInteger) results.get(7).getValue(), 
                                (BigInteger) results.get(8).getValue());
                    }
                });
    }

    @Deprecated
    public static ReservationAbi load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new ReservationAbi(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static ReservationAbi load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new ReservationAbi(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static ReservationAbi load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new ReservationAbi(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static ReservationAbi load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new ReservationAbi(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static class ReservationCancelledEventResponse extends BaseEventResponse {
        public byte[] reservationId;

        public String userId;
    }

    public static class ReservationCreatedEventResponse extends BaseEventResponse {
        public byte[] reservationId;

        public byte[] userId;

        public String seatNumber;

        public String areaName;

        public BigInteger startTime;

        public BigInteger endTime;
    }

    public static class ReservationUpdatedEventResponse extends BaseEventResponse {
        public byte[] reservationId;

        public BigInteger status;
    }
}
