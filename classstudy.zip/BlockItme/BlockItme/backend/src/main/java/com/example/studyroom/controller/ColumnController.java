package com.example.studyroom.controller;

import com.example.studyroom.model.SeatColumn;
import com.example.studyroom.service.ColumnService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/columns") // 移除/api前缀，因为context-path已经配置了
@AllArgsConstructor
public class ColumnController {

    private final ColumnService columnService;

    @GetMapping
    public ResponseEntity<List<SeatColumn>> getAllColumns() {
        return ResponseEntity.ok(columnService.getAllColumns());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeatColumn> getColumnById(@PathVariable Long id) {
        Optional<SeatColumn> column = columnService.getColumnById(id);
        return column.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/number/{columnNumber}")
    public ResponseEntity<SeatColumn> getColumnByColumnNumber(@PathVariable Integer columnNumber) {
        Optional<SeatColumn> column = columnService.getColumnByColumnNumber(columnNumber);
        return column.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<SeatColumn> addColumn(@RequestBody SeatColumn column) {
        // 检查列号是否已存在
        if (columnService.existsByColumnNumber(column.getColumnNumber())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        SeatColumn savedColumn = columnService.saveColumn(column);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedColumn);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SeatColumn> updateColumn(@PathVariable Long id, @RequestBody SeatColumn column) {
        Optional<SeatColumn> existingColumn = columnService.getColumnById(id);
        if (existingColumn.isPresent()) {
            column.setId(id);
            SeatColumn updatedColumn = columnService.saveColumn(column);
            return ResponseEntity.ok(updatedColumn);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteColumn(@PathVariable Long id) {
        Optional<SeatColumn> column = columnService.getColumnById(id);
        if (column.isPresent()) {
            columnService.deleteColumn(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}