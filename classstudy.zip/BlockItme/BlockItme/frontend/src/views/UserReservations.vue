<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>预约记录</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 过滤栏区域 -->
      <section class="filter-section">
        <div class="filter-bar">
          <div class="filter-group">
            <label for="status-filter">预约状态</label>
            <select id="status-filter" class="form-control status-select" v-model="statusFilter">
              <option value="">全部状态</option>
              <option value="reserved">已预约</option>
              <option value="active">已签到</option>
              <option value="completed">已完成</option>
              <option value="late">迟到</option>
            </select>
          </div>

          <div class="filter-group">
            <label>预约日期</label>
            <div class="date-range">
              <input type="date" class="form-control date-picker" v-model="startDate" placeholder="开始日期">
              <span class="date-separator">至</span>
              <input type="date" class="form-control date-picker" v-model="endDate" placeholder="结束日期">
            </div>
          </div>
          <div class="filter-actions">
            <button class="primary-btn filter-btn" @click="searchReservations">查询</button>
            <button class="secondary-btn reset-btn" @click="resetFilters">重置</button>
          </div>
        </div>
      </section>

      <!-- 预约记录列表区域 -->
      <section class="reservations-section">
        <div class="reservations-card">
          <h2>我的预约记录</h2>
          <div class="reservations-list">
            <table class="reservations-table">
              <thead>
                <tr>
                  <th>预约ID</th>
                  <th>座位号</th>
                  <th>预约日期</th>
                  <th>预约开始</th>
                  <th>预约结束</th>
                  <th>押金</th>
                  <th class="actions-column">操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="loading">
                  <td colspan="7" class="loading-text">加载中...</td>
                </tr>
                <tr v-else-if="error">
                  <td colspan="7" class="error-text">{{ error }}</td>
                </tr>
                <tr v-else-if="reservations.length === 0">
                  <td colspan="7" class="empty-text">暂无预约记录</td>
                </tr>
                <tr v-for="reservation in reservations" :key="reservation.id">
                  <td>{{ reservation.id }}</td>
                  <td>{{ reservation.seatNumber }}</td>
                  <td>{{ reservation.reservationDate }}</td>
                  <td>{{ reservation.startTime ? new Date(reservation.startTime).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '-' }}</td>
                  <td>{{ reservation.endTime ? new Date(reservation.endTime).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '-' }}</td>
                  <td>{{ reservation.depositAmount || '-' }}</td>
                  <td class="actions-column">
                    <button class="btn-view" @click="viewReservation(reservation.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      查看
                    </button>
                    <button v-if="reservation.status === 'reserved'" class="btn-checkin" @click="checkInReservation(reservation.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                      </svg>
                      签到
                    </button>

                    <button v-if="reservation.status === 'reserved'" class="btn-cancel" @click="cancelReservation(reservation.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      取消
                    </button>

                    <button 
                      class="btn-delete" 
                      @click="deleteReservation(reservation.id)"
                      :disabled="reservation.status === 'active' || reservation.status === 'checked_in'"
                      :class="{ 'btn-disabled': reservation.status === 'active' || reservation.status === 'checked_in' }"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      删除
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- 预约查看功能框 -->
      <div v-if="showViewModal" class="modal-overlay">
        <div class="view-modal">
          <div class="modal-header">
            <h3>预约记录详情</h3>
            <button class="close-btn" @click="showViewModal = false">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
          <div class="modal-body" v-if="selectedReservation">
            <div class="reservation-detail-item">
              <span class="detail-label">预约ID:</span>
              <span class="detail-value">{{ selectedReservation.id }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">用户姓名:</span>
              <span class="detail-value">{{ selectedReservation.userName || '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">学号/管理员ID:</span>
              <span class="detail-value">{{ selectedReservation.stuAdminId || '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">教室名称:</span>
              <span class="detail-value">{{ selectedReservation.classroomName || '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">座位号:</span>
              <span class="detail-value">{{ selectedReservation.seatNumber }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">预约日期:</span>
              <span class="detail-value">{{ selectedReservation.reservationDate }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">预约开始时间:</span>
              <span class="detail-value">{{ selectedReservation.startTime ? new Date(selectedReservation.startTime).toLocaleString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">预约结束时间:</span>
              <span class="detail-value">{{ selectedReservation.endTime ? new Date(selectedReservation.endTime).toLocaleString('zh-CN', { hour: '2-digit', minute: '2-digit' }) : '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">预约状态:</span>
              <span class="detail-value">
                <span :class="['status', selectedReservation.status.toLowerCase()]">
                  {{ selectedReservation.status === 'active' || selectedReservation.status === 'checked_in' ? '已签到' : 
                     selectedReservation.status === 'reserved' ? '已预约' : 
                     selectedReservation.status === 'completed' ? '已完成' : 
                     selectedReservation.status === 'cancelled' ? '已取消' : selectedReservation.status }}
                </span>
              </span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">押金:</span>
              <span class="detail-value">{{ selectedReservation.depositAmount || '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">押金交易哈希:</span>
              <span class="detail-value hash-text">{{ selectedReservation.depositTxHash || '无' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">预约哈希:</span>
              <span class="detail-value hash-text">{{ selectedReservation.transactionHash || '无' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">区块高度:</span>
              <span class="detail-value">{{ selectedReservation.blockHeight || '无' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">创建时间:</span>
              <span class="detail-value">{{ selectedReservation.createdAt ? new Date(selectedReservation.createdAt).toLocaleString('zh-CN') : '-' }}</span>
            </div>
            <div class="reservation-detail-item">
              <span class="detail-label">更新时间:</span>
              <span class="detail-value">{{ selectedReservation.updatedAt ? new Date(selectedReservation.updatedAt).toLocaleString('zh-CN') : '-' }}</span>
            </div>
            
            <!-- 区块链日志信息 -->
            <div v-if="selectedReservation.transactionHash">
              <div class="blockchain-log-info">
                <div class="log-item">
                  <span class="log-label">交易哈希:</span>
                  <span class="log-value" style="word-break: break-all; font-family: monospace; font-size: 12px;">{{ selectedReservation.transactionHash }}</span>
                </div>
                <div v-if="blockchainLogLoading" class="loading-info">
                  加载区块链日志中...
                </div>
                <div v-else-if="blockchainLogError" class="error-info">
                  {{ blockchainLogError }}
                </div>
                <div v-else-if="blockchainLogData" class="blockchain-log-details">
                  <div class="log-item">
                    <span class="log-label">区块高度:</span>
                    <span class="log-value">{{ blockchainLogData.blockHeight || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">操作类型:</span>
                    <span class="log-value">{{ blockchainLogData.operationType || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">状态:</span>
                    <span class="log-value">{{ blockchainLogData.status || '-' }}</span>
                  </div>
                  <div class="log-item">
                    <span class="log-label">创建时间:</span>
                    <span class="log-value">{{ blockchainLogData.createdAt ? new Date(blockchainLogData.createdAt).toLocaleString('zh-CN') : '-' }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="primary-btn" @click="showViewModal = false">关闭</button>
          </div>
        </div>
      </div>


    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { getUserReservations, cancelReservation as cancelReservationAPI, checkInReservation as checkInReservationAPI, deleteReservation as deleteReservationAPI } from '../services/api'
import axios from 'axios'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)



// 过滤条件
const startDate = ref('')
const endDate = ref('')
const statusFilter = ref('')

// 组件挂载时获取预约记录
onMounted(() => {
  fetchUserReservations()
})

// 预约记录列表
const reservations = ref([])

// 加载状态
const loading = ref(false)

// 错误信息
const error = ref(null)

// 获取用户预约记录
const fetchUserReservations = async () => {
  if (!userStore.userInfo?.userId) {
    console.error('用户未登录或用户ID不存在')
    return
  }
  
  loading.value = true
  error.value = null
  
  try {
    const data = await getUserReservations(userStore.userInfo.userId)
    reservations.value = data
    console.log('获取用户预约记录成功:', data)
  } catch (err) {
    console.error('获取用户预约记录失败:', err)
    error.value = '获取预约记录失败，请稍后重试'
  } finally {
    loading.value = false
  }
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 查询预约记录
const searchReservations = async () => {
  if (!userStore.userInfo?.userId) {
    console.error('用户未登录或用户ID不存在')
    return
  }
  
  loading.value = true
  error.value = null
  
  try {
    const data = await getUserReservations(userStore.userInfo.userId)
    
    // 应用所有过滤条件
    reservations.value = data.filter(reservation => {
      // 状态过滤
      if (statusFilter.value) {
        let mappedStatus = reservation.status
        if (reservation.status === 'active' || reservation.status === 'checked_in') {
          mappedStatus = 'active'
        }
        if (mappedStatus !== statusFilter.value) {
          return false
        }
      }
      

      
      // 日期范围过滤
      if (startDate.value) {
        const reservationDate = new Date(reservation.reservationDate)
        const start = new Date(startDate.value)
        if (reservationDate < start) {
          return false
        }
      }
      
      if (endDate.value) {
        const reservationDate = new Date(reservation.reservationDate)
        const end = new Date(endDate.value)
        if (reservationDate > end) {
          return false
        }
      }
      
      return true
    })
    
    console.log('查询预约记录成功:', reservations.value)
  } catch (err) {
    console.error('查询预约记录失败:', err)
    error.value = '查询预约记录失败，请稍后重试'
  } finally {
    loading.value = false
  }
}

// 重置过滤器
const resetFilters = () => {
  // 重置过滤条件
  startDate.value = ''
  endDate.value = ''
  statusFilter.value = ''
  // 重新获取数据
  fetchUserReservations()
}

// 预约查看模态框相关数据
const showViewModal = ref(false)
const selectedReservation = ref(null)
const blockchainLogData = ref(null)
const blockchainLogLoading = ref(false)
const blockchainLogError = ref(null)

// 获取区块链日志
const fetchBlockchainLog = async (transactionHash) => {
  if (!transactionHash) {
    blockchainLogData.value = null
    return
  }
  
  blockchainLogLoading.value = true
  blockchainLogError.value = null
  
  try {
    const response = await axios.get(`/api/blockchain-logs/reservation-info/${transactionHash}`)
    blockchainLogData.value = response.data
    console.log('获取区块链日志成功:', response.data)
  } catch (err) {
    console.error('获取区块链日志失败:', err)
    blockchainLogError.value = '获取区块链日志失败'
    blockchainLogData.value = null
  } finally {
    blockchainLogLoading.value = false
  }
}

// 查看预约详情
const viewReservation = async (reservationId) => {
  console.log('查看预约详情:', reservationId)
  // 查找当前点击行对应的预约记录
  const reservation = reservations.value.find(r => r.id === reservationId)
  if (reservation) {
    selectedReservation.value = reservation
    showViewModal.value = true
    // 获取区块链日志
    if (reservation.transactionHash) {
      await fetchBlockchainLog(reservation.transactionHash)
    }
  } else {
    console.error('未找到对应的预约记录')
  }
}

// 取消预约
const cancelReservation = async (reservationId) => {
  if (confirm('确定要取消该预约吗？')) {
    loading.value = true
    try {
      await cancelReservationAPI(reservationId)
      console.log('取消预约成功:', reservationId)
      // 重新获取预约记录列表
      await fetchUserReservations()
      alert('预约已成功取消')
    } catch (err) {
      console.error('取消预约失败:', err)
      alert('取消预约失败，请稍后重试')
    } finally {
      loading.value = false
    }
  }
}

// 签到预约
const checkInReservation = async (reservationId) => {
  if (confirm('确定要签到该预约吗？')) {
    loading.value = true
    try {
      // 获取预约信息，找到用户钱包地址
      const reservation = reservations.value.find(r => r.id === reservationId)
      if (!reservation) {
        alert('未找到预约信息')
        loading.value = false
        return
      }
      
      // 检查钱包地址
      if (!userStore.walletAddress) {
        alert('请先连接钱包')
        loading.value = false
        return
      }
      
      console.log('准备发起押金退还交易...')
      
      // 智能合约地址（已部署）
      const depositManagerContractAddress = '0x9fEfb53DC3f9170018c7eF660c6b9023736A3CcC'
      
      // 智能合约ABI（包含refund函数和userDeposits状态变量）
      const depositManagerAbi = [
        {
          "inputs": [],
          "name": "refund",
          "outputs": [],
          "stateMutability": "nonpayable",
          "type": "function"
        },
        {
          "inputs": [{"internalType": "address", "name": "", "type": "address"}],
          "name": "userDeposits",
          "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
          "stateMutability": "view",
          "type": "function"
        }
      ]
      
      // 检查MetaMask是否连接
      if (window.ethereum) {
        try {
          // 获取当前账户
          const accounts = await window.ethereum.request({ method: 'eth_accounts' })
          if (accounts && accounts.length > 0) {
            console.log('当前MetaMask账户:', accounts[0])
            
            // 创建合约实例
            const contract = new userStore.web3.eth.Contract(depositManagerAbi, depositManagerContractAddress)
            
            // 先检查用户是否有押金
            try {
              const depositAmount = await contract.methods.userDeposits(accounts[0]).call()
              console.log('用户押金余额:', userStore.web3.utils.fromWei(depositAmount, 'ether'), 'ETH')
              
              if (depositAmount === '0') {
                alert('您没有押金记录，无法退还押金')
                loading.value = false
                return
              }
            } catch (error) {
              console.error('检查押金余额失败:', error)
              // 跳过押金检查，直接尝试退还押金
              console.log('跳过押金检查，直接尝试退还押金...')
            }
            
            // 构建合约调用交易
            const transaction = {
              from: accounts[0],
              to: depositManagerContractAddress,
              data: contract.methods.refund().encodeABI() // 调用无参数的refund函数
              // gas和gasPrice由MetaMask自动处理
            }
            
            console.log('发送押金退还交易:', transaction)
            
            // 发送交易
            const txHash = await window.ethereum.request({
              method: 'eth_sendTransaction',
              params: [transaction]
            })
            
            console.log('押金退还交易成功，交易哈希:', txHash)
            
            // 押金退还成功后，再执行签到，传递押金退还交易哈希
            await checkInReservationAPI(reservationId, txHash)
            console.log('签到预约成功:', reservationId)
            
            // 重新获取用户预约列表以更新状态
            await fetchUserReservations()
            
            alert('签到成功！押金已退还，交易哈希: ' + txHash)
          } else {
            console.error('MetaMask未连接')
            alert('押金退还失败：MetaMask未连接，签到流程已中断')
          }
        } catch (txError) {
          console.error('押金退还交易失败:', txError)
          alert('押金退还失败：' + (txError.message || '交易失败') + '，签到流程已中断')
        }
      } else {
        console.error('MetaMask未安装')
        alert('押金退还失败：请安装MetaMask扩展，签到流程已中断')
      }
    } catch (error) {
      console.error('签到预约失败:', error)
      // 显示错误提示
      alert('操作失败: ' + (error.response?.data?.message || error.message))
    } finally {
      loading.value = false
    }
  }
}

// 删除预约
const deleteReservation = async (reservationId) => {
  if (confirm('确定要删除该预约吗？')) {
    loading.value = true
    try {
      await deleteReservationAPI(reservationId)
      console.log('删除预约成功:', reservationId)
      // 重新获取预约记录列表
      await fetchUserReservations()
      alert('预约已成功删除')
    } catch (err) {
      console.error('删除预约失败:', err)
      alert('删除预约失败，请稍后重试')
    } finally {
      loading.value = false
    }
  }
}


</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.main-content::-webkit-scrollbar {
  width: 8px;
}

.main-content::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.main-content::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

.main-content::-webkit-scrollbar-thumb:hover {
  background: #a1a1a1;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

/* 过滤栏区域样式 */
.filter-section {
  padding: 20px 30px 0 30px;
}

.filter-bar {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.filter-group {
  flex: 1;
  min-width: 200px;
}

.filter-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  color: #495057;
  font-size: 14px;
}

.date-range {
  display: flex;
  align-items: center;
  gap: 10px;
}

.date-separator {
  color: #6c757d;
  font-size: 14px;
}

.form-control {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  border-color: #4CAF50;
  outline: none;
  box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25);
}

.date-picker {
  width: calc(50% - 15px);
}

.search-input {
  padding-left: 32px;
  background-image: url("data:image/svg+xml,%3Csvg width='16' height='16' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z' stroke='%236c757d' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M21 21L16.65 16.65' stroke='%236c757d' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: 10px center;
}

.filter-actions {
  display: flex;
  gap: 15px;
  align-items: flex-end;
}

.primary-btn,
.secondary-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
  border: none;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.secondary-btn {
  background-color: white;
  color: #4CAF50;
  border: 1px solid #4CAF50;
}

.secondary-btn:hover {
  background-color: #f1f8e9;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.2);
}

/* 预约记录列表区域样式 */
.reservations-section {
  padding: 20px 30px;
}

.reservations-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.reservations-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.reservations-list {
  overflow-x: auto;
}

.reservations-table {
  width: 100%;
  border-collapse: collapse;
}

.reservations-table th,
.reservations-table td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #e0e0e0;
  font-size: 14px;
}

.reservations-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
  text-align: center;
}

.reservations-table tr:hover {
  background-color: #f5f5f5;
}

/* 状态列样式 */
.status-column {
  min-width: 100px;
  white-space: nowrap;
}

.hash-column {
  min-width: 250px;
  white-space: nowrap;
}

.status {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
  display: inline-block;
}

.status.active,
.status.checked_in {
  background-color: #d4edda;
  color: #155724;
}

.status.reserved {
  background-color: #fff3cd;
  color: #856404;
}

.status.completed {
  background-color: #d1ecf1;
  color: #0c5460;
}

.status.cancelled {
  background-color: #f8d7da;
  color: #721c24;
}

/* 操作列样式 */
.actions-column {
  min-width: 120px;
  white-space: nowrap;
}

.btn-view,
.btn-cancel,
.btn-checkin,
.btn-delete {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 6px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  transition: all 0.3s ease;
  border: none;
  margin-right: 5px;
}

.btn-view {
  background-color: #e9ecef;
  color: #495057;
}

.btn-view:hover {
  background-color: #dee2e6;
}

.btn-cancel {
  background-color: #f8d7da;
  color: #721c24;
}

.btn-checkin {
  background-color: #d4edda;
  color: #155724;
}

.btn-checkin:hover {
  background-color: #c3e6cb;
}

.btn-delete {
  background-color: #f8d7da;
  color: #721c24;
}

.btn-delete:hover {
  background-color: #f5c6cb;
}

.btn-cancel:hover {
  background-color: #f5c6cb;
}



/* 用户信息和下拉菜单样式 */
.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 预约查看功能框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.view-modal {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  background-color: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
  position: sticky;
  top: 0;
  z-index: 10;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #495057;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: background-color 0.3s ease;
}

.close-btn:hover {
  background-color: #e9ecef;
}

.modal-body {
  padding: 20px;
}

.reservation-detail-item {
  display: flex;
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.reservation-detail-item:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.detail-label {
  width: 120px;
  font-weight: 600;
  color: #495057;
  margin-right: 10px;
  flex-shrink: 0;
}

.detail-value {
  flex: 1;
  color: #6c757d;
}

.hash-text {
  white-space: normal;
  word-break: break-all;
}

/* 区块链日志样式 */
.blockchain-log-info {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 15px;
  margin-top: 15px;
  border: 1px solid #e9ecef;
}

.log-item {
  display: flex;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e0e0e0;
}

.log-item:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.log-label {
  width: 100px;
  font-weight: 600;
  color: #495057;
  flex-shrink: 0;
}

.log-value {
  flex: 1;
  color: #6c757d;
}

.loading-info,
.error-info {
  text-align: center;
  padding: 15px;
  margin-top: 15px;
  border-radius: 8px;
  font-size: 14px;
}

.loading-info {
  background-color: #e3f2fd;
  color: #1976d2;
  border: 1px solid #bbdefb;
}

.error-info {
  background-color: #ffebee;
  color: #c62828;
  border: 1px solid #ffcdd2;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  padding: 16px 20px;
  background-color: #f8f9fa;
  border-top: 1px solid #e9ecef;
  position: sticky;
  bottom: 0;
  z-index: 10;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: auto;
  }

  .nav-menu {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    padding: 0;
  }

  .nav-item {
    flex: 0 0 auto;
  }

  .filter-bar {
    flex-direction: column;
  }

  .filter-group {
    width: 100%;
  }

  .date-range {
    flex-direction: column;
    align-items: stretch;
  }

  .date-picker {
    width: 100% !important;
  }

  .filter-actions {
    width: 100%;
  }

  .primary-btn,
  .secondary-btn {
    width: 100%;
    justify-content: center;
  }

  .reservations-table {
    font-size: 12px;
  }

  .reservations-table th,
  .reservations-table td {
    padding: 8px;
  }

  .pagination-section {
    flex-direction: column;
    align-items: center;
  }

  .pagination-controls {
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>