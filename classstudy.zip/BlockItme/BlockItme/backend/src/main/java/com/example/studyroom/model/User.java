package com.example.studyroom.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "user")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 50)
    @Column(name = "user_id", unique = true, nullable = false)
    private String userId;

    @NotNull
    @Size(max = 255)
    @Column(nullable = false)
    private String password;

    @Size(max = 100)
    @Column(name = "wallet_address", unique = true)
    private String walletAddress;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @NotNull
    @Size(max = 50)
    @Column(nullable = false)
    private String name;

    @Size(max = 50)
    @Column(name = "stu_admin_id")
    @JsonProperty("stu_admin_id")
    private String studentId;

    @Email
    @Size(max = 100)
    private String email;

    @Size(max = 20)
    private String phone;

    @Column(name = "balance", precision = 10, scale = 2)
    private BigDecimal balance;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "enum('enabled','disabled') default 'enabled'", nullable = false)
    private Status status;

    @NotNull
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "deleted", nullable = false)
    @Builder.Default
    private Boolean deleted = false;

    public enum Role {
        student, admin
    }

    public enum Status {
        enabled, disabled
    }
}


