package com.example.studyroom.service.impl;

import com.example.studyroom.dto.ReservationDetailDTO;
import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.model.CheckIn;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.Seat;
import com.example.studyroom.model.User;
import com.example.studyroom.repository.ReservationRepository;
import com.example.studyroom.model.Violation;
import com.example.studyroom.service.BlockchainService;
import com.example.studyroom.service.CheckInService;
import com.example.studyroom.service.ReservationService;
import com.example.studyroom.service.SeatService;
import com.example.studyroom.service.UserService;
import com.example.studyroom.service.ViolationService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ReservationServiceImpl implements ReservationService {
    private final ReservationRepository reservationRepository;
    private final BlockchainService blockchainService;
    private final SeatService seatService;
    private final UserService userService;
    private final CheckInService checkInService;
    private final ViolationService violationService;

    @Override
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    // 新增：获取所有预约详情（包含签到信息）
    @Override
    public List<ReservationDetailDTO> getAllReservationDetails() {
        List<Reservation> reservations = reservationRepository.findAll();
        
        return reservations.stream().map(reservation -> {
            // 查找对应的签到记录
            Optional<CheckIn> checkInOptional = checkInService.getCheckInByReservationId(reservation.getId());
            
            LocalDateTime checkInTime = null;
            String checkInStatus = null;
            
            if (checkInOptional.isPresent()) {
                CheckIn checkIn = checkInOptional.get();
                checkInTime = checkIn.getActualCheckInTime();
                checkInStatus = checkIn.getStatus() != null ? checkIn.getStatus().name() : null;
            }
            
            return ReservationDetailDTO.fromReservation(reservation, checkInTime, checkInStatus);
        }).collect(Collectors.toList());
    }

    @Override
    public Optional<Reservation> getReservationById(@NonNull Long id) {
        return reservationRepository.findById(id);
    }

    @Override
    public List<Reservation> getReservationsByUserId(@NonNull String userId) {
        List<Reservation> reservations = reservationRepository.findByUserIdAndDisplay(userId, Reservation.DisplayStatus.TRUE);
        // 为每个预约记录添加用户姓名信息
        reservations.forEach(reservation -> {
            Optional<User> user = userService.getUserByUserId(reservation.getUserId());
            if (user.isPresent()) {
                // 使用反射添加userName字段，避免修改Reservation模型
                try {
                    java.lang.reflect.Field field = Reservation.class.getDeclaredField("userName");
                    field.setAccessible(true);
                    field.set(reservation, user.get().getName());
                } catch (Exception e) {
                    System.out.println("Error adding userName to reservation: " + e.getMessage());
                }
            }
        });
        return reservations;
    }

    @Override
    public List<Reservation> getReservationsBySeatId(@NonNull Long seatId) {
        return reservationRepository.findBySeatId(seatId);
    }

    @Override
    public List<Reservation> getReservationsByStatus(@NonNull Reservation.Status status) {
        return reservationRepository.findByStatus(status);
    }

    @Override
    public List<Reservation> getReservationsByUserIdAndStatus(@NonNull String userId, @NonNull Reservation.Status status) {
        return reservationRepository.findByUserIdAndStatus(userId, status);
    }

    @Override
    public List<Reservation> getReservationsByDateTimeRange(@NonNull LocalDateTime startDateTime, @NonNull LocalDateTime endDateTime) {
        return reservationRepository.findByStartTimeBetween(startDateTime, endDateTime);
    }

    @Override
    public List<Reservation> getReservationsBySeatIdAndDateTimeRange(@NonNull Long seatId, @NonNull LocalDateTime startDateTime, @NonNull LocalDateTime endDateTime) {
        return reservationRepository.findBySeatIdAndStartTimeBetween(seatId, startDateTime, endDateTime);
    }

    @Override
    public Reservation createReservation(@NonNull Reservation reservation) {
        // Check if seat is available
        if (!isSeatAvailable(reservation.getSeatId(), reservation.getStartTime(), reservation.getEndTime())) {
            throw new RuntimeException("Seat is not available for the selected time slot");
        }
        // Retrieve the seat to get seatNumber and classroomName
        Optional<Seat> optionalSeat = seatService.getSeatById(reservation.getSeatId());
        if (!optionalSeat.isPresent()) {
            throw new RuntimeException("Seat not found with id: " + reservation.getSeatId());
        }
        Seat seat = optionalSeat.get();
        // 设置区域号（classroomName）
        reservation.setClassroomName(seat.getClassroomName());

        // Retrieve the user to get studentId for foreign key constraint
        Optional<User> optionalUser = userService.getUserByUserId(reservation.getUserId());
        if (!optionalUser.isPresent()) {
            throw new RuntimeException("User not found with userId: " + reservation.getUserId());
        }
        User user = optionalUser.get();

        reservation.setCreatedAt(LocalDateTime.now());
        // 设置stuAdminId为用户的studentId，如果studentId为null则使用userId
        reservation.setStuAdminId(user.getStudentId() != null ? user.getStudentId() : user.getUserId());
        // 设置seatNumber为seat对象的seatNumber
        reservation.setSeatNumber(seat.getSeatNumber());
        // 设置reservation_date为startTime的日期部分
        reservation.setReservationDate(reservation.getStartTime().toLocalDate());
        
        // Upload reservation to database first
        Reservation savedReservation = reservationRepository.save(reservation);
        
        // Update seat status to reserved
        seat.setStatus(Seat.Status.reserved);
        seatService.updateSeat(seat.getId(), seat);
        
        // Upload reservation to blockchain
        try {
            BlockchainLog blockchainLog = blockchainService.uploadToBlockchain(
                    savedReservation,
                    savedReservation.getUserId(),
                    savedReservation.getStuAdminId(),
                    savedReservation.getId(),
                    BlockchainLog.OperationType.reservation
            );
            if (blockchainLog != null && blockchainLog.getStatus() == BlockchainLog.Status.success && blockchainLog.getTransactionHash() != null) {
                // Update reservation with transaction hash and block height
                savedReservation.setTransactionHash(blockchainLog.getTransactionHash());
                savedReservation.setBlockHeight(blockchainLog.getBlockHeight());
            } else {
                // Blockchain upload failed but we continue with the reservation
                System.out.println("Warning: Blockchain upload failed for reservation " + savedReservation.getId() + ", but reservation was created successfully");
                savedReservation.setTransactionHash("local_" + System.currentTimeMillis());
                savedReservation.setBlockHeight(null);
            }
        } catch (Exception e) {
            // Handle blockchain errors gracefully - don't fail the reservation
            System.out.println("Warning: Blockchain service error for reservation " + savedReservation.getId() + ": " + e.getMessage());
            savedReservation.setTransactionHash("error_" + System.currentTimeMillis());
            savedReservation.setBlockHeight(null);
        }
        
        // 注意：押金现在通过智能合约管理，不需要从用户数据库余额中扣除
        // 用户已经通过MetaMask支付了押金到智能合约
        
        return reservationRepository.save(savedReservation);
    }

    @Override
    public Reservation updateReservation(@NonNull Long id, @NonNull Reservation reservation) {
        Optional<Reservation> existingReservation = reservationRepository.findById(id);
        if (existingReservation.isPresent()) {
            Reservation updatedReservation = existingReservation.get();
            
            // 保存更新前的状态
            Reservation.Status oldStatus = updatedReservation.getStatus();
            
            // 更新预约信息
            updatedReservation.setUserId(reservation.getUserId());
            updatedReservation.setSeatId(reservation.getSeatId());
            updatedReservation.setStartTime(reservation.getStartTime());
            updatedReservation.setEndTime(reservation.getEndTime());
            updatedReservation.setStatus(reservation.getStatus());
            updatedReservation.setTransactionHash(reservation.getTransactionHash());
            updatedReservation.setDepositTxHash(reservation.getDepositTxHash());
            updatedReservation.setUpdatedAt(LocalDateTime.now());
            
            // 保存更新后的预约
        Reservation savedReservation = reservationRepository.save(updatedReservation);
        
        // 如果状态从其他状态变为"已完成"，则更新对应座位状态为"可用"
        if (oldStatus != Reservation.Status.completed && 
            savedReservation.getStatus() == Reservation.Status.completed) {
            Optional<Seat> optionalSeat = seatService.getSeatById(savedReservation.getSeatId());
            if (optionalSeat.isPresent()) {
                Seat seat = optionalSeat.get();
                seat.setStatus(Seat.Status.available);
                seatService.updateSeat(seat.getId(), seat);
            }
        }
        
        // 如果状态从其他状态变为"违规"，则创建违约记录
        if (oldStatus != Reservation.Status.violated && 
            savedReservation.getStatus() == Reservation.Status.violated) {
            // 检查是否已经存在对应的违约记录
            if (!violationService.existsByReservationId(savedReservation.getId())) {
                // 创建违约记录
                Violation violation = new Violation();
                violation.setUserId(savedReservation.getUserId());
                violation.setReservationId(savedReservation.getId());
                violation.setViolationType(Violation.ViolationType.other); // 默认违约类型，可根据实际情况调整
                violation.setViolationTime(LocalDateTime.now());
                violation.setStatus(Violation.Status.unpaid);
                violation.setPenaltyAmount(java.math.BigDecimal.valueOf(0)); // 默认罚款金额，可根据实际情况调整
                violation.setSeatNumber(savedReservation.getSeatNumber());
                violation.setClassroomName(savedReservation.getClassroomName());
                violation.setCreatedAt(LocalDateTime.now());
                
                // 保存违约记录
                violationService.createViolation(violation);
                
                // 将对应的座位状态改为可用
                try {
                    Optional<Seat> seatOptional = seatService.getSeatBySeatNumber(savedReservation.getSeatNumber());
                    if (seatOptional.isPresent()) {
                        Seat seat = seatOptional.get();
                        seat.setStatus(Seat.Status.available);
                        seat.setUpdatedAt(LocalDateTime.now());
                        seatService.updateSeat(seat.getId(), seat);
                        System.out.println("Seat " + seat.getSeatNumber() + " status changed to available due to violation");
                    }
                } catch (Exception e) {
                    System.out.println("Failed to update seat status: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
            
            return savedReservation;
        }
        throw new RuntimeException("Reservation not found with id: " + id);
    }

    @Override
    public void deleteReservation(@NonNull Long id) {
        // 将预约记录软删除（display字段改为false）
        reservationRepository.updateDisplayByReservationId(id, false);
    }

    @Override
    public boolean isSeatAvailable(@NonNull Long seatId, @NonNull LocalDateTime startTime, @NonNull LocalDateTime endTime) {
        // 查找时间冲突的预约
        List<Reservation> allReservations = reservationRepository.findBySeatId(seatId);
        // 过滤掉已完成、已取消、违规状态的预约，并检查时间冲突
        return allReservations.stream()
                .filter(res -> res.getStatus() != Reservation.Status.completed 
                        && res.getStatus() != Reservation.Status.cancelled 
                        && res.getStatus() != Reservation.Status.violated)
                .filter(res -> res.getStartTime().isBefore(endTime) && res.getEndTime().isAfter(startTime))
                .findFirst()
                .isEmpty();
    }

    @Override
    public List<Reservation> getRecentReservations() {
        return reservationRepository.findTop5ByOrderByStartTimeDesc();
    }

    @Override
    public List<Reservation> getUserRecentReservations(@NonNull String userId) {
        return reservationRepository.findTop5ByUserIdOrderByStartTimeDesc(userId);
    }

    @Override
    public Reservation checkInReservation(@NonNull Long id) {
        return checkInReservation(id, null);
    }
    
    @Override
    public Reservation checkInReservation(@NonNull Long id, String depositRefundTxHash) {
        Optional<Reservation> optionalReservation = reservationRepository.findById(id);
        if (!optionalReservation.isPresent()) {
            throw new RuntimeException("Reservation not found with id: " + id);
        }
        
        Reservation reservation = optionalReservation.get();
        
        // 检查预约状态，如果是违规状态则不允许签到
        if (reservation.getStatus() == Reservation.Status.violated) {
            throw new RuntimeException("违规状态的预约不允许签到");
        }
        
        LocalDateTime now = LocalDateTime.now();
        
        // 创建签到记录
        CheckIn checkIn = new CheckIn();
        checkIn.setReservationId(id);
        checkIn.setUserId(reservation.getUserId());
        checkIn.setStuAdminId(reservation.getStuAdminId());
        checkIn.setActualCheckInTime(now);
        // 设置押金退还交易哈希
        checkIn.setDepositRefundTxHash(depositRefundTxHash);
        
        // 判断是否迟到（超过预约开始时间15分钟）
        boolean isLate = now.isAfter(reservation.getStartTime().plusMinutes(15));
        
        if (isLate) {
            checkIn.setStatus(CheckIn.Status.late);
            
            // 迟到超过15分钟，创建违约记录
            System.out.println("User is late by more than 15 minutes, creating violation record");
            
            // 检查是否已经存在对应的违约记录
            if (!violationService.existsByReservationId(reservation.getId())) {
                // 创建违约记录
                Violation violation = new Violation();
                violation.setUserId(reservation.getUserId());
                violation.setStuAdminId(reservation.getStuAdminId()); // 设置stu_admin_id
                violation.setReservationId(reservation.getId());
                violation.setViolationType(Violation.ViolationType.long_late); // 设置为迟到类型
                violation.setViolationTime(now);
                violation.setStatus(Violation.Status.unpaid);
                violation.setPenaltyAmount(java.math.BigDecimal.valueOf(0)); // 默认罚款金额
                violation.setSeatNumber(reservation.getSeatNumber());
                violation.setClassroomName(reservation.getClassroomName());
                violation.setCreatedAt(now);
                
                // 保存违约记录
                Violation savedViolation = violationService.createViolation(violation);
                
                // 更新预约状态为违规
                reservation.setStatus(Reservation.Status.violated);
                
                // 将对应的座位状态改为可用
                try {
                    Optional<Seat> seatOptional = seatService.getSeatBySeatNumber(reservation.getSeatNumber());
                    if (seatOptional.isPresent()) {
                        Seat seat = seatOptional.get();
                        seat.setStatus(Seat.Status.available);
                        seat.setUpdatedAt(now);
                        seatService.updateSeat(seat.getId(), seat);
                        System.out.println("Seat " + seat.getSeatNumber() + " status changed to available due to violation");
                    }
                } catch (Exception e) {
                    System.out.println("Failed to update seat status: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        } else {
            checkIn.setStatus(CheckIn.Status.checked_in);
        }
        
        // 设置创建时间
        checkIn.setCreatedAt(now);
        
        // 设置区域号和座位号
        checkIn.setClassroomName(reservation.getClassroomName());
        checkIn.setSeatNumber(reservation.getSeatNumber());
        
        // 将签到信息上传到区块链
        try {
            BlockchainLog blockchainLog = blockchainService.uploadToBlockchain(
                    checkIn,
                    checkIn.getUserId(),
                    checkIn.getStuAdminId(),
                    checkIn.getId(),
                    BlockchainLog.OperationType.check_in
            );
            
            // 设置区块链交易哈希和区块高度
            if (blockchainLog != null && blockchainLog.getStatus() == BlockchainLog.Status.success && blockchainLog.getTransactionHash() != null) {
                checkIn.setTransactionHash(blockchainLog.getTransactionHash());
                checkIn.setBlockHeight(blockchainLog.getBlockHeight());
            } else {
                // Blockchain upload failed but we continue with check-in
                System.out.println("Warning: Blockchain upload failed for check-in, but check-in was processed successfully");
                checkIn.setTransactionHash("local_checkin_" + System.currentTimeMillis());
                checkIn.setBlockHeight(null);
            }
        } catch (Exception e) {
            // Handle blockchain errors gracefully - don't fail the check-in
            System.out.println("Warning: Blockchain service error for check-in: " + e.getMessage());
            checkIn.setTransactionHash("error_checkin_" + System.currentTimeMillis());
            checkIn.setBlockHeight(null);
        }
        
        // 保存签到记录到数据库（只保存一次）
        CheckIn savedCheckIn = checkInService.createCheckIn(checkIn);
        
        // 根据签到状态更新预约状态
        if (isLate) {
            // 如果迟到，更新预约状态为违规
            reservation.setStatus(Reservation.Status.violated);
        } else {
            // 否则更新为已签到
            reservation.setStatus(Reservation.Status.checked_in);
        }
        reservationRepository.save(reservation);
        
        // 退还押金到用户余额
        String depositAmountStr = reservation.getDepositAmount();
        if (depositAmountStr != null && !depositAmountStr.isEmpty()) {
            try {
                BigDecimal depositAmount = new BigDecimal(depositAmountStr);
                if (depositAmount.compareTo(BigDecimal.ZERO) > 0) {
                    Optional<User> optionalUser = userService.getUserByUserId(reservation.getUserId());
                    if (optionalUser.isPresent()) {
                        User user = optionalUser.get();
                        BigDecimal currentBalance = user.getBalance() != null ? user.getBalance() : BigDecimal.ZERO;
                        user.setBalance(currentBalance.add(depositAmount));
                        userService.updateUser(user.getId(), user);
                    }
                }
            } catch (NumberFormatException e) {
                // 处理转换错误
                e.printStackTrace();
            }
        }
        
        // 更新对应座位状态为used(已占用)
        Optional<Seat> optionalSeat = seatService.getSeatById(reservation.getSeatId());
        if (optionalSeat.isPresent()) {
            Seat seat = optionalSeat.get();
            seat.setStatus(Seat.Status.used);
            seatService.updateSeat(seat.getId(), seat);
        }
        
        return reservation;
    }
    
    @Override
    public Reservation cancelReservation(@NonNull Long id) {
        Optional<Reservation> optionalReservation = reservationRepository.findById(id);
        if (!optionalReservation.isPresent()) {
            throw new RuntimeException("Reservation not found with id: " + id);
        }
        
        Reservation reservation = optionalReservation.get();
        
        // 将预约状态改为"取消"
        reservation.setStatus(Reservation.Status.cancelled);
        reservation.setUpdatedAt(LocalDateTime.now());
        
        // 保存预约记录
        Reservation savedReservation = reservationRepository.save(reservation);
        
        // 更新对应座位状态为可用
        Optional<Seat> optionalSeat = seatService.getSeatById(reservation.getSeatId());
        if (optionalSeat.isPresent()) {
            Seat seat = optionalSeat.get();
            seat.setStatus(Seat.Status.available);
            seatService.updateSeat(seat.getId(), seat);
        }
        
        return savedReservation;
    }
    
    @Override
    public Reservation updateDisplayStatus(@NonNull Long id, @NonNull Reservation.DisplayStatus displayStatus) {
        Optional<Reservation> optionalReservation = reservationRepository.findById(id);
        if (!optionalReservation.isPresent()) {
            throw new RuntimeException("Reservation not found with id: " + id);
        }
        
        Reservation reservation = optionalReservation.get();
        
        // 更新display字段
        reservation.setDisplay(displayStatus);
        reservation.setUpdatedAt(LocalDateTime.now());
        
        // 保存预约记录
        Reservation savedReservation = reservationRepository.save(reservation);
        
        // 如果display字段被设置为FALSE，则更新对应座位状态为可用
        if (displayStatus == Reservation.DisplayStatus.FALSE) {
            Optional<Seat> optionalSeat = seatService.getSeatById(reservation.getSeatId());
            if (optionalSeat.isPresent()) {
                Seat seat = optionalSeat.get();
                seat.setStatus(Seat.Status.available);
                seatService.updateSeat(seat.getId(), seat);
            }
        }
        
        return savedReservation;
    }
    
    @Override
    public int updateExpiredReservations() {
        LocalDateTime now = LocalDateTime.now();
        
        // 查询所有结束时间小于当前时间的预约（排除已完成、已取消、违规状态）
        List<Reservation> allReservations = reservationRepository.findAll();
        
        int updatedCount = 0;
        
        // 将这些预约的状态更新为completed，并更新对应座位状态为available
        for (Reservation reservation : allReservations) {
            // 如果预约结束时间小于当前时间，且状态不是已完成、已取消、违规
            if (reservation.getEndTime().isBefore(now) && 
                reservation.getStatus() != Reservation.Status.completed && 
                reservation.getStatus() != Reservation.Status.cancelled && 
                reservation.getStatus() != Reservation.Status.violated) {
                reservation.setStatus(Reservation.Status.completed);
                reservation.setUpdatedAt(now);
                reservationRepository.save(reservation);
                
                // 更新对应座位状态为可用
                Optional<Seat> optionalSeat = seatService.getSeatById(reservation.getSeatId());
                if (optionalSeat.isPresent()) {
                    Seat seat = optionalSeat.get();
                    seat.setStatus(Seat.Status.available);
                    seatService.updateSeat(seat.getId(), seat);
                }
                
                updatedCount++;
            }
        }
        
        return updatedCount;
    }
}
