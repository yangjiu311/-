package com.example.studyroom.service;

import com.example.studyroom.model.BlockchainLog;

public interface BlockchainService {
    /**
     * 生成区块链交易哈希
     * @param data 要上链的数据
     * @return 交易哈希
     */
    String generateTransactionHash(Object data);
    
    /**
     * 生成区块高度
     * @return 区块高度
     */
    Long generateBlockHeight();
    
    /**
     * 将数据上链
     * @param data 要上链的数据
     * @param userId 用户ID
     * @param stuAdminId 学生/管理员ID
     * @param targetId 目标ID（如预约ID）
     * @param operationType 操作类型
     * @return 包含交易哈希和区块高度的区块链日志
     */
    BlockchainLog uploadToBlockchain(Object data, String userId, String stuAdminId, Long targetId, BlockchainLog.OperationType operationType);
    
    /**
     * 通过申诉后向用户转账1ETH
     * @param userAddress 用户钱包地址
     * @return 交易哈希
     */
    String refundEthAfterAppeal(String userAddress);
}