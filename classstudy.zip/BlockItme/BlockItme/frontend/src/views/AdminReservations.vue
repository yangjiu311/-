<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          仪表盘
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 13H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 17H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M10 9H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          座位管理
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15C10.9391 15 9.92172 15.4214 9.17157 16.1716C8.42143 16.9217 8 17.9391 8 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3 21V19C3 16.7909 4.79086 15 7 15H17C19.2091 15 21 16.7909 21 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C13.6569 7 15 5.65685 15 4C15 2.34315 13.6569 1 12 1C10.3431 1 9 2.34315 9 4C9 5.65685 10.3431 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          用户管理
        </router-link>
        <router-link to="/admin/reservations" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1-2 0l.43.25a2 2 0 0 1-1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l-.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <h1>预约记录管理</h1>
        <div class="user-info" @click="showDropdown = !showDropdown">
          <span class="username">管理员</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <!-- 用户下拉菜单 -->
          <div class="user-dropdown" v-if="showDropdown">
            <button class="dropdown-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              修改密码
            </button>
            <button class="dropdown-item" @click="logout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M15 15L21 12L15 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              退出登录
            </button>
          </div>
        </div>
      </header>

      <!-- 预约记录管理内容区域 -->
      <section class="reservations-management">
        <!-- 搜索栏 -->
        <div class="search-bar">
          <select v-model="searchType" class="search-select">
            <option value="userId">用户ID</option>
            <option value="status">状态</option>
          </select>
          <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索预约记录...">
          <button class="search-btn" @click="handleSearch">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.74948 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            搜索
          </button>
        </div>

        <!-- 预约记录列表 -->
        <div class="reservations-list">
          <table class="reservations-table">
            <thead>
              <tr>
                <th><input type="checkbox" class="select-all"></th>
                <th>预约ID</th>
                <th>用户ID</th>
                <th>座位号</th>
                <th>开始时间</th>
                <th>结束时间</th>
                <th>签到时间</th>
                <th>状态</th>
                <th>交易哈希</th>
                <th>备注</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="reservation in filteredReservations" :key="reservation.id">
                <td><input type="checkbox" class="select-reservation"></td>
                <td>{{ reservation.id }}</td>
                <td>{{ reservation.userId }}</td>
                <td>{{ reservation.seatId }}</td>
                <td>{{ formatDateTime(reservation.startTime) }}</td>
                <td>{{ formatDateTime(reservation.endTime) }}</td>
                <td>{{ formatDateTime(reservation.signInRecord?.signInTime) || '-' }}</td>
                <td>
                  <span :class="['status', reservation.status]">
                    {{ statusText[reservation.status] || reservation.status }}
                  </span>
                </td>
                <td>
                  <span class="transaction-hash" :title="reservation.transactionHash">
                    {{ formatTransactionHash(reservation.transactionHash) }}
                  </span>
                </td>
                <td>{{ reservation.notes || '-' }}</td>
                <td class="actions-column">
                  <button class="btn-view" @click="handleViewReservation(reservation)">查看</button>
                  <button class="btn-delete" @click="handleDeleteReservation(reservation.id)">删除</button>
                </td>
              </tr>
              <tr v-if="filteredReservations.length === 0">
                <td colspan="11" style="text-align: center; padding: 40px; color: #999;">
                  暂无预约记录
                </td>
              </tr>
            </tbody>
          </table>
        </div>


      </section>
    </main>

    <!-- 预约详情模态框 -->
    <div v-if="showDetailModal" class="modal-overlay" @click="closeDetailModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>预约详情</h3>
          <button class="modal-close" @click="closeDetailModal">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
        </div>
        <div class="modal-body" v-if="selectedReservation">
          <div class="detail-section">
            <h4>基本信息</h4>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">预约ID:</span>
                <span class="detail-value">{{ selectedReservation.id }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">用户ID:</span>
                <span class="detail-value">{{ selectedReservation.userId }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">座位号:</span>
                <span class="detail-value">{{ selectedReservation.seatId }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">状态:</span>
                <span class="detail-value">
                  <span :class="['status', selectedReservation.status]">
                    {{ statusText[selectedReservation.status] || selectedReservation.status }}
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div class="detail-section">
            <h4>时间信息</h4>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">开始时间:</span>
                <span class="detail-value">{{ formatDateTime(selectedReservation.startTime) }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">结束时间:</span>
                <span class="detail-value">{{ formatDateTime(selectedReservation.endTime) }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">签到时间:</span>
                <span class="detail-value">{{ formatDateTime(selectedReservation.signInRecord?.signInTime) || '未签到' }}</span>
              </div>
              <div class="detail-item">
                <span class="detail-label">创建时间:</span>
                <span class="detail-value">{{ formatDateTime(selectedReservation.createdAt) }}</span>
              </div>
            </div>
          </div>
          <div class="detail-section">
            <h4>其他信息</h4>
            <div class="detail-grid">
              <div class="detail-item full-width">
                <span class="detail-label">交易哈希:</span>
                <span class="detail-value full-width">{{ selectedReservation.transactionHash || '-' }}</span>
              </div>
              <div class="detail-item full-width">
                <span class="detail-label">备注:</span>
                <span class="detail-value full-width">{{ selectedReservation.notes || '无备注' }}</span>
              </div>
            </div>
          </div>
          <div class="detail-section">
            <h4>区块链信息</h4>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="detail-label">交易哈希:</span>
                <span class="detail-value" style="word-break: break-all; font-family: monospace; font-size: 12px;">{{ selectedReservation.transactionHash || '-' }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-close" @click="closeDetailModal">关闭</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, computed, onMounted } from 'vue'
import { getAllReservationDetails, deleteReservation } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 搜索相关变量
const searchType = ref('userId')
const searchKeyword = ref('')

// 预约数据
const reservations = ref([])
const loading = ref(false)

// 详情弹窗
const showDetailModal = ref(false)
const selectedReservation = ref(null)

// 状态文本映射
const statusText = {
  reserved: '已预约',
  checked_in: '已签到',
  completed: '已完成',
  cancelled: '已取消',
  expired: '已超时'
}

// 格式化日期时间
const formatDateTime = (dateTime) => {
  if (!dateTime) return null
  const date = new Date(dateTime)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 格式化交易哈希
const formatTransactionHash = (hash) => {
  if (!hash) return '-'
  return hash.substring(0, 10) + '...' + hash.substring(hash.length - 8)
}

// 计算属性：过滤后的预约列表
const filteredReservations = computed(() => {
  let result = [...reservations.value]
  
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    switch (searchType.value) {
      case 'userId':
        result = result.filter(r => r.userId.toString().includes(keyword))
        break
      case 'status':
        result = result.filter(r => r.status.toLowerCase().includes(keyword))
        break
    }
  }
  
  return result
})



// 加载预约数据
const loadReservations = async () => {
  loading.value = true
  try {
    const response = await getAllReservationDetails()
    reservations.value = response || []
    console.log('加载预约数据成功，共', reservations.value.length, '条记录')
  } catch (error) {
    console.error('加载预约数据失败:', error)
    reservations.value = []
  } finally {
    loading.value = false
  }
}

// 搜索处理函数
const handleSearch = () => {
  // 搜索处理
}

// 查看预约详情
const handleViewReservation = (reservation) => {
  selectedReservation.value = reservation
  showDetailModal.value = true
}

// 关闭详情弹窗
const closeDetailModal = () => {
  showDetailModal.value = false
  selectedReservation.value = null
}

// 编辑预约
const handleEditReservation = (reservation) => {
  console.log('编辑预约:', reservation)
  // TODO: 实现编辑逻辑
}

// 删除预约
const handleDeleteReservation = async (id) => {
  if (!confirm('确定要删除这条预约记录吗?')) {
    return
  }
  
  try {
    await deleteReservation(id)
    alert('删除成功')
    await loadReservations()
  } catch (error) {
    console.error('删除预约失败:', error)
    alert('删除失败: ' + (error.message || '未知错误'))
  }
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}



// 页面加载时获取数据
onMounted(() => {
  loadReservations()
})
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏样式 */
.top-nav {
  background-color: white;
  padding: 20px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
}

/* 用户信息样式 */
.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 8px 16px;
  border-radius: 6px;
  transition: background-color 0.3s ease;
  position: relative;
}

.user-info:hover {
  background-color: #f0f2f5;
}

.username {
  font-size: 14px;
  color: #2c3e50;
  font-weight: 500;
}

/* 用户下拉菜单样式 */
.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 8px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  min-width: 160px;
  z-index: 1000;
  overflow: hidden;
}

.dropdown-item {
  width: 100%;
  padding: 12px 16px;
  border: none;
  background: none;
  text-align: left;
  font-size: 14px;
  color: #2c3e50;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background-color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #f0f2f5;
}

/* 预约记录管理内容样式 */
.reservations-management {
  padding: 30px;
}

/* 统计卡片样式 */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background-color: white;
  border-radius: 12px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-icon.total {
  background-color: rgba(52, 152, 219, 0.1);
  color: #3498db;
}

.stat-icon.today {
  background-color: rgba(155, 89, 182, 0.1);
  color: #9b59b6;
}

.stat-icon.active {
  background-color: rgba(46, 204, 113, 0.1);
  color: #2ecc71;
}

.stat-icon.completed {
  background-color: rgba(230, 126, 34, 0.1);
  color: #e67e22;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #7f8c8d;
  margin-bottom: 8px;
  font-weight: 500;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #2c3e50;
}

/* 功能按钮区域样式 */
.action-buttons {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.export-btn {
  background-color: #3498db;
  color: white;
}

.export-btn:hover {
  background-color: #2980b9;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
}

/* 搜索栏样式 */
.search-bar {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  background-color: white;
  border-radius: 8px;
  padding: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.search-select {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-radius: 4px 0 0 4px;
  font-size: 14px;
  background-color: #fff;
  color: #2c3e50;
  min-width: 120px;
  cursor: pointer;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-select:focus {
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-left: none;
  border-right: none;
  font-size: 14px;
  width: 300px;
  color: #2c3e50;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input::placeholder {
  color: #bdc3c7;
}

.search-btn {
  padding: 8px 16px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.3s ease;
}

.search-btn:hover {
  background-color: #2980b9;
}

/* 预约记录表格样式 */
.reservations-list {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow-x: auto;
  margin-bottom: 20px;
}

.reservations-table {
  width: 100%;
  border-collapse: collapse;
}

.reservations-table thead {
  background-color: #f8f9fa;
}

.reservations-table th {
  padding: 15px;
  text-align: left;
  font-weight: 600;
  color: #2c3e50;
  font-size: 14px;
  border-bottom: 2px solid #e9ecef;
}

.reservations-table td {
  padding: 15px;
  border-bottom: 1px solid #e9ecef;
  font-size: 14px;
  color: #2c3e50;
}

.reservations-table tbody tr:hover {
  background-color: #f8f9fa;
}

/* 状态标签样式 */
.status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status.arrived {
  background-color: rgba(46, 204, 113, 0.1);
  color: #2ecc71;
}

.status.reserved {
  background-color: rgba(52, 152, 219, 0.1);
  color: #3498db;
}

.status.completed {
  background-color: rgba(155, 89, 182, 0.1);
  color: #9b59b6;
}

.status.cancelled {
  background-color: rgba(231, 76, 60, 0.1);
  color: #e74c3c;
}

.status.expired {
  background-color: rgba(149, 165, 166, 0.1);
  color: #95a5a6;
}

/* 操作按钮样式 */
.reservations-table .btn-view, 
.reservations-table .btn-edit, 
.reservations-table .btn-delete {
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  margin-right: 5px;
  transition: all 0.3s ease;
  display: inline-block;
  vertical-align: middle;
}

/* 操作列样式 */
.reservations-table .actions-column {
  display: flex;
  gap: 5px;
  align-items: center;
}

.btn-view {
  background-color: #3498db;
  color: white;
}

.btn-view:hover {
  background-color: #2980b9;
}

.btn-edit {
  background-color: #f39c12;
  color: white;
}

.btn-edit:hover {
  background-color: #e67e22;
}

.btn-delete {
  background-color: #e74c3c;
  color: white;
}

.btn-delete:hover {
  background-color: #c0392b;
}



/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1001;
  animation: fadeIn 0.3s ease;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.15);
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  animation: slideUp 0.3s ease;
}

.modal-header {
  padding: 20px 24px;
  border-bottom: 1px solid #e9ecef;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #2c3e50;
}

.modal-close {
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: #7f8c8d;
  padding: 4px;
  transition: color 0.3s ease;
}

.modal-close:hover {
  color: #2c3e50;
}

.modal-body {
  padding: 24px;
}

.detail-section {
  margin-bottom: 24px;
}

.detail-section h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 600;
  color: #2c3e50;
  padding-bottom: 8px;
  border-bottom: 1px solid #e9ecef;
}

.detail-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 16px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.detail-item.full-width {
  grid-column: 1 / -1;
}

.detail-label {
  font-size: 14px;
  color: #7f8c8d;
  font-weight: 500;
}

.detail-value {
  font-size: 14px;
  color: #2c3e50;
  word-break: break-all;
}

.detail-value.full-width {
  white-space: pre-wrap;
}

.modal-footer {
  padding: 20px 24px;
  border-top: 1px solid #e9ecef;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

.btn-close {
  padding: 8px 20px;
  border: 1px solid #dfe6e9;
  background-color: white;
  color: #2c3e50;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-close:hover {
  background-color: #f8f9fa;
}

/* 动画 */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideUp {
  from { transform: translateY(20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .sidebar {
    width: 200px;
  }
  
  .stats-cards {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  }
}

@media (max-width: 480px) {
  .sidebar {
    display: none;
  }
  
  .reservations-management {
    padding: 15px;
  }
  
  .top-nav {
    padding: 0 15px;
  }
  
  .top-nav h1 {
    font-size: 18px;
  }
  
  .stats-cards {
    grid-template-columns: 1fr;
  }
}



/* slide-fade 过渡动画 */
.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s ease-in;
}

.slide-fade-enter-from {
  transform: translateX(-20px);
  opacity: 0;
}

.slide-fade-leave-to {
  transform: translateX(20px);
  opacity: 0;
}
</style>