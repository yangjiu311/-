package com.example.studyroom.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 关闭CSRF保护，因为前端使用JWT进行认证
            .csrf(AbstractHttpConfigurer::disable)
            // 允许所有请求访问，因为当前只需要测试功能
            .authorizeHttpRequests(auth -> auth
                .anyRequest().permitAll()
            )
            // 关闭默认的表单登录
            .formLogin(AbstractHttpConfigurer::disable)
            // 关闭默认的HTTP基本认证
            .httpBasic(AbstractHttpConfigurer::disable)
            // 禁用会话管理，因为使用JWT
            .sessionManagement(AbstractHttpConfigurer::disable);

        return http.build();
    }
}