import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import Home from '../views/Home.vue'
import Admin from '../views/Admin.vue'
import AdminProfile from '../views/AdminProfile.vue'
import AdminSeats from '../views/AdminSeats.vue'
import AdminUsers from '../views/AdminUsers.vue' // 添加导入
import AdminReservations from '../views/AdminReservations.vue' // 添加导入
import AdminSettings from '../views/AdminSettings.vue' // 添加导入
import AdminChangePassword from '../views/AdminChangePassword.vue' // 添加导入
import AdminCheckIn from '../views/AdminCheckIn.vue' // 添加签到记录页面导入
import AdminViolations from '../views/AdminViolations.vue' // 添加违约记录页面导入
import AdminAppeals from '../views/AdminAppeals.vue' // 添加申诉记录页面导入
import User from '../views/User.vue' // 添加用户页面导入
import UserSeats from '../views/UserSeats.vue' // 添加用户座位预约页面导入
import UserReservations from '../views/UserReservations.vue' // 添加用户预约记录页面导入
import UserCheckIns from '../views/UserCheckIns.vue' // 添加用户签到记录页面导入
import UserViolations from '../views/UserViolations.vue' // 添加用户违约记录页面导入
import UserAppeals from '../views/UserAppeals.vue' // 添加用户申诉记录页面导入
import UserProfile from '../views/UserProfile.vue' // 添加用户个人信息页面导入
import UserSettings from '../views/UserSettings.vue' // 添加用户个人设置页面导入
import BlockchainLog from '../views/BlockchainLog.vue' // 添加区块链日志页面导入
import { useUserStore } from '../stores/user'
import TestAreaSelection from '../views/TestAreaSelection.vue'

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/Login',
    redirect: '/login'
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
    meta: { requiresAuth: true }
  },
  // 用户页面路由配置
  {
    path: '/user',
    name: 'User',
    component: User,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/seats',
    name: 'UserSeats',
    component: UserSeats,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/reservations',
    name: 'UserReservations',
    component: UserReservations,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/checkins',
    name: 'UserCheckIns',
    component: UserCheckIns,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/violations',
    name: 'UserViolations',
    component: UserViolations,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/appeals',
    name: 'UserAppeals',
    component: UserAppeals,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/profile',
    name: 'UserProfile',
    component: UserProfile,
    meta: { requiresAuth: true, isUser: true }
  },
  {
    path: '/user/settings',
    name: 'UserSettings',
    component: UserSettings,
    meta: { requiresAuth: true, isUser: true }
  },
  // 区块链日志页面路由（公开访问，用于二维码扫描）
  {
    path: '/blockchain-log/:transactionHash',
    name: 'BlockchainLog',
    component: BlockchainLog
  },
  // 管理员页面路由配置
  {
    path: '/admin',
    name: 'Admin',
    component: Admin,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/profile',
    name: 'AdminProfile',
    component: AdminProfile,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/seats',
    name: 'AdminSeats',
    component: AdminSeats,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/users',
    name: 'AdminUsers',
    component: AdminUsers,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/reservations',
    name: 'AdminReservations',
    component: AdminReservations,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/checkins',
    name: 'AdminCheckIn',
    component: AdminCheckIn,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/violations',
    name: 'AdminViolations',
    component: AdminViolations,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/appeals',
    name: 'AdminAppeals',
    component: AdminAppeals,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/settings',
    name: 'AdminSettings',
    component: AdminSettings,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/admin/change-password',
    name: 'AdminChangePassword',
    component: AdminChangePassword,
    meta: { requiresAuth: true, isAdmin: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  const userStore = useUserStore()
  
  // 从本地存储恢复用户信息
  if (token && !userStore.isLoggedIn) {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'))
    if (userInfo) {
      userStore.isLoggedIn = true
      userStore.userInfo = userInfo
      userStore.walletAddress = userInfo.wallet_address
    }
  }
  
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!token) {
      next({ path: '/login' })
    } else if (to.matched.some(record => record.meta.isAdmin)) {
      if (userStore.isAdmin) {
        next()
      } else {
        next({ path: '/user' }) // 普通用户重定向到用户首页
      }
    } else if (to.matched.some(record => record.meta.isUser)) {
      if (!userStore.isAdmin) {
        next()
      } else {
        next({ path: '/admin' }) // 管理员重定向到管理员首页
      }
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router



