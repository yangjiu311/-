package com.example.studyroom.service.impl;

import com.example.studyroom.model.Row;
import com.example.studyroom.repository.RowRepository;
import com.example.studyroom.service.RowService;
import com.example.studyroom.repository.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.AllArgsConstructor;
import lombok.NonNull;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class RowServiceImpl implements RowService {

    private final RowRepository rowRepository;
    private final SeatRepository seatRepository;

    @Override
    public List<Row> getAllRows() {
        return rowRepository.findAll();
    }

    @Override
    public Optional<Row> getRowById(@NonNull Long id) {
        return rowRepository.findById(id);
    }

    @Override
    public Optional<Row> getRowByRowNumber(@NonNull Integer rowNumber) {
        return rowRepository.findByRowNumber(rowNumber);
    }

    @Override
    public Row saveRow(@NonNull Row row) {
        return rowRepository.save(row);
    }

    @Override
    @Transactional
    public void deleteRow(@NonNull Long id) {
        // 首先获取行信息
        Optional<Row> rowOptional = rowRepository.findById(id);
        if (rowOptional.isPresent()) {
            Row row = rowOptional.get();
            // 删除该行对应的所有座位
            seatRepository.deleteByRow(row.getRowNumber());
            // 然后删除行
            rowRepository.deleteById(id);
        }
    }

    @Override
    public boolean existsByRowNumber(@NonNull Integer rowNumber) {
        return rowRepository.existsByRowNumber(rowNumber);
    }
}