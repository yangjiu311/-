<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          仪表盘
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          座位管理
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15C10.9391 15 9.92172 15.4214 9.17157 16.1716C8.42143 16.9217 8 17.9391 8 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          用户管理
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <h1>违约记录</h1>
        <div class="user-info" @click="showDropdown = !showDropdown">
          <span class="username">管理员</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <!-- 用户下拉菜单 -->
          <div class="user-dropdown" v-if="showDropdown">
            <button class="dropdown-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              修改密码
            </button>
            <button class="dropdown-item" @click="logout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M15 15L21 12L15 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              退出登录
            </button>
          </div>
        </div>
      </header>

      <!-- 违约记录内容区域 -->
      <section class="violations-management">


        <!-- 搜索栏 -->
        <div class="search-bar">
          <select v-model="searchType" class="search-select">
            <option value="userId">用户ID</option>
            <option value="seatId">座位号</option>
            <option value="reservationId">预约ID</option>
          </select>
          <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索违约记录..." @input="handleSearch">
          <button class="search-btn" @click="handleSearch">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.74948 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            搜索
          </button>
        </div>

        <transition name="slide-fade" mode="out-in">
          <!-- 违约记录列表 -->
          <div class="violations-list" key="list">
            <table class="violations-table">
              <thead>
                <tr>
                  <th><input type="checkbox" class="select-all" v-model="selectAll" @change="handleSelectAll"></th>
                  <th>违约ID</th>
                  <th>用户ID</th>
                  <th>座位号</th>
                  <th>预约ID</th>
                  <th>违约类型</th>
                  <th>违约时间</th>
                  <th>状态</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="violation in filteredViolations" :key="violation.id">
                  <td><input type="checkbox" class="select-violation" v-model="selectedViolations" :value="violation.id"></td>
                  <td>{{ violation.id }}</td>
                  <td>{{ violation.user_id }}</td>
                  <td>{{ violation.seat_id }}</td>
                  <td>{{ violation.reservation_id }}</td>
                  <td>
                    <span :class="['type-badge', violation.violation_type]">
                      {{ formatViolationType(violation.violation_type) }}
                    </span>
                  </td>
                  <td>{{ formatViolationTime(violation.violation_time) }}</td>
                  <td>
                    <span :class="['status-badge', violation.status]">
                      {{ formatStatus(violation.status) }}
                    </span>
                  </td>
                  <td>
                    <button class="btn-view" @click="handleViewDetail(violation)" title="查看详情">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                    <button class="btn-resolve" @click="handleResolveViolation(violation.id)" title="标记为已处理" v-if="violation.status === 'pending'">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                    <button class="btn-withdraw" @click="handleWithdrawDeposit(violation.id)" title="提取违约押金">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7 10V7a5 5 0 0 1 10 0v3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 15V3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                    <button class="btn-delete" @click="handleDeleteViolation(violation.id)" title="删除记录">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                  </td>
                </tr>
                <tr v-if="filteredViolations.length === 0">
                  <td colspan="9" class="no-data">暂无违约记录</td>
                </tr>
              </tbody>
            </table>
          </div>
        </transition>

      </section>

      <!-- 违约详情模态框 -->
      <div v-if="showDetailModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>违约详情</h3>
            <button class="close-btn" @click="showDetailModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="detail-item">
              <label>违约ID：</label>
              <span>{{ currentViolation.id }}</span>
            </div>
            <div class="detail-item">
              <label>用户ID：</label>
              <span>{{ currentViolation.user_id }}</span>
            </div>
            <div class="detail-item">
              <label>座位号：</label>
              <span>{{ currentViolation.seat_id }}</span>
            </div>
            <div class="detail-item">
              <label>预约ID：</label>
              <span>{{ currentViolation.reservation_id }}</span>
            </div>
            <div class="detail-item">
              <label>违约类型：</label>
              <span :class="['type-badge', currentViolation.violation_type]">{{ formatViolationType(currentViolation.violation_type) }}</span>
            </div>
            <div class="detail-item">
              <label>违约时间：</label>
              <span>{{ formatViolationTime(currentViolation.violation_time) }}</span>
            </div>
            <div class="detail-item">
              <label>状态：</label>
              <span :class="['status-badge', currentViolation.status]">{{ formatStatus(currentViolation.status) }}</span>
            </div>
            <div class="detail-item">
              <label>交易哈希：</label>
              <span style="word-break: break-all; font-family: monospace; font-size: 12px;">{{ currentViolation.transaction_hash || '-' }}</span>
            </div>
            <div class="detail-item">
              <label>区块高度：</label>
              <span>{{ currentViolation.block_height || '-' }}</span>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showDetailModal = false">关闭</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { getAllViolations, deleteViolation, updateViolationStatus, withdrawViolationDeposit } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

const violations = ref([])
const searchType = ref('userId')
const searchKeyword = ref('')

const selectedViolations = ref([])
const selectAll = ref(false)
const showDetailModal = ref(false)
const currentViolation = ref({})
const pollingInterval = ref(null)
const isLoading = ref(false)

const pendingCount = computed(() => violations.value.filter(v => v.status === 'pending').length)
const resolvedCount = computed(() => violations.value.filter(v => v.status === 'resolved').length)

const fetchViolations = async () => {
  if (isLoading.value) return
  
  isLoading.value = true
  try {
    const response = await getAllViolations()
    // 转换后端数据格式以匹配前端期望的结构
    const formattedViolations = response.map(violation => ({
      id: violation.id,
      user_id: violation.userId,
      seat_id: violation.seatNumber,
      reservation_id: violation.reservationId,
      violation_type: violation.violationType.toLowerCase(),
      violation_time: violation.violationTime,
      status: violation.status.toLowerCase(),
      transaction_hash: violation.transactionHash || null,
      block_height: violation.blockHeight || null
    }))
    violations.value = formattedViolations
  } catch (error) {
    console.error('获取违约记录失败:', error)
  } finally {
    isLoading.value = false
  }
}

// 启动轮询
const startPolling = () => {
  // 每5秒刷新一次数据
  pollingInterval.value = setInterval(fetchViolations, 5000)
}

// 停止轮询
const stopPolling = () => {
  if (pollingInterval.value) {
    clearInterval(pollingInterval.value)
    pollingInterval.value = null
  }
}

const filteredViolations = computed(() => {
  let result = [...violations.value]
  
  if (searchKeyword.value) {
    const query = searchKeyword.value.toLowerCase()
    if (searchType.value === 'userId') {
      result = result.filter(violation => violation.user_id.toLowerCase().includes(query))
    } else if (searchType.value === 'seatId') {
      result = result.filter(violation => violation.seat_id.toLowerCase().includes(query))
    } else if (searchType.value === 'reservationId') {
      result = result.filter(violation => violation.reservation_id.toString().includes(query))
    }
  }
  
  return result
})

const handleSearch = () => {
  // 搜索处理
}

const handleSelectAll = () => {
  if (selectAll.value) {
    selectedViolations.value = filteredViolations.value.map(v => v.id)
  } else {
    selectedViolations.value = []
  }
}

const handleViewDetail = (violation) => {
  currentViolation.value = violation
  showDetailModal.value = true
}

const handleResolveViolation = async (violationId) => {
  if (confirm('确定要标记这条违约记录为已处理吗？')) {
    try {
      await updateViolationStatus(violationId, 'RESOLVED')
      // 立即刷新数据以反映状态更新
      await fetchViolations()
      alert('标记成功')
    } catch (error) {
      console.error('标记违约记录失败:', error)
      alert('标记失败')
    }
  }
}

const handleDeleteViolation = async (violationId) => {
  if (confirm('确定要删除这条违约记录吗？')) {
    try {
      await deleteViolation(violationId)
      // 立即刷新数据以反映删除结果
      await fetchViolations()
      alert('删除成功')
    } catch (error) {
      console.error('删除违约记录失败:', error)
      alert('删除失败')
    }
  }
}

const handleWithdrawDeposit = async (violationId) => {
  if (confirm('确定要提取这条违约记录的押金吗？')) {
    try {
      await withdrawViolationDeposit(violationId)
      // 立即刷新数据以反映提取结果
      await fetchViolations()
      alert('提取违约押金成功')
    } catch (error) {
      console.error('提取违约押金失败:', error)
      alert('提取违约押金失败，请重试')
    }
  }
}

const handleExport = () => {
  alert('导出功能开发中...')
}

const handleBatchResolve = () => {
  if (selectedViolations.value.length === 0) {
    alert('请先选择要处理的违约记录')
    return
  }
  if (confirm(`确定要批量处理选中的 ${selectedViolations.value.length} 条违约记录吗？`)) {
    selectedViolations.value.forEach(id => {
      const violation = violations.value.find(v => v.id === id)
      if (violation) {
        violation.status = 'resolved'
      }
    })
    selectedViolations.value = []
    selectAll.value = false
    alert('批量处理成功')
  }
}

const handleBatchDelete = () => {
  if (selectedViolations.value.length === 0) {
    alert('请先选择要删除的违约记录')
    return
  }
  if (confirm(`确定要批量删除选中的 ${selectedViolations.value.length} 条违约记录吗？`)) {
    violations.value = violations.value.filter(v => !selectedViolations.value.includes(v.id))
    selectedViolations.value = []
    selectAll.value = false
    alert('批量删除成功')
  }
}

const formatViolationTime = (time) => {
  if (!time) return ''
  const date = new Date(time)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const formatViolationType = (type) => {
  const typeMap = {
    'no_checkin': '未签到',
    'late': '迟到',
    'early_leave': '早退',
    'overtime': '超时未离开'
  }
  return typeMap[type] || type
}

const formatStatus = (status) => {
  const statusMap = {
    'pending': '待处理',
    'resolved': '已处理'
  }
  return statusMap[status] || status
}

const logout = () => {
  userStore.logout()
  router.push('/login')
}

onMounted(() => {
  fetchViolations()
  startPolling()
})

onUnmounted(() => {
  stopPolling()
})
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
  position: relative;
  cursor: pointer;
}

.username {
  font-weight: 600;
  color: #2c3e50;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 8px 0;
  min-width: 150px;
  z-index: 1000;
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 10px 16px;
  background: none;
  border: none;
  text-align: left;
  cursor: pointer;
  font-size: 14px;
  color: #2c3e50;
  transition: background-color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #f8f9fa;
}

.violations-management {
  padding: 30px;
}

.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-icon.total {
  background-color: #e3f2fd;
  color: #3498db;
}

.stat-icon.pending {
  background-color: #fff3cd;
  color: #ffc107;
}

.stat-icon.resolved {
  background-color: #d4edda;
  color: #4CAF50;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #6c757d;
  margin-bottom: 8px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #2c3e50;
}

.action-buttons {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.action-btn.export {
  background-color: #3498db;
  color: white;
}

.action-btn.export:hover {
  background-color: #2980b9;
}

.action-btn.batch-resolve {
  background-color: #4CAF50;
  color: white;
}

.action-btn.batch-resolve:hover {
  background-color: #45a049;
}

.action-btn.batch-delete {
  background-color: #e74c3c;
  color: white;
}

.action-btn.batch-delete:hover {
  background-color: #c0392b;
}

.search-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  align-items: center;
}

.search-select,
.search-input {
  flex: 1;
  min-width: 200px;
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
}

.search-btn {
  padding: 10px 20px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
}

.search-btn:hover {
  background-color: #2980b9;
}

.violations-list {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.violations-table {
  width: 100%;
  border-collapse: collapse;
}

.violations-table th,
.violations-table td {
  padding: 12px 16px;
  text-align: left;
  border-bottom: 1px solid #e0e0e0;
}

.violations-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
  font-size: 14px;
}

.violations-table tbody tr:hover {
  background-color: #f8f9fa;
}

.no-data {
  text-align: center;
  color: #95a5a6;
  padding: 40px !important;
}

.type-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.type-badge.no_checkin {
  background-color: #f8d7da;
  color: #721c24;
}

.type-badge.late {
  background-color: #fff3cd;
  color: #856404;
}

.type-badge.early_leave {
  background-color: #d1ecf1;
  color: #0c5460;
}

.type-badge.overtime {
  background-color: #d4edda;
  color: #155724;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.pending {
  background-color: #fff3cd;
  color: #856404;
}

.status-badge.resolved {
  background-color: #d4edda;
  color: #155724;
}

.btn-view,
.btn-resolve,
.btn-delete,
.btn-withdraw {
  padding: 6px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: none;
  margin-right: 5px;
}

.btn-view {
  color: #3498db;
}

.btn-view:hover {
  background-color: #e3f2fd;
}

.btn-resolve {
  color: #4CAF50;
}

.btn-resolve:hover {
  background-color: #e8f5e9;
}

.btn-withdraw {
  color: #ff9800;
}

.btn-withdraw:hover {
  background-color: #fff3e0;
}

.btn-delete {
  color: #e74c3c;
}

.btn-delete:hover {
  background-color: #fee;
}

.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s ease-in;
}

.slide-fade-enter-from {
  transform: translateX(-20px);
  opacity: 0;
}

.slide-fade-leave-to {
  transform: translateX(20px);
  opacity: 0;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #6c757d;
  font-size: 24px;
  line-height: 1;
  transition: color 0.3s ease;
}

.close-btn:hover {
  color: #dc3545;
}

.modal-body {
  padding: 20px;
}

.detail-item {
  display: flex;
  margin-bottom: 15px;
  align-items: center;
}

.detail-item label {
  font-weight: 600;
  color: #2c3e50;
  min-width: 100px;
}

.detail-item span {
  color: #495057;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 20px;
  border-top: 1px solid #e0e0e0;
}

.btn-cancel {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  background-color: #95a5a6;
  color: white;
}

.btn-cancel:hover {
  background-color: #7f8c8d;
}
</style>
