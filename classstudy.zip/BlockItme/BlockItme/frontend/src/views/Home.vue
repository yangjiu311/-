<template>
  <div class="home-container">
    <h1>区块链自习室系统</h1>
    <p>欢迎使用基于区块链技术的智能自习室管理系统</p>
  </div>
</template>

<script setup>
// 主页组件
</script>

<style scoped>
.home-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #f0f2f5;
}

h1 {
  color: #4CAF50;
  margin-bottom: 20px;
}
</style>