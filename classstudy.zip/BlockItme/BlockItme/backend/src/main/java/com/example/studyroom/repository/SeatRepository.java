package com.example.studyroom.repository;

import com.example.studyroom.model.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SeatRepository extends JpaRepository<Seat, Long> {
    Optional<Seat> findBySeatNumber(String seatNumber);
    List<Seat> findByStatus(Seat.Status status);
    boolean existsBySeatNumber(String seatNumber);
    // 添加按行号查询和删除座位的方法
    List<Seat> findByRow(Integer row);
    void deleteByRow(Integer row);
    // 添加按列号查询和删除座位的方法
    List<Seat> findByColumn(Integer column);
    void deleteByColumn(Integer column);
}