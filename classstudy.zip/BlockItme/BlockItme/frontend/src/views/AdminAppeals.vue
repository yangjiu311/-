<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin/dashboard" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
          </svg>
          仪表盘
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
          </svg>
          座位管理
        </router-link>
        <router-link to="/admin/bookings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
          </svg>
          预约管理
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          签到记录
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
          </svg>
          违约记录
        </router-link>
        <router-link to="/admin/appeals" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
          </svg>
          申诉记录
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"></path>
            <circle cx="9" cy="7" r="4"></circle>
            <path d="M23 21v-2a4 4 0 00-3-3.87"></path>
            <path d="M16 3.13a4 4 0 010 7.75"></path>
          </svg>
          用户管理
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <h1>申诉记录管理</h1>
        <div class="user-info">
          <span class="username" @click="toggleUserDropdown">
            {{ userStore.username || '管理员' }}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 9l-7 7-7-7"></path>
            </svg>
          </span>
          <div class="user-dropdown" v-if="showUserDropdown">
            <button class="dropdown-item" @click="logout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"></path>
                <polyline points="16 17 21 12 16 7"></polyline>
                <line x1="21" y1="12" x2="9" y2="12"></line>
              </svg>
              退出登录
            </button>
          </div>
        </div>
      </header>

      <!-- 申诉记录内容区域 -->
      <section class="appeals-management">
        <!-- 搜索和筛选栏 -->
        <div class="search-bar">
          <div class="search-input-group">
            <select v-model="searchType" class="search-type-select">
              <option value="all">全部</option>
              <option value="userId">用户ID</option>
              <option value="violationId">违约ID</option>
            </select>
            <input type="text" v-model="searchQuery" placeholder="搜索申诉记录..." @input="handleSearch">
            <button class="search-btn" @click="handleSearch"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg> 搜索</button>
          </div>

        </div>
        <!-- 申诉记录表格 -->
        <div class="appeals-table-container">
          <table class="appeals-table">
            <thead>
              <tr>
                <th style="width: 50px;"><input type="checkbox" v-model="selectAll" @change="toggleSelectAll"></th>
                <th>申诉ID</th>
                <th>用户ID</th>
                <th>学号/工号</th>
                <th>违约ID</th>
                <th>申诉原因</th>
                <th>申诉时间</th>
                <th>交易哈希</th>
                <th>区块高度</th>
                <th>状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="filteredAppeals.length === 0">
                <td colspan="11" class="no-data">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                  <p>暂无申诉记录</p>
                </td>
              </tr>
              <tr v-for="appeal in filteredAppeals" :key="appeal.id" v-else>
                <td><input type="checkbox" v-model="selectedAppeals" :value="appeal.id"></td>
                <td>{{ appeal.id }}</td>
                <td>{{ appeal.userId }}</td>
                <td>{{ appeal.stuAdminId || '-' }}</td>
                <td>{{ appeal.violationId }}</td>
                <td><div class="reason-text" :title="appeal.reason">{{ appeal.reason }}</div></td>
                <td>{{ formatAppealTime(appeal.appealTime) }}</td>
                <td><div class="hash-text" :title="appeal.transactionHash">{{ appeal.transactionHash || '-' }}</div></td>
                <td>{{ appeal.blockHeight || '-' }}</td>
                <td><span class="status-badge" :class="appeal.status">{{ formatStatus(appeal.status) }}</span></td>
                <td>
                  <button class="action-btn view-btn" @click="viewAppealDetail(appeal)" title="查看详情"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg> 查看</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

      </section>
    </main>

    <!-- 申诉详情模态框 -->
    <transition name="slide-fade">
      <div class="modal-overlay" v-if="showDetailModal" @click="closeDetailModal">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h3>申诉详情</h3>
            <button class="close-btn" @click="closeDetailModal">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <div class="detail-item">
              <span class="detail-label">申诉ID：</span>
              <span class="detail-value">{{ selectedAppealDetail.id }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">用户ID：</span>
              <span class="detail-value">{{ selectedAppealDetail.userId }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">学号/工号：</span>
              <span class="detail-value">{{ selectedAppealDetail.stuAdminId || '-' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">违约ID：</span>
              <span class="detail-value">{{ selectedAppealDetail.violationId }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">申诉原因：</span>
              <span class="detail-value">{{ selectedAppealDetail.reason }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">申诉时间：</span>
              <span class="detail-value">{{ formatAppealTime(selectedAppealDetail.appealTime) }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">交易哈希：</span>
              <span class="detail-value">{{ selectedAppealDetail.transactionHash || '-' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">区块高度：</span>
              <span class="detail-value">{{ selectedAppealDetail.blockHeight || '-' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">状态：</span>
              <span class="detail-value">
                <span class="status-badge" :class="selectedAppealDetail.status">
                  {{ formatStatus(selectedAppealDetail.status) }}
                </span>
              </span>
            </div>
            
            <div class="detail-item" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #e0e0e0;">
              <label style="font-weight: 600; margin-bottom: 8px; display: block;">申诉上链信息</label>
              <div class="detail-item">
                <label>交易哈希：</label>
                <span style="word-break: break-all; font-family: monospace; font-size: 12px;">{{ selectedAppealDetail.transactionHash || '-' }}</span>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button 
              v-if="selectedAppealDetail.status === 'pending'" 
              class="btn btn-success" 
              @click="handleApproveAppeal(selectedAppealDetail.id); closeDetailModal();"
            >
              通过申诉
            </button>
            <button 
              v-if="selectedAppealDetail.status === 'pending'" 
              class="btn btn-warning" 
              @click="handleRejectAppeal(selectedAppealDetail.id); closeDetailModal();"
            >
              驳回申诉
            </button>
            <button class="btn btn-secondary" @click="closeDetailModal">
              关闭
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import axios from 'axios'

const router = useRouter()
const userStore = useUserStore()

// 响应式变量
const appeals = ref([])
const searchQuery = ref('')
const searchType = ref('all')

const showUserDropdown = ref(false)
const showDetailModal = ref(false)
const selectedAppealDetail = ref({})
const selectedAppeals = ref([])
const selectAll = ref(false)

// 统计数据
const stats = computed(() => {
  return {
    total: appeals.value.length,
    pending: appeals.value.filter(a => a.status === 'pending').length,
    approved: appeals.value.filter(a => a.status === 'approved').length,
    rejected: appeals.value.filter(a => a.status === 'rejected').length
  }
})

// 获取申诉记录
const fetchAppeals = async () => {
  try {
    const response = await axios.get('/api/appeals')
    // 处理后端返回的数据，映射到前端需要的字段格式
    appeals.value = response.data.map(item => ({
      id: item.id.toString(),
      userId: item.userId,
      stuAdminId: item.stuAdminId,
      violationId: item.violationId.toString(),
      reason: item.appealContent,
      appealTime: item.createdAt,
      status: item.appealStatus,
      transactionHash: item.transactionHash,
      blockHeight: item.blockHeight
    }))
  } catch (error) {
    console.error('获取申诉记录失败:', error)
    appeals.value = []
  }
}

// 筛选后的申诉记录
const filteredAppeals = computed(() => {
  let result = [...appeals.value]

  // 搜索过滤
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    result = result.filter(appeal => {
      if (searchType.value === 'userId') {
        return appeal.userId.toLowerCase().includes(query)
      } else if (searchType.value === 'violationId') {
        return appeal.violationId.toLowerCase().includes(query)
      } else {
        return appeal.userId.toLowerCase().includes(query) ||
               appeal.violationId.toLowerCase().includes(query) ||
               appeal.reason.toLowerCase().includes(query)
      }
    })
  }

  return result
})



// 搜索处理
const handleSearch = () => {
  // 搜索处理
}



// 切换用户下拉菜单
const toggleUserDropdown = () => {
  showUserDropdown.value = !showUserDropdown.value
}

// 查看申诉详情
const viewAppealDetail = (appeal) => {
  selectedAppealDetail.value = { ...appeal }
  showDetailModal.value = true
}

// 关闭详情模态框
const closeDetailModal = () => {
  showDetailModal.value = false
  selectedAppealDetail.value = {}
}

// 全选/取消全选
const toggleSelectAll = () => {
  if (selectAll.value) {
    selectedAppeals.value = filteredAppeals.value.map(a => a.id)
  } else {
    selectedAppeals.value = []
  }
}

// 批量通过
const batchApprove = async () => {
  if (confirm(`确定要通过选中的 ${selectedAppeals.value.length} 条申诉吗？`)) {
    try {
      for (const id of selectedAppeals.value) {
        const appeal = appeals.value.find(a => a.id === id)
        if (appeal) {
          await axios.put(`http://localhost:8080/api/appeals/${id}`, {
            id: appeal.id,
            userId: appeal.userId,
            stuAdminId: appeal.stuAdminId,
            violationId: appeal.violationId,
            appealContent: appeal.reason,
            appealStatus: 'approved',
            transactionHash: appeal.transactionHash,
            blockHeight: appeal.blockHeight
          })
        }
      }
      await fetchAppeals()
      selectedAppeals.value = []
      selectAll.value = false
      alert('批量通过成功')
    } catch (error) {
      console.error('批量通过失败:', error)
      alert('批量操作失败')
    }
  }
}

// 批量驳回
const batchReject = async () => {
  if (confirm(`确定要驳回选中的 ${selectedAppeals.value.length} 条申诉吗？`)) {
    try {
      for (const id of selectedAppeals.value) {
        const appeal = appeals.value.find(a => a.id === id)
        if (appeal) {
          await axios.put(`http://localhost:8080/api/appeals/${id}`, {
            id: appeal.id,
            userId: appeal.userId,
            stuAdminId: appeal.stuAdminId,
            violationId: appeal.violationId,
            appealContent: appeal.reason,
            appealStatus: 'rejected',
            transactionHash: appeal.transactionHash,
            blockHeight: appeal.blockHeight
          })
        }
      }
      await fetchAppeals()
      selectedAppeals.value = []
      selectAll.value = false
      alert('批量驳回成功')
    } catch (error) {
      console.error('批量驳回失败:', error)
      alert('批量操作失败')
    }
  }
}

// 批量删除
const batchDelete = async () => {
  if (confirm(`确定要删除选中的 ${selectedAppeals.value.length} 条申诉记录吗？`)) {
    try {
      for (const id of selectedAppeals.value) {
        await axios.delete(`http://localhost:8080/api/appeals/${id}`)
      }
      await fetchAppeals()
      selectedAppeals.value = []
      selectAll.value = false
      alert('批量删除成功')
    } catch (error) {
      console.error('批量删除失败:', error)
      alert('批量操作失败')
    }
  }
}

// 导出记录
const exportRecords = () => {
  alert('导出功能开发中...')
}

// 通过申诉
const handleApproveAppeal = async (appealId) => {
  if (confirm('确定要通过这条申诉吗？')) {
    try {
      const appeal = appeals.value.find(a => a.id === appealId)
      if (appeal) {
        // 调用后端API更新状态，确保传递正确的字段名
        await axios.put(`/api/appeals/${appealId}`, {
          id: appeal.id,
          userId: appeal.userId,
          stuAdminId: appeal.stuAdminId,
          violationId: appeal.violationId,
          appealContent: appeal.reason,  // 将reason映射回appealContent
          appealStatus: 'approved',  // 使用appealStatus而不是status
          transactionHash: appeal.transactionHash,
          blockHeight: appeal.blockHeight
        })
        // 重新获取申诉列表
        await fetchAppeals()
        alert('申诉已通过')
      }
    } catch (error) {
      console.error('通过申诉失败:', error)
      alert('操作失败')
    }
  }
}

// 驳回申诉
const handleRejectAppeal = async (appealId) => {
  if (confirm('确定要驳回这条申诉吗？')) {
    try {
      const appeal = appeals.value.find(a => a.id === appealId)
      if (appeal) {
        // 调用后端API更新状态，确保传递正确的字段名
        await axios.put(`http://localhost:8080/api/appeals/${appealId}`, {
          id: appeal.id,
          userId: appeal.userId,
          stuAdminId: appeal.stuAdminId,
          violationId: appeal.violationId,
          appealContent: appeal.reason,  // 将reason映射回appealContent
          appealStatus: 'rejected',  // 使用appealStatus而不是status
          transactionHash: appeal.transactionHash,
          blockHeight: appeal.blockHeight
        })
        // 重新获取申诉列表
        await fetchAppeals()
        alert('申诉已驳回')
      }
    } catch (error) {
      console.error('驳回申诉失败:', error)
      alert('操作失败')
    }
  }
}

// 删除申诉记录
const handleDeleteAppeal = async (appealId) => {
  if (confirm('确定要删除这条申诉记录吗？')) {
    try {
      // 调用后端API删除申诉记录
      await axios.delete(`/api/appeals/${appealId}`)
      // 重新获取申诉列表
      await fetchAppeals()
      alert('删除成功')
    } catch (error) {
      console.error('删除申诉记录失败:', error)
      alert('删除失败')
    }
  }
}

// 格式化申诉时间
const formatAppealTime = (time) => {
  if (!time) return ''
  const date = new Date(time)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 格式化状态
const formatStatus = (status) => {
  const statusMap = {
    'pending': '待审核',
    'approved': '已通过',
    'rejected': '已驳回'
  }
  return statusMap[status] || status
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 定时器变量
let updateTimer = null

// 在组件挂载时获取申诉记录并设置定时更新
onMounted(() => {
  fetchAppeals()
  // 设置定时轮询，每30秒更新一次数据
  updateTimer = setInterval(() => {
    fetchAppeals()
  }, 30000)
})

// 在组件卸载时清除定时器
onUnmounted(() => {
  if (updateTimer) {
    clearInterval(updateTimer)
    updateTimer = null
  }
})
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

/* 表格样式调整 */
.appeals-table {
  width: 100%;
  border-collapse: collapse;
}

.appeals-table th,
.appeals-table td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #e0e0e0;
}

.appeals-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  white-space: nowrap;
}

.hash-text {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.reason-text {
  max-width: 250px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
  position: relative;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
  padding: 8px 12px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.username:hover {
  background-color: #f5f5f5;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  background-color: white;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  min-width: 150px;
  z-index: 1000;
  margin-top: 5px;
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 10px 15px;
  background: none;
  border: none;
  text-align: left;
  cursor: pointer;
  font-size: 14px;
  color: #2c3e50;
  transition: background-color 0.3s;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

/* 申诉记录内容样式 */
.appeals-content {
  padding: 30px;
}

/* 统计卡片区域 */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
  margin-bottom: 25px;
}

.stat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-card.total .stat-icon {
  background-color: #e3f2fd;
  color: #2196f3;
}

.stat-card.pending .stat-icon {
  background-color: #fff3cd;
  color: #ffc107;
}

.stat-card.approved .stat-icon {
  background-color: #d4edda;
  color: #28a745;
}

.stat-card.rejected .stat-icon {
  background-color: #f8d7da;
  color: #dc3545;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #7f8c8d;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 28px;
  font-weight: 600;
  color: #2c3e50;
}

/* 功能按钮区域 */
.action-buttons {
  display: flex;
  gap: 12px;
  margin-bottom: 25px;
  flex-wrap: wrap;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-primary {
  background-color: #4CAF50;
  color: white;
}

.btn-primary:hover:not(:disabled) {
  background-color: #45a049;
}

.btn-success {
  background-color: #28a745;
  color: white;
}

.btn-success:hover:not(:disabled) {
  background-color: #218838;
}

.btn-warning {
  background-color: #ffc107;
  color: #212529;
}

.btn-warning:hover:not(:disabled) {
  background-color: #e0a800;
}

.btn-danger {
  background-color: #dc3545;
  color: white;
}

.btn-danger:hover:not(:disabled) {
  background-color: #c82333;
}

.btn-secondary {
  background-color: #6c757d;
  color: white;
}

.btn-secondary:hover {
  background-color: #5a6268;
}

/* 搜索和筛选栏 */
.search-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 15px;
}

.search-input-group {
  display: flex;
  align-items: center;
  background-color: white;
  border-radius: 8px;
  padding: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.search-type-select {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-radius: 4px 0 0 4px;
  font-size: 14px;
  background-color: #fff;
  color: #2c3e50;
  min-width: 120px;
  cursor: pointer;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-type-select:focus {
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input-group input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-left: none;
  border-right: none;
  font-size: 14px;
  color: #2c3e50;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-input-group input:focus {
  outline: none;
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input-group input::placeholder {
  color: #bdc3c7;
}

.search-btn {
  padding: 8px 16px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.3s ease;
}

.search-btn:hover {
  background-color: #2980b9;
}



/* 申诉记录表格 */
.appeals-table-container {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  margin-bottom: 20px;
}

.appeals-table {
  width: 100%;
  border-collapse: collapse;
}

.appeals-table thead {
  background-color: #f8f9fa;
}

.appeals-table th {
  padding: 12px 16px;
  text-align: left;
  font-weight: 600;
  color: #2c3e50;
  border-bottom: 2px solid #e0e0e0;
}

.appeals-table td {
  padding: 12px 16px;
  border-bottom: 1px solid #e0e0e0;
  color: #34495e;
}

.appeals-table tbody tr:hover {
  background-color: #f8f9fa;
}

.appeals-table tbody tr:last-child td {
  border-bottom: none;
}

.no-data {
  text-align: center;
  color: #95a5a6;
  padding: 40px;
}

.no-data svg {
  margin-bottom: 10px;
  color: #bdc3c7;
}

.no-data p {
  margin: 0;
  font-size: 16px;
}

/* 申诉原因文本 */
.reason-text {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 状态徽章 */
.status-badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.pending {
  background-color: #fff3cd;
  color: #856404;
}

.status-badge.approved {
  background-color: #d4edda;
  color: #155724;
}

.status-badge.rejected {
  background-color: #f8d7da;
  color: #721c24;
}

/* 操作按钮 */
.action-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0 10px;
  height: 32px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-right: 5px;
  font-size: 14px;
  white-space: nowrap;
}

.action-btn:last-child {
  margin-right: 0;
}

.view-btn {
  background-color: #3498db;
  color: white;
}

.view-btn:hover {
  background-color: #2980b9;
}

.approve-btn {
  background-color: #2ecc71;
  color: white;
}

.approve-btn:hover {
  background-color: #27ae60;
}

.reject-btn {
  background-color: #e74c3c;
  color: white;
}

.reject-btn:hover {
  background-color: #c0392b;
}

.delete-btn {
  background-color: #95a5a6;
  color: white;
}

.delete-btn:hover {
  background-color: #7f8c8d;
}



/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: #95a5a6;
  transition: color 0.3s;
}

.close-btn:hover {
  color: #2c3e50;
}

.modal-body {
  padding: 20px;
}

.detail-item {
  display: flex;
  margin-bottom: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid #f0f0f0;
}

.detail-item:last-child {
  border-bottom: none;
}

.detail-label {
  font-weight: 600;
  color: #2c3e50;
  min-width: 100px;
}

.detail-value {
  color: #34495e;
  flex: 1;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 20px;
  border-top: 1px solid #e0e0e0;
}

/* 过渡动画 */
.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s ease-in;
}

.slide-fade-enter-from {
  transform: translateX(-20px);
  opacity: 0;
}

.slide-fade-leave-to {
  transform: translateX(20px);
  opacity: 0;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .sidebar {
    width: 200px;
  }

  .stats-cards {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
  }

  .action-buttons {
    flex-direction: column;
  }

  .search-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .search-input-group {
    max-width: 100%;
  }

  .appeals-table-container {
    overflow-x: auto;
  }

  .appeals-table {
    min-width: 800px;
  }
}
</style>

