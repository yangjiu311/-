package com.example.studyroom.repository;

import com.example.studyroom.model.Row;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RowRepository extends JpaRepository<Row, Long> {
    Optional<Row> findByRowNumber(Integer rowNumber);
    boolean existsByRowNumber(Integer rowNumber);
}