package com.example.studyroom.repository;

import com.example.studyroom.model.SeatColumn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ColumnRepository extends JpaRepository<SeatColumn, Long> {
    Optional<SeatColumn> findByColumnNumber(Integer columnNumber);
    boolean existsByColumnNumber(Integer columnNumber);
}