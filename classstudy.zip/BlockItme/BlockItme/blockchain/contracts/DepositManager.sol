// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DepositManager {
    address public admin;
    mapping(address => uint256) public userDeposits;
    
    event DepositReceived(address user, uint256 amount);
    event DepositRefunded(address user, uint256 amount);
    event DepositForfeited(address user, uint256 amount);
    event EthRefundedAfterAppeal(address user, uint256 amount);
    
    constructor() {
        admin = msg.sender;
    }
    
    // 用户存入押金（预约时调用）- 支持任意金额
    function deposit() external payable {
        require(msg.value > 0, "Deposit amount must be greater than 0");
        userDeposits[msg.sender] = msg.value;
        emit DepositReceived(msg.sender, msg.value);
    }
    
    // 支持直接向合约地址转账 - 支持任意金额
    receive() external payable {
        require(msg.value > 0, "Deposit amount must be greater than 0");
        // 直接转账的资金不记录到userDeposits中，直接成为合约余额的一部分
        // 这部分资金会自动成为违约金额的一部分
        emit DepositReceived(msg.sender, msg.value);
    }
    
    // 用户自己退还押金
    function refund() external {
        uint256 depositAmount = userDeposits[msg.sender];
        require(depositAmount > 0, "No deposit to refund");
        
        userDeposits[msg.sender] = 0;
        payable(msg.sender).transfer(depositAmount);
        emit DepositRefunded(msg.sender, depositAmount);
    }
    
    // 管理员退还押金给用户
    function refundForUser(address user) external onlyAdmin {
        uint256 depositAmount = userDeposits[user];
        require(depositAmount > 0, "No deposit to refund");
        
        userDeposits[user] = 0;
        payable(user).transfer(depositAmount);
        emit DepositRefunded(user, depositAmount);
    }
    
    // 没收押金（违约时调用）
    function forfeit(address user) external onlyAdmin {
        uint256 depositAmount = userDeposits[user];
        require(depositAmount > 0, "No deposit to forfeit");
        
        userDeposits[user] = 0;
        emit DepositForfeited(user, depositAmount);
    }
    
    // 管理员提取合约余额（支持提取任意金额到指定地址）
    function withdrawTo(address recipient, uint256 amount) external onlyAdmin {
        uint256 balance = address(this).balance;
        require(amount > 0, "Amount must be greater than 0");
        require(amount <= balance, "Insufficient contract balance");
        require(recipient != address(0), "Recipient address cannot be zero");
        
        payable(recipient).transfer(amount);
    }
    
    // 管理员提取合约余额（支持提取任意金额到管理员地址）
    function withdraw(uint256 amount) external onlyAdmin {
        uint256 balance = address(this).balance;
        require(amount > 0, "Amount must be greater than 0");
        require(amount <= balance, "Insufficient contract balance");
        
        payable(admin).transfer(amount);
    }
    
    // 通过申诉后向用户转账1ETH
    function refundEthAfterAppeal(address user) external onlyAdmin {
        uint256 balance = address(this).balance;
        uint256 refundAmount = 1 ether;
        
        require(user != address(0), "User address cannot be zero");
        require(balance >= refundAmount, "Insufficient contract balance");
        
        payable(user).transfer(refundAmount);
        emit EthRefundedAfterAppeal(user, refundAmount);
    }
    
    modifier onlyAdmin() {
        require(msg.sender == admin, "Not admin");
        _;
    }
}