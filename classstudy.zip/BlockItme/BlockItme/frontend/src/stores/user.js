import { defineStore } from 'pinia'
import { Web3 } from 'web3'

export const useUserStore = defineStore('user', {
  state: () => ({
    isLoggedIn: false,
    userInfo: null,
    walletAddress: null,
    web3: null,
    contract: null
  }),
  
  onMounted() {
    // 从本地存储加载用户信息
    const savedUserInfo = localStorage.getItem('userInfo')
    if (savedUserInfo) {
      this.userInfo = JSON.parse(savedUserInfo)
      this.isLoggedIn = true
      this.walletAddress = this.userInfo.wallet_address
    }
    
    // 从本地存储加载钱包地址
    const savedWalletAddress = localStorage.getItem('walletAddress')
    if (savedWalletAddress) {
      this.walletAddress = savedWalletAddress
    }
  },
  
  getters: {
    isAdmin: (state) => state.userInfo?.role === 'admin'
  },
  
  actions: {
    login(userInfo, token) {
      this.isLoggedIn = true
      this.userInfo = userInfo
      this.walletAddress = userInfo.wallet_address
      localStorage.setItem('token', token)
      localStorage.setItem('userInfo', JSON.stringify(userInfo))
    },
    
    logout() {
      this.isLoggedIn = false
      this.userInfo = null
      this.walletAddress = null
      localStorage.removeItem('token')
      localStorage.removeItem('userInfo')
    },
    
    async initWeb3() {
      try {
        // 强制连接到Ganache本地节点（不使用MetaMask的provider，避免网络不匹配问题）
        const ganacheUrl = 'http://127.0.0.1:7545'
        this.web3 = new Web3(ganacheUrl)
        console.log('已连接到本地Ganache节点:', ganacheUrl)
        
        // 获取当前网络信息
        const networkId = await this.web3.eth.net.getId()
        console.log('当前网络ID:', networkId)
        
        // 获取Ganache中的账户列表
        const accounts = await this.web3.eth.getAccounts()
        console.log('Ganache账户列表:', accounts)
        if (accounts.length > 0) {
          console.log('第一个账户:', accounts[0])
          // 获取第一个账户的余额
          const balance = await this.web3.eth.getBalance(accounts[0])
          console.log('第一个账户余额:', this.web3.utils.fromWei(balance, 'ether'), 'ETH')
        }
      } catch (error) {
        console.error('Web3初始化失败:', error)
        throw error
      }
    },
    
    async connectWallet() {
      if (!this.web3) {
        await this.initWeb3()
      }
      
      try {
        // 请求用户连接MetaMask钱包
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
        const connectedAddress = accounts[0]
        this.walletAddress = connectedAddress
        
        // 将钱包地址保存到本地存储，确保页面跳转后仍然保持连接状态
        localStorage.setItem('walletAddress', connectedAddress)
        
        // 获取钱包余额
        const balance = await this.web3.eth.getBalance(connectedAddress)
        const balanceInEth = this.web3.utils.fromWei(balance, 'ether')
        
        console.log('钱包连接成功，地址:', connectedAddress)
        console.log('当前钱包余额:', balanceInEth, 'ETH')
        
        // 如果余额不足，提示用户
        if (parseFloat(balanceInEth) < 1) {
          alert(`已连接钱包地址：${connectedAddress}\n当前余额：${balanceInEth} ETH\n余额不足1 ETH，请切换到有足够余额的账户后重新连接！`)
        }
        
        return connectedAddress
      } catch (error) {
        console.error('钱包连接失败:', error)
        return null
      }
    }
  }
})