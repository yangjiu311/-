package com.example.studyroom.controller;

import com.example.studyroom.model.Area;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.Seat;
import com.example.studyroom.model.User;
import com.example.studyroom.service.AreaService;
import com.example.studyroom.service.ReservationService;
import com.example.studyroom.service.SeatService;
import com.example.studyroom.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ReservationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService;

    @Autowired
    private SeatService seatService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private AreaService areaService;

    @Autowired
    private ObjectMapper objectMapper;

    private String testUserId = "test-user-123";
    private Long testSeatId1;
    private Long testSeatId2;

    @BeforeEach
    public void setUp() {
        // 清理测试数据（按依赖顺序删除）
        // 删除预约记录
        List<Reservation> allReservations = reservationService.getAllReservations();
        for (Reservation reservation : allReservations) {
            if (reservation.getUserId().equals(testUserId)) {
                reservationService.deleteReservation(reservation.getId());
            }
        }
        
        // 删除座位记录
        List<Seat> allSeats = seatService.getAllSeats();
        for (Seat seat : allSeats) {
            if (seat.getClassroomName().equals("Classroom 1")) {
                seatService.deleteSeat(seat.getId());
            }
        }
        
        // 删除用户记录
        if (userService.existsByUserId(testUserId)) {
            Optional<User> existingUser = userService.getUserByUserId(testUserId);
            existingUser.ifPresent(user -> userService.deleteUser(user.getId()));
        }
        
        // 删除区域记录
        if (areaService.existsByClassroomName("Classroom 1")) {
            List<Area> areas = areaService.getAllAreas();
            for (Area area : areas) {
                if (area.getClassroomName().equals("Classroom 1")) {
                    areaService.deleteArea(area.getId());
                    break;
                }
            }
        }
        Area area = new Area();
        area.setClassroomName("Classroom 1");
        areaService.createArea(area);

        // 创建测试用户
        if (userService.existsByUserId(testUserId)) {
            // 获取User对象并删除
            Optional<User> existingUser = userService.getUserByUserId(testUserId);
            existingUser.ifPresent(user -> userService.deleteUser(user.getId()));
        }
        User user = new User();
        user.setUserId(testUserId);
        user.setPassword("password");
        user.setRole(User.Role.student);
        user.setStatus(User.Status.enabled);
        user.setName("Test User");
        user.setPhone("1234567890");
        user.setStudentId("TEST-STU-123"); // 设置学生ID，满足数据库约束
        user.setCreatedAt(LocalDateTime.now());
        userService.createUser(user);

        // 创建测试座位1
        Seat seat1 = new Seat();
        seat1.setSeatNumber("Seat 1");
        seat1.setClassroomName("Classroom 1");
        seat1.setRow(1);
        seat1.setColumn(1);
        seat1.setStatus(Seat.Status.available);
        seat1.setCreatedAt(LocalDateTime.now());
        Seat savedSeat1 = seatService.createSeat(seat1);
        testSeatId1 = savedSeat1.getId();

        // 创建测试座位2
        Seat seat2 = new Seat();
        seat2.setSeatNumber("Seat 2");
        seat2.setClassroomName("Classroom 1");
        seat2.setRow(1);
        seat2.setColumn(2);
        seat2.setStatus(Seat.Status.available);
        seat2.setCreatedAt(LocalDateTime.now());
        Seat savedSeat2 = seatService.createSeat(seat2);
        testSeatId2 = savedSeat2.getId();

        // 创建测试预约记录1
        Reservation reservation1 = new Reservation();
        reservation1.setUserId(testUserId);
        reservation1.setStuAdminId(testUserId); // 设置学生/管理员ID
        reservation1.setSeatId(testSeatId1);
        reservation1.setSeatNumber("Seat 1"); // 设置座位号
        reservation1.setStartTime(LocalDateTime.now().plusHours(1));
        reservation1.setEndTime(LocalDateTime.now().plusHours(2));
        reservation1.setReservationDate(LocalDate.now()); // 设置预约日期
        reservation1.setStatus(Reservation.Status.confirmed);
        reservation1.setClassroomName("Classroom 1"); // 设置教室名称
        reservation1.setCreatedAt(LocalDateTime.now()); // 设置创建时间
        reservationService.createReservation(reservation1);

        // 创建测试预约记录2
        Reservation reservation2 = new Reservation();
        reservation2.setUserId(testUserId);
        reservation2.setStuAdminId(testUserId); // 设置学生/管理员ID
        reservation2.setSeatId(testSeatId2);
        reservation2.setSeatNumber("Seat 2"); // 设置座位号
        reservation2.setStartTime(LocalDateTime.now().plusDays(1).plusHours(1));
        reservation2.setEndTime(LocalDateTime.now().plusDays(1).plusHours(2));
        reservation2.setReservationDate(LocalDate.now().plusDays(1)); // 设置预约日期
        reservation2.setStatus(Reservation.Status.confirmed);
        reservation2.setClassroomName("Classroom 1"); // 设置教室名称
        reservation2.setCreatedAt(LocalDateTime.now()); // 设置创建时间
        reservationService.createReservation(reservation2);
    }

    @Test
    public void testGetReservationsByUserId() throws Exception {
        // 调用API获取用户预约记录
        MvcResult result = mockMvc.perform(get("/reservations/user/" + testUserId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // 解析响应
        List<Reservation> reservations = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                objectMapper.getTypeFactory().constructCollectionType(List.class, Reservation.class)
        );

        // 验证结果
        assertFalse(reservations.isEmpty(), "用户应该有预约记录");
        assertEquals(2, reservations.size(), "用户应该有2条预约记录");
        
        // 验证预约记录属于正确的用户
        for (Reservation reservation : reservations) {
            assertEquals(testUserId, reservation.getUserId(), "预约记录应该属于测试用户");
        }
        
        System.out.println("测试通过：成功获取到用户的所有预约记录");
        System.out.println("共获取到 " + reservations.size() + " 条预约记录");
        for (Reservation reservation : reservations) {
            System.out.println("预约ID：" + reservation.getId() + ", 座位ID：" + reservation.getSeatId() + ", 状态：" + reservation.getStatus());
        }
    }
}