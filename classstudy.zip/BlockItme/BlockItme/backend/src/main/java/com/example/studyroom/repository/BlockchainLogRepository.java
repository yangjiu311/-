package com.example.studyroom.repository;

import com.example.studyroom.model.BlockchainLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BlockchainLogRepository extends JpaRepository<BlockchainLog, Long> {
    List<BlockchainLog> findByUserId(String userId);
    List<BlockchainLog> findByOperationType(BlockchainLog.OperationType operationType);
    List<BlockchainLog> findByStatus(BlockchainLog.Status status);
    Optional<BlockchainLog> findByTransactionHash(String transactionHash);
    List<BlockchainLog> findByBlockHeight(Long blockHeight);
    List<BlockchainLog> findByUserIdAndOperationType(String userId, BlockchainLog.OperationType operationType);
    List<BlockchainLog> findByOperationTypeAndStatus(BlockchainLog.OperationType operationType, BlockchainLog.Status status);
    List<BlockchainLog> findByTargetId(Long targetId);
}