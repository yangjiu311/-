package com.example.studyroom.controller;

import com.example.studyroom.dto.LoginRequest;
import com.example.studyroom.dto.LoginResponse;
import com.example.studyroom.model.User;
import com.example.studyroom.service.UserService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;
import java.util.UUID;

/**
 * 认证控制器
 */
@RestController
@RequestMapping("/auth")
@AllArgsConstructor
public class AuthController {
    
    private final UserService userService;
    
    /**
     * 用户登录
     * @param loginRequest 登录请求参数
     * @return 登录响应
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
        Optional<User> optionalUser = userService.login(
                loginRequest.getUserId(),
                loginRequest.getPassword(),
                loginRequest.getRole()
        );
        
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // 生成简单的模拟token（实际项目中应该使用JWT）
            String token = "Bearer " + UUID.randomUUID().toString();
            
            // 创建登录响应
            LoginResponse response = new LoginResponse(
                    user,
                    token,
                    "登录成功"
            );
            
            return ResponseEntity.ok(response);
        } else {
            // 登录失败
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("账号、密码或角色错误");
        }
    }
}