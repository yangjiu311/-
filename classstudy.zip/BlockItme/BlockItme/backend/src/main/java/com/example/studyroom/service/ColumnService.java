package com.example.studyroom.service;

import com.example.studyroom.model.SeatColumn;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ColumnService {
    List<SeatColumn> getAllColumns();
    Page<SeatColumn> getAllColumns(Pageable pageable);
    Optional<SeatColumn> getColumnById(Long id);
    Optional<SeatColumn> getColumnByColumnNumber(Integer columnNumber);
    SeatColumn saveColumn(SeatColumn column);
    void deleteColumn(Long id);
    boolean existsByColumnNumber(Integer columnNumber);
}