package com.example.studyroom.service;

import com.example.studyroom.model.CheckIn;
import java.util.List;
import java.util.Optional;

public interface CheckInService {
    List<CheckIn> getAllCheckIns();
    Optional<CheckIn> getCheckInById(Long id);
    Optional<CheckIn> getCheckInByReservationId(Long reservationId);
    List<CheckIn> getCheckInsByUserId(String userId);
    List<CheckIn> getCheckInsByStatus(CheckIn.Status status);
    List<CheckIn> getCheckInsByUserIdAndStatus(String userId, CheckIn.Status status);
    Optional<CheckIn> getCheckInByTransactionHash(String transactionHash);
    CheckIn createCheckIn(CheckIn checkIn);
    CheckIn updateCheckIn(Long id, CheckIn checkIn);
    void deleteCheckIn(Long id);
    boolean existsByReservationId(Long reservationId);
    CheckIn updateDisplayStatus(Long id, CheckIn.DisplayStatus display);
    List<CheckIn> getCheckInsByUserIdAndDisplay(String userId, CheckIn.DisplayStatus display);
    void deleteCheckInByReservationId(Long reservationId);
}