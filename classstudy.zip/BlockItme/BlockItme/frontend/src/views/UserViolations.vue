<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="12" y1="9" x2="12" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="12" y1="17" x2="12.01" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>违约记录</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 统计卡片区域 -->
      <section class="stats-cards">
        <div class="stat-card">
          <div class="card-icon total-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <line x1="12" y1="9" x2="12" y2="13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <line x1="12" y1="17" x2="12.01" y2="17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>总违约次数</h3>
            <p class="stat-value">{{ stats.totalViolations }}</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="card-icon recent-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2" stroke="white" stroke-width="2"/>
              <line x1="16" y1="2" x2="16" y2="6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <line x1="8" y1="2" x2="8" y2="6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <line x1="3" y1="10" x2="21" y2="10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="card-content">
            <h3>本月违约</h3>
            <p class="stat-value">{{ stats.monthlyViolations }}</p>
          </div>
        </div>
      </section>

      <!-- 过滤栏区域 -->
      <section class="filter-section">
        <div class="filter-bar">
          <div class="filter-group">
            <label for="type-filter">违约类型</label>
            <select id="type-filter" class="form-control status-select" v-model="typeFilter">
              <option value="">全部类型</option>
              <option value="long_late">长期迟到</option>
              <option value="no_show">未签到</option>
              <option value="early_leave">早退</option>
            </select>
          </div>
          <div class="filter-actions">
            <button class="primary-btn filter-btn" @click="searchViolations">查询</button>
            <button class="secondary-btn reset-btn" @click="resetFilters">重置</button>
          </div>
        </div>
      </section>

      <!-- 违约记录列表区域 -->
      <section class="violations-section">
        <div class="violations-card">
          <h2>我的违约记录</h2>
          <div class="violations-list">
            <table class="violations-table">
              <thead>
                <tr>
                  <th>违约ID</th>
                  <th>预约ID</th>
                  <th>座位号</th>
                  <th>区域</th>
                  <th>违约类型</th>
                  <th>违约时间</th>
                  <th>记录时间</th>
                  <th class="actions-column">操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="loading">
                  <td colspan="8" class="loading-text">加载中...</td>
                </tr>
                <tr v-else-if="error">
                  <td colspan="8" class="error-text">{{ error }}</td>
                </tr>
                <tr v-else-if="violations.length === 0">
                  <td colspan="8" class="empty-text">暂无违约记录</td>
                </tr>
                <tr v-for="violation in violations" :key="violation.id">
                  <td>{{ violation.id }}</td>
                  <td>{{ violation.reservationId }}</td>
                  <td>{{ violation.seatNumber || '-' }}</td>
                  <td>{{ violation.classroomName || '-' }}</td>
                  <td>
                    <span :class="['violation-type', violation.violationType]">
                      {{ getViolationTypeText(violation.violationType) }}
                    </span>
                  </td>
                  <td>{{ formatDate(violation.violationTime) }}</td>
                  <td>{{ formatDate(violation.createdAt) }}</td>
                  <td class="actions-column">
                    <button class="btn-view" @click="viewViolation(violation.id)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      查看
                    </button>
                    <button class="btn-appeal" @click="handleAppeal(violation)">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      申诉
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- 申诉功能框 -->
      <div class="appeal-modal" v-if="appealDialogVisible">
        <div class="modal-overlay" @click="appealDialogVisible = false"></div>
        <div class="modal-content">
          <div class="modal-header">
            <h3>违约申诉</h3>
            <button class="close-btn" @click="appealDialogVisible = false">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <form class="appeal-form">
              <div class="form-group">
                <label>用户ID</label>
                <input type="text" class="form-control" v-model="appealForm.userId" disabled>
              </div>
              <div class="form-group">
                <label>学号/工号</label>
                <input type="text" class="form-control" v-model="appealForm.stuAdminId" disabled>
              </div>
              <div class="form-group">
                <label>违约ID</label>
                <input type="text" class="form-control" v-model="appealForm.violationId" disabled>
              </div>
              <div class="form-group">
                <label>创建时间</label>
                <input type="text" class="form-control" v-model="appealForm.createTime" disabled>
              </div>
              <div class="form-group">
                <label>申诉内容</label>
                <textarea class="form-control" v-model="appealForm.content" rows="4" placeholder="请输入您的申诉内容"></textarea>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button class="secondary-btn" @click="appealDialogVisible = false">取消</button>
            <button class="primary-btn" @click="submitAppeal">提交申诉</button>
          </div>
        </div>
      </div>

      <!-- 违约详情弹窗 -->
      <div class="violation-modal" v-if="violationDialogVisible">
        <div class="modal-overlay" @click="violationDialogVisible = false"></div>
        <div class="modal-content violation-detail-content">
          <div class="modal-header">
            <h3>违约详情</h3>
            <button class="close-btn" @click="violationDialogVisible = false">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
          <div class="modal-body">
            <div v-if="isUploading" class="loading-state">
              <p>正在将违约信息上链，请稍候...</p>
            </div>
            <div v-else>
              <div class="violation-info">
                <div class="info-row">
                  <span class="info-label">违约ID:</span>
                  <span class="info-value">{{ currentViolation?.id }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">预约ID:</span>
                  <span class="info-value">{{ currentViolation?.reservationId }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">座位号:</span>
                  <span class="info-value">{{ currentViolation?.seatNumber || '-' }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">区域:</span>
                  <span class="info-value">{{ currentViolation?.classroomName || '-' }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">违约类型:</span>
                  <span class="info-value">{{ getViolationTypeText(currentViolation?.violationType) }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">违约时间:</span>
                  <span class="info-value">{{ formatDate(currentViolation?.violationTime) }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">记录时间:</span>
                  <span class="info-value">{{ formatDate(currentViolation?.createdAt) }}</span>
                </div>
                <div v-if="uploadError" class="error-message">
                  {{ uploadError }}
                </div>
              </div>
              
              <div v-if="blockchainResult" class="blockchain-info">
                <h4>区块链信息</h4>
                <div class="info-row">
                  <span class="info-label">交易哈希:</span>
                  <span class="info-value hash-value">{{ blockchainResult.transactionHash }}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">区块高度:</span>
                  <span class="info-value">{{ blockchainResult.blockHeight }}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="primary-btn" @click="violationDialogVisible = false">关闭</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted } from 'vue'
import { getUserViolations, updateViolationStatus, createAppeal } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 区块链浏览器URL
const blockchainExplorerUrl = import.meta.env.VITE_BLOCKCHAIN_EXPLORER_URL || 'http://localhost:8545'



// 数据状态
const loading = ref(false)
const error = ref('')
const violations = ref([])
const originalViolations = ref([]) // 保存原始数据

// 过滤条件
const typeFilter = ref('')
const dateFilter = ref('')

// 统计数据
const stats = ref({
  totalViolations: 0,
  monthlyViolations: 0
})

// 申诉功能相关
const appealDialogVisible = ref(false)
const appealForm = ref({
  userId: '',
  stuAdminId: '',
  violationId: '',
  createTime: '',
  content: ''
})

// 违约详情弹窗相关
const violationDialogVisible = ref(false)
const currentViolation = ref(null)
const blockchainResult = ref(null)
const isUploading = ref(false)
const uploadError = ref('')

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 获取违约记录列表
const fetchViolations = async () => {
  loading.value = true
  error.value = ''
  try {
    // 获取当前登录用户的ID（优先使用userId，因为后端API需要String类型的userId）
    const userId = userStore.userInfo?.userId || userStore.userInfo?.id
    
    if (!userId) {
      error.value = '用户信息不存在，请重新登录'
      loading.value = false
      return
    }
    
    // 调用真实的API获取用户违约记录
    const data = await getUserViolations(userId)
    violations.value = data
    originalViolations.value = data // 保存原始数据
    
    // 更新统计数据
    updateStats()
  } catch (err) {
    error.value = '获取违约记录失败'
    console.error('获取违约记录失败:', err)
  } finally {
    loading.value = false
  }
}

// 更新统计数据
const updateStats = () => {
  stats.value.totalViolations = violations.value.length
  
  // 计算本月违约次数
  const now = new Date()
  const currentMonth = now.getMonth()
  const currentYear = now.getFullYear()
  stats.value.monthlyViolations = violations.value.filter(v => {
    const date = new Date(v.createdAt)
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear
  }).length
}

// 查询违约记录
const searchViolations = () => {
  if (!typeFilter.value) {
    // 如果没有选择类型，获取所有违约记录
    fetchViolations()
  } else {
    // 根据选择的类型过滤违约记录
    const filtered = originalViolations.value.filter(v => v.violationType === typeFilter.value)
    violations.value = filtered
  }
}

// 重置过滤条件
const resetFilters = () => {
  typeFilter.value = ''
  dateFilter.value = ''
  fetchViolations()
}

// 查看违约详情
const viewViolation = async (id) => {
  console.log('查看违约详情:', id)
  
  try {
    // 查找对应的违约记录
    const violation = violations.value.find(v => v.id === id)
    if (!violation) {
      alert('违约记录不存在')
      return
    }
    
    currentViolation.value = violation
    uploadError.value = ''
    
    // 检查是否已经上链
    if (violation.transactionHash && violation.blockHeight) {
      console.log('违约信息已上链，跳过上链步骤')
      blockchainResult.value = {
        transactionHash: violation.transactionHash,
        blockHeight: violation.blockHeight
      }
      violationDialogVisible.value = true
    } else {
      // 未上链，执行上链操作
      isUploading.value = true
      
      // 准备上链数据
      const violationData = {
        id: violation.id,
        reservationId: violation.reservationId,
        seatNumber: violation.seatNumber,
        classroomName: violation.classroomName,
        violationType: violation.violationType,
        violationTime: violation.violationTime,
        penaltyAmount: violation.penaltyAmount,
        createdAt: violation.createdAt
      }
      
      // 调用后端API将违约信息上链
      const response = await updateViolationStatus(violation.id, {
        status: violation.status || 'unpaid',
        uploadToBlockchain: true
      })
      
      blockchainResult.value = {
        transactionHash: response.transactionHash,
        blockHeight: response.blockHeight
      }
      
      // 更新本地记录，标记为已上链
      violation.transactionHash = response.transactionHash
      violation.blockHeight = response.blockHeight
      
      // 显示详情弹窗
      violationDialogVisible.value = true
    }
  } catch (error) {
    console.error('上链失败:', error)
    uploadError.value = '上链失败，请重试'
    // 即使上链失败，也显示详情
    violationDialogVisible.value = true
  } finally {
    isUploading.value = false
  }
}

// 缴纳罚款
const payViolation = (id) => {
  console.log('缴纳罚款:', id)
  // TODO: 实现缴纳罚款功能
}

// 处理申诉
const handleAppeal = (violation) => {
  // 检查 userStore.userInfo 的值
  console.log('userStore.userInfo:', userStore.userInfo)
  console.log('userStore.isLoggedIn:', userStore.isLoggedIn)
  
  // 确保 userInfo 存在
  const userInfo = userStore.userInfo || {}
  
  // 自动填写字段
  appealForm.value = {
    userId: userInfo.userId || userInfo.id || '未知用户ID',
    stuAdminId: userInfo.stu_admin_id || userInfo.stuAdminId || userInfo.userNo || userInfo.userId || userInfo.id || '未知学号/工号',
    violationId: violation.id,
    createTime: formatDate(new Date()),
    content: ''
  }
  console.log('appealForm:', appealForm.value)
  appealDialogVisible.value = true
}

// 提交申诉
const submitAppeal = async () => {
  if (!appealForm.value.content.trim()) {
    alert('请输入申诉内容')
    return
  }
  
  try {
    const userId = userStore.userInfo?.userId || userStore.userInfo?.id
    
    if (!userId) {
      alert('用户信息不存在，请重新登录')
      return
    }
    
    // 构建申诉数据
    const appealData = {
      userId: userId,
      stuAdminId: appealForm.value.stuAdminId,
      violationId: appealForm.value.violationId,
      appealContent: appealForm.value.content,
      appealStatus: 'pending'
    }
    
    // 调用后端API提交申诉
    console.log('提交申诉数据:', appealData)
    await createAppeal(appealData)
    
    alert('申诉提交成功，已上链')
    appealDialogVisible.value = false
    
    // 刷新违约记录列表，查看最新状态
    await fetchViolations()
  } catch (error) {
    console.error('提交申诉失败:', error)
    alert('申诉提交失败，请重试')
  }
}

// 获取违约类型文本
const getViolationTypeText = (type) => {
  const typeMap = {
    'long_late': '长期迟到',
    'no_show': '未签到',
    'early_leave': '早退'
  }
  return typeMap[type] || type
}

// 获取状态文本
const getStatusText = (status) => {
  const statusMap = {
    'unpaid': '未缴纳',
    'paid': '已缴纳',
    'cancelled': '已取消'
  }
  return statusMap[status] || status
}

// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '-'
  const date = new Date(dateString)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 页面加载时获取数据
onMounted(() => {
  fetchViolations()
})
</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f5f6fa;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 10px;
}

/* 主内容区域 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  padding: 20px;
}

/* 顶部导航栏 */
.top-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e0e0e0;
}

.nav-left h1 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.user-info {
  position: relative;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
}

.username {
  font-weight: 600;
  color: #333;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  background: white;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  min-width: 160px;
  z-index: 100;
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 15px;
  width: 100%;
  text-align: left;
  border: none;
  background: none;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.2s;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

/* 统计卡片 */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.card-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.total-icon {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.penalty-icon {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.long-late-icon {
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
}

.recent-icon {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.card-content h3 {
  margin: 0 0 5px 0;
  color: #666;
  font-size: 14px;
  font-weight: 500;
}

.stat-value {
  margin: 0;
  font-size: 28px;
  font-weight: bold;
  color: #333;
}

/* 过滤栏 */
.filter-section {
  margin-bottom: 20px;
}

.filter-bar {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  padding: 20px;
  display: flex;
  gap: 20px;
  align-items: flex-end;
  flex-wrap: wrap;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.filter-group label {
  font-size: 14px;
  color: #333;
  font-weight: 500;
}

.form-control {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  color: #333;
  background-color: #f9f9f9;
  transition: all 0.3s ease;
  min-width: 150px;
}

.form-control:focus {
  outline: none;
  border-color: #4CAF50;
  box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.2);
  background-color: white;
}

.filter-actions {
  display: flex;
  gap: 10px;
}

.primary-btn, .secondary-btn {
  padding: 8px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover {
  background-color: #45a049;
}

.secondary-btn {
  background-color: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.secondary-btn:hover {
  background-color: #e0e0e0;
}

/* 违约记录卡片 */
.violations-section {
  flex: 1;
}

.violations-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  padding: 20px;
}

.violations-card h2 {
  margin: 0 0 20px 0;
  color: #333;
  font-size: 18px;
  font-weight: 600;
}

.violations-list {
  overflow-x: auto;
}

.violations-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}

.violations-table thead {
  background-color: #f8f9fa;
}

.violations-table th {
  padding: 12px;
  text-align: left;
  font-weight: 600;
  color: #333;
  border-bottom: 2px solid #e0e0e0;
  white-space: nowrap;
}

.violations-table td {
  padding: 12px;
  border-bottom: 1px solid #e0e0e0;
  color: #666;
}

.violations-table tbody tr:hover {
  background-color: #f8f9fa;
}

.violations-table .loading-text,
.violations-table .error-text,
.violations-table .empty-text {
  text-align: center;
  padding: 40px;
  color: #999;
}

.violations-table .error-text {
  color: #f44336;
}

/* 违约类型标签 */
.violation-type {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
}

.violation-type.long_late {
  background-color: #fff3cd;
  color: #856404;
}

.violation-type.no_show {
  background-color: #f8d7da;
  color: #721c24;
}

.violation-type.early_leave {
  background-color: #d1ecf1;
  color: #0c5460;
}

/* 罚款金额 */
.penalty-amount {
  font-weight: 600;
  color: #f44336;
}

/* 状态标签 */
.status-column {
  white-space: nowrap;
}

/* 交易哈希列 */
.hash-column {
  white-space: nowrap;
}

.transaction-hash {
  font-family: 'Courier New', monospace;
  font-size: 12px;
  color: #666;
  cursor: help;
}

.transaction-hash:hover {
  color: #2196F3;
}

.status {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
}

.status.unpaid {
  background-color: #f8d7da;
  color: #721c24;
}

.status.paid {
  background-color: #d4edda;
  color: #155724;
}

.status.cancelled {
  background-color: #e2e3e5;
  color: #383d41;
}

/* 操作按钮 */
.actions-column {
  white-space: nowrap;
  text-align: center;
}

th.actions-column {
  text-align: center;
  vertical-align: middle;
}

.btn-view,
.btn-pay,
.btn-appeal {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-right: 5px;
}

.btn-view {
  background-color: #2196F3;
  color: white;
}

.btn-view:hover {
  background-color: #1976D2;
}

.btn-pay {
  background-color: #4CAF50;
  color: white;
}

.btn-pay:hover {
  background-color: #45a049;
}

.btn-appeal {
  background-color: #ff9800;
  color: white;
}

.btn-appeal:hover {
  background-color: #f57c00;
}

/* 申诉模态框样式 */
.appeal-modal,
.violation-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  position: relative;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  width: 90%;
  max-width: 500px;
  z-index: 1001;
  animation: modalFadeIn 0.3s ease;
}

@keyframes modalFadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  color: #333;
  font-size: 18px;
  font-weight: 600;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #666;
  transition: color 0.2s;
}

.close-btn:hover {
  color: #333;
}

.modal-body {
  padding: 20px;
}

.appeal-form {
  width: 100%;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  font-weight: 500;
  color: #333;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  color: #333;
  transition: all 0.3s ease;
}

.form-group input:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #4CAF50;
  box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.2);
}

.form-group input:disabled {
  background-color: #f5f5f5;
  color: #999;
  cursor: not-allowed;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 16px 20px;
  border-top: 1px solid #e0e0e0;
  background-color: #f9f9f9;
}

/* 哈希值样式 */
.hash-value {
  word-break: break-all;
  word-wrap: break-word;
  white-space: normal;
  max-width: 100%;
  display: inline-block;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .stats-cards {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .sidebar {
    width: 60px;
  }
  
  .sidebar-header h2,
  .nav-item span {
    display: none;
  }
  
  .nav-icon {
    margin-right: 0;
  }
  
  .stats-cards {
    grid-template-columns: 1fr;
  }
  
  .filter-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .form-control {
    min-width: 100%;
  }
  
  .filter-actions {
    justify-content: stretch;
  }
  
  .primary-btn,
  .secondary-btn {
    flex: 1;
  }
  
  .modal-content {
    width: 95%;
    margin: 20px;
  }
}
</style>











