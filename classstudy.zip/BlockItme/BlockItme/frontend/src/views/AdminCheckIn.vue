<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>仪表盘</span>
        </router-link>
        <router-link to="/admin/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位管理</span>
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>用户管理</span>
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l-.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>签到记录</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">管理员</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/admin/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/admin/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 签到记录内容区域 -->
      <section class="checkins-management">
        <!-- 搜索栏 -->
        <div class="search-bar">
          <select v-model="searchType" class="search-select">
            <option value="seatId">座位号</option>
            <option value="reservationId">预约ID</option>
          </select>
          <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索签到记录..." @input="handleSearch">
          <button class="search-btn" @click="handleSearch">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.74948 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            搜索
          </button>
        </div>

        <!-- 签到记录表格 -->
        <div class="checkins-list">
          <table class="checkins-table">
            <thead>
              <tr>
                <th><input type="checkbox" class="select-all" @change="handleSelectAll"></th>
                <th>签到ID</th>
                <th>用户ID</th>
                <th>座位号</th>
                <th>预约ID</th>
                <th>签到时间</th>
                <th>状态</th>
                <th>签到哈希</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <template v-for="checkin in filteredCheckins" :key="checkin.id">
                <!-- 主行 -->
                <tr :class="{'selected': selectedCheckins.includes(checkin.id)}">
                  <td><input type="checkbox" class="select-checkin" :value="checkin.id" v-model="selectedCheckins"></td>
                  <td>{{ checkin.id }}</td>
                  <td>{{ checkin.user_id }}</td>
                  <td>{{ checkin.seat_id }}</td>
                  <td>{{ checkin.reservation_id }}</td>
                  <td>{{ formatCheckinTime(checkin.checkin_time) }}</td>
                  <td>
                    <span :class="['status', checkin.status]">
                      {{ formatStatus(checkin.status) }}
                    </span>
                  </td>
                  <td class="hash-cell">{{ checkin.checkin_hash || '-' }}</td>
                  <td>
                    <button 
                      class="btn-view" 
                      @click="handleViewCheckin(checkin.id)"
                      title="查看详情"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 12C13.6569 12 15 10.6569 15 9C15 7.34315 13.6569 6 12 6C10.3431 6 9 7.34315 9 9C9 10.6569 10.3431 12 12 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                    <button 
                      class="btn-delete" 
                      @click="handleDeleteCheckIn(checkin.id)"
                      title="删除"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 6H5M5 6H21M5 6L5 20C5 20.5304 5.21071 21.0391 5.58579 21.4142C5.96086 21.7893 6.46957 22 7 22H17C17.5304 22 18.0391 21.7893 18.4142 21.4142C18.7893 21.0391 19 20.5304 19 20V6M19 6L19 4C19 3.46957 18.7893 2.96086 18.4142 2.58579C18.0391 2.21071 17.5304 2 17 2H7C6.46957 2 5.96086 2.21071 5.58579 2.58579C5.21071 2.96086 5 3.46957 5 4L5 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </button>
                  </td>
                </tr>
              </template>
              <tr v-if="filteredCheckins.length === 0">
                <td colspan="9" class="no-data">暂无签到记录</td>
              </tr>
            </tbody>
          </table>
        </div>


      </section>
    </main>
  </div>

  <!-- 查看详情模态框 -->
  <div class="modal-overlay" v-if="showViewModal" @click="showViewModal = false">
    <div class="modal-content" @click.stop>
      <div class="modal-header">
        <h3>签到详情</h3>
        <button class="modal-close" @click="showViewModal = false">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="checkin-info" v-if="currentCheckin">
          <div class="info-grid">
            <div class="info-item">
              <span class="info-label">签到ID:</span>
              <span class="info-value">{{ currentCheckin.id }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">用户ID:</span>
              <span class="info-value">{{ currentCheckin.user_id }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">座位号:</span>
              <span class="info-value">{{ currentCheckin.seat_id }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">预约ID:</span>
              <span class="info-value">{{ currentCheckin.reservation_id }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">签到时间:</span>
              <span class="info-value">{{ formatCheckinTime(currentCheckin.checkin_time) }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">状态:</span>
              <span class="info-value">{{ formatStatus(currentCheckin.status) }}</span>
            </div>
            <div class="info-item full-width">
              <span class="info-label">押金退还哈希:</span>
              <span class="info-value hash-full">{{ currentCheckin.deposit_refund_tx_hash || '-' }}</span>
            </div>
            <div class="info-item full-width">
              <span class="info-label">签到哈希:</span>
              <span class="info-value hash-full">{{ currentCheckin.checkin_hash || '-' }}</span>
            </div>
          </div>
          

        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-close" @click="showViewModal = false">关闭</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted, onUnmounted, computed } from 'vue'
import { getAllCheckIns, deleteCheckIn } from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 签到记录数据
const checkins = ref([])
const searchType = ref('seatId')
const searchKeyword = ref('')
const statusFilter = ref('')
const dateFilter = ref('')
const selectedCheckins = ref([])
const pollingInterval = ref(null)
const isLoading = ref(false)
const showViewModal = ref(false)
const currentCheckin = ref(null)

// 获取签到记录
const fetchCheckins = async () => {
  if (isLoading.value) return
  
  isLoading.value = true
  try {
    const response = await getAllCheckIns()
    // 转换后端数据格式以匹配前端期望的结构
    const formattedCheckins = response.map(checkin => ({
      id: checkin.id,
      user_id: checkin.userId,
      seat_id: checkin.seatNumber,
      reservation_id: checkin.reservationId,
      checkin_time: checkin.actualCheckInTime,
      status: checkin.status,
      checkin_hash: checkin.transactionHash
    }))
    checkins.value = formattedCheckins
  } catch (error) {
    console.error('获取签到记录失败:', error)
  } finally {
    isLoading.value = false
  }
}

// 筛选后的签到记录
const filteredCheckins = computed(() => {
  let result = [...checkins.value]
  
  if (searchKeyword.value) {
    const query = searchKeyword.value.toLowerCase()
    if (searchType.value === 'seatId') {
      result = result.filter(checkin => checkin.seat_id.toLowerCase().includes(query))
    } else if (searchType.value === 'reservationId') {
      result = result.filter(checkin => checkin.reservation_id.toString().includes(query))
    }
  }
  
  if (statusFilter.value) {
    result = result.filter(checkin => checkin.status === statusFilter.value)
  }
  
  if (dateFilter.value) {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    result = result.filter(checkin => {
      const checkinDate = new Date(checkin.checkin_time)
      checkinDate.setHours(0, 0, 0, 0)
      
      if (dateFilter.value === 'today') {
        return checkinDate.getTime() === today.getTime()
      } else if (dateFilter.value === 'week') {
        const weekAgo = new Date(today)
        weekAgo.setDate(weekAgo.getDate() - 7)
        return checkinDate >= weekAgo
      } else if (dateFilter.value === 'month') {
        const monthAgo = new Date(today)
        monthAgo.setMonth(monthAgo.getMonth() - 1)
        return checkinDate >= monthAgo
      }
      return true
    })
  }
  
  return result
})

const handleSearch = () => {
  // 搜索处理
}

const handleFilter = () => {
  // 筛选处理
}

// 全选/取消全选功能
const handleSelectAll = (event) => {
  if (event.target.checked) {
    selectedCheckins.value = filteredCheckins.value.map(checkin => checkin.id)
  } else {
    selectedCheckins.value = []
  }
}

// 查看签到详情
const handleViewCheckin = (checkinId) => {
  const checkin = checkins.value.find(c => c.id === checkinId)
  if (checkin) {
    currentCheckin.value = checkin
    showViewModal.value = true
  }
}

// 删除签到记录
const handleDeleteCheckIn = async (checkinId) => {
  if (confirm('确定要删除这条签到记录吗？')) {
    try {
      await deleteCheckIn(checkinId)
      // 删除成功后刷新列表
      fetchCheckins()
      // 提示成功信息
      alert('删除成功')
    } catch (error) {
      console.error('删除签到记录失败:', error)
      alert('删除失败，请重试')
    }
  }
}

const formatCheckinTime = (time) => {
  if (!time) return ''
  const date = new Date(time)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const formatStatus = (status) => {
  const statusMap = {
    'checked_in': '准时',
    'late': '迟到',
    'missed': '未签到'
  }
  return statusMap[status] || status
}

const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 启动轮询
const startPolling = () => {
  // 每5秒刷新一次数据
  pollingInterval.value = setInterval(fetchCheckins, 5000)
}

// 停止轮询
const stopPolling = () => {
  if (pollingInterval.value) {
    clearInterval(pollingInterval.value)
    pollingInterval.value = null
  }
}

onMounted(() => {
  fetchCheckins()
  startPolling()
})

onUnmounted(() => {
  stopPolling()
})
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 12px;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
  position: relative;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 8px 0;
  min-width: 150px;
  z-index: 1000;
}

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 10px 16px;
  background: none;
  border: none;
  text-align: left;
  cursor: pointer;
  font-size: 14px;
  color: #2c3e50;
  transition: background-color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #f8f9fa;
}

.checkins-management {
  padding: 30px;
}

.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-2px);
}

.hash-cell {
  font-family: monospace;
  font-size: 12px;
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #666;
}

.stat-icon {
  width: 50px;
  height: 50px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.stat-icon.total {
  background-color: #3498db;
}

.stat-icon.on-time {
  background-color: #2ecc71;
}

.stat-icon.late {
  background-color: #f39c12;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #7f8c8d;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #2c3e50;
}

.action-buttons {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  color: white;
}

.action-btn.export-checkins {
  background-color: #3498db;
}

.action-btn.export-checkins:hover {
  background-color: #2980b9;
}

.action-btn.batch-delete {
  background-color: #e74c3c;
}

.action-btn.batch-delete:hover {
  background-color: #c0392b;
}

.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  align-items: center;
}

.search-select {
  padding: 10px 15px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  background-color: white;
  cursor: pointer;
  transition: border-color 0.3s ease;
}

.search-select:focus {
  outline: none;
  border-color: #3498db;
}

.search-input {
  flex: 1;
  padding: 10px 15px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
}

.search-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.search-btn:hover {
  background-color: #2980b9;
}

.checkins-list {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  overflow-x: auto;
  overflow-y: hidden;
}

.checkins-list::-webkit-scrollbar {
  height: 8px;
}

.checkins-list::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

.checkins-list::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

.checkins-list::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

.checkins-table {
  min-width: 900px;
  border-collapse: collapse;
  table-layout: fixed;
}

.checkins-table th,
.checkins-table td {
  padding: 12px 16px;
  text-align: left;
  border-bottom: 1px solid #e0e0e0;
}

.checkins-table th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
  font-size: 14px;
  width: calc(100% / 9);
}

.checkins-table tbody tr:hover {
  background-color: #f8f9fa;
}

/* 添加选中行样式 */
.checkins-table tbody tr.selected {
  background-color: #e3f2fd;
}

/* 添加复选框样式 */
.select-all, .select-checkin {
  cursor: pointer;
}

.no-data {
  text-align: center;
  color: #95a5a6;
  padding: 40px !important;
}

.status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status.on_time {
  background-color: #d4edda;
  color: #155724;
}

.status.late {
  background-color: #fff3cd;
  color: #856404;
}

.btn-delete {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: none;
  color: #e74c3c;
}

.btn-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: none;
  color: #3498db;
  margin-right: 8px;
}

.btn-toggle:hover {
  background-color: #e3f2fd;
}

.btn-toggle.rotated svg {
  transform: rotate(180deg);
  transition: transform 0.3s ease;
}

.btn-toggle svg {
  transition: transform 0.3s ease;
}

.btn-view {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: none;
  color: #3498db;
  margin-right: 8px;
}

.btn-view:hover {
  background-color: #e3f2fd;
}

.btn-delete {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  background: none;
  color: #e74c3c;
}

.btn-delete:hover {
  background-color: #fee;
}

.expanded-row {
  background-color: #f8f9fa;
  border-top: 1px solid #e0e0e0;
}

.expanded-content {
  padding: 20px !important;
}

.checkin-details {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.checkin-details h4 {
  margin: 0 0 16px 0;
  font-size: 16px;
  font-weight: 600;
  color: #2c3e50;
}

.details-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 12px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.detail-label {
  font-size: 12px;
  color: #7f8c8d;
  font-weight: 500;
}

.detail-value {
  font-size: 14px;
  color: #2c3e50;
  font-weight: 500;
}

.hash-full {
  font-family: monospace;
  word-break: break-all;
  font-size: 12px;
  color: #666;
}



/* 响应式设计优化 */
@media (max-width: 768px) {
  .checkins-management {
    padding: 20px 15px;
  }
  
  .search-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-select {
    width: 100%;
  }
  
  .checkins-table {
    min-width: 800px;
  }
  
  .checkins-table th,
  .checkins-table td {
    padding: 10px 12px;
    font-size: 13px;
  }
  
  .hash-cell {
    max-width: 150px;
    font-size: 11px;
  }
}

@media (max-width: 480px) {
  .checkins-table {
    min-width: 700px;
  }
  
  .checkins-table th,
  .checkins-table td {
    padding: 8px 10px;
    font-size: 12px;
  }
  
  .hash-cell {
    max-width: 120px;
    font-size: 10px;
  }
}

/* 查看按钮样式 */


/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.modal-close {
  background: none;
  border: none;
  cursor: pointer;
  color: #666;
  padding: 4px;
  border-radius: 4px;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background-color: #f0f0f0;
  color: #333;
}

.modal-body {
  padding: 20px;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  padding: 16px 20px;
  border-top: 1px solid #e0e0e0;
}

.btn-close {
  background-color: #666;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-close:hover {
  background-color: #555;
}

/* 签到信息样式 */
.checkin-info {
  width: 100%;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;
  margin-bottom: 24px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.info-item.full-width {
  grid-column: 1 / -1;
}

.info-label {
  font-size: 14px;
  color: #666;
  font-weight: 500;
}

.info-value {
  font-size: 14px;
  color: #333;
  font-weight: 400;
}

.info-value.hash-full {
  font-family: 'Courier New', monospace;
  word-break: break-all;
  background-color: #f8f9fa;
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #e0e0e0;
}



.info-list {
  margin: 0;
  padding-left: 20px;
  font-size: 14px;
  color: #333;
}

.info-list li {
  margin-bottom: 6px;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    margin: 20px;
  }
  
  .info-grid {
    grid-template-columns: 1fr;
  }
  
  .info-list {
    text-align: left;
    display: inline-block;
  }
}
</style>



