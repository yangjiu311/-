<template>
  <div class="login-container">
    <!-- 区块链背景元素 -->
    <div class="blockchain-background">
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
      <div class="blockchain-line">
        <div class="block" v-for="i in 10" :key="i"></div>
      </div>
    </div>

    <!-- 顶部装饰区 -->
    <div class="top-decoration">
      <div class="decoration-box box-1"></div>
      <div class="decoration-box box-2"></div>
      <div class="decoration-box box-3"></div>
    </div>

    <div class="login-box">
      <!-- 标题和区块链图标 -->
      <div class="login-header">
        <div class="blockchain-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h1>区块链自习室系统</h1>
        <p>基于区块链技术的智能自习室管理</p>
      </div>

      <!-- 登录表单 -->
      <form @submit.prevent="login" class="login-form">
        <div class="form-group">
          <label for="userId">账号</label>
          <input 
            type="text" 
            id="userId" 
            v-model="form.userId" 
            required 
            placeholder="请输入学号或管理员账号"
          >
        </div>

        <div class="form-group">
          <label for="password">密码</label>
          <input 
            type="password" 
            id="password" 
            v-model="form.password" 
            required 
            placeholder="请输入密码"
          >
        </div>

        <div class="form-group">
          <label>角色</label>
          <div class="role-selection">
            <label class="role-option">
              <input 
                type="radio" 
                v-model="form.role" 
                value="student" 
                required
              >
              <span>学生</span>
            </label>
            <label class="role-option">
              <input 
                type="radio" 
                v-model="form.role" 
                value="admin" 
                required
              >
              <span>管理员</span>
            </label>
          </div>
        </div>

        <button type="submit" class="login-btn">
          登录
        </button>
      </form>

      <!-- 注册链接 -->
      <div class="register-link">
        <span>还没有账号？</span>
        <router-link to="/register">立即注册</router-link>
      </div>
    </div>

    <!-- 底部装饰区 -->
    <div class="bottom-decoration">
      <!-- 系统特色介绍 -->
      <div class="feature-section">
        <h2 class="section-title">系统特色</h2>
        <div class="features">
          <div class="feature-item">
            <div class="feature-icon">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="feature-content">
              <h3>区块链技术</h3>
              <p>采用先进的区块链技术，确保预约记录不可篡改，保障用户权益</p>
            </div>
          </div>
          <div class="feature-item">
            <div class="feature-icon">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="feature-content">
              <h3>智能预约</h3>
              <p>智能推荐最佳座位，支持提前预约，灵活调整时间，提高自习效率</p>
            </div>
          </div>
          <div class="feature-item">
            <div class="feature-icon">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
            <div class="feature-content">
              <h3>实时状态</h3>
              <p>实时查看自习室座位使用情况，避免无效等待，优化资源配置</p>
            </div>
          </div>
        </div>
      </div>

      <!-- 系统详情说明 -->
      <div class="system-info">
        <h2 class="section-title">系统详情</h2>
        <div class="info-content">
          <div class="info-item">
            <h3>系统简介</h3>
            <p>区块链自习室系统是一款基于区块链技术的智能自习室管理平台，旨在为学生提供便捷、公平、透明的自习室座位预约服务。系统采用分布式账本技术，确保所有预约记录的真实性和不可篡改性，有效解决了传统预约系统中存在的公平性问题。</p>
          </div>
          <div class="info-item">
            <h3>技术特点</h3>
            <ul>
              <li>基于区块链的分布式账本技术，确保数据安全</li>
              <li>智能合约自动执行预约规则，减少人为干预</li>
              <li>实时数据同步，提供准确的座位使用情况</li>
              <li>响应式设计，支持多设备访问</li>
              <li>完善的用户认证和权限管理机制</li>
            </ul>
          </div>
          <div class="info-item">
            <h3>使用说明</h3>
            <p>学生用户可以通过学号注册账号，登录后查看自习室座位情况，选择合适的座位进行预约。管理员用户可以管理自习室资源、查看预约记录、处理用户反馈等。系统支持预约时间调整、取消预约等功能，满足用户的个性化需求。</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import api from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const form = ref({
  userId: '',
  password: '',
  role: 'student'
})

// 登录方法
const login = async () => {
  try {
    // 调用后端登录接口
    const response = await api.post('/auth/login', form.value)
    
    // 登录成功，保存用户信息
    userStore.login(response.user, response.token)
    
    // 根据角色跳转到不同页面
    if (form.value.role === 'admin') {
      router.push('/admin')
    } else {
      router.push('/user')
    }
  } catch (error) {
    console.error('登录失败:', error)
    alert('登录失败，请检查账号密码和角色')
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  min-height: 100vh;
  max-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 20px 0;
  box-sizing: border-box;
}

/* 区块链背景动画 */
.blockchain-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.1;
  z-index: 0;
}

.blockchain-line {
  display: flex;
  justify-content: space-around;
  margin: 20px 0;
  animation: blockchainMove 20s linear infinite;
}

.blockchain-line:nth-child(2) {
  animation-delay: -7s;
}

.blockchain-line:nth-child(3) {
  animation-delay: -14s;
}

.blockchain-line:nth-child(4) {
  animation-delay: -3s;
}

.blockchain-line:nth-child(5) {
  animation-delay: -10s;
}

.blockchain-line:nth-child(6) {
  animation-delay: -17s;
}

.block {
  width: 20px;
  height: 20px;
  border: 2px solid #4CAF50;
  border-radius: 4px;
  background: rgba(76, 175, 80, 0.1);
}

@keyframes blockchainMove {
  0% {
    transform: translateY(-100px);
  }
  100% {
    transform: translateY(100vh);
  }
}

/* 顶部装饰区 */
.top-decoration {
  position: relative;
  width: 100%;
  max-width: 1200px;
  height: 100px;
  margin-bottom: 30px;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
}

.decoration-box {
  width: 80px;
  height: 80px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  animation: float 6s ease-in-out infinite;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.decoration-box.box-1 {
  animation-delay: 0s;
}

.decoration-box.box-2 {
  animation-delay: 2s;
}

.decoration-box.box-3 {
  animation-delay: 4s;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
}

.login-box {
  background: white;
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  width: 100%;
  max-width: 450px;
  position: relative;
  z-index: 1;
  margin-bottom: 40px;
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.blockchain-icon {
  margin-bottom: 15px;
}

.login-header h1 {
  font-size: 24px;
  color: #333;
  margin: 0;
}

.login-header p {
  color: #666;
  margin: 5px 0 0;
  font-size: 14px;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: center;
  width: 100%;
}

.form-group {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 15px;
  width: 100%;
  max-width: 380px;
  justify-content: center;
}

.form-group label {
  min-width: 60px;
  font-weight: 600;
  color: #333;
  font-size: 14px;
  text-align: left;
}

.form-group input {
  flex: 1;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  height: 44px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}

.form-group input:focus {
  outline: none;
  border-color: #4CAF50;
}

.role-selection {
  display: flex;
  gap: 20px;
}

.role-option {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 14px;
}

.login-btn {
  padding: 14px;
  background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  width: 100%;
  max-width: 380px;
}

.login-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(76, 175, 80, 0.3);
}

.register-link {
  text-align: center;
  margin-top: 20px;
  font-size: 14px;
}

.register-link a {
  color: #4CAF50;
  text-decoration: none;
  font-weight: 600;
}

.register-link a:hover {
  text-decoration: underline;
}

/* 底部装饰区 */
.bottom-decoration {
  position: relative;
  width: 100%;
  max-width: 1200px;
  padding: 40px 20px;
  display: flex;
  flex-direction: column;
  gap: 40px;
  z-index: 1;
}

/* 系统特色介绍 */
.feature-section {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
  padding: 30px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.section-title {
  color: white;
  font-size: 24px;
  text-align: center;
  margin-bottom: 30px;
  font-weight: 600;
}

.features {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.feature-item {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  background: rgba(255, 255, 255, 0.1);
  padding: 20px;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: transform 0.3s, box-shadow 0.3s;
}

.feature-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.feature-icon {
  width: 60px;
  height: 60px;
  background: rgba(76, 175, 80, 0.2);
  border-radius: 12px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
  border: 1px solid rgba(76, 175, 80, 0.4);
}

.feature-content h3 {
  color: white;
  font-size: 18px;
  margin: 0 0 10px 0;
  font-weight: 600;
}

.feature-content p {
  color: rgba(255, 255, 255, 0.9);
  margin: 0;
  font-size: 14px;
  line-height: 1.6;
}

/* 系统详情说明 */
.system-info {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 16px;
  padding: 30px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.info-content {
  display: flex;
  flex-direction: column;
  gap: 25px;
}

.info-item h3 {
  color: white;
  font-size: 18px;
  margin: 0 0 15px 0;
  font-weight: 600;
}

.info-item p {
  color: rgba(255, 255, 255, 0.9);
  margin: 0;
  font-size: 14px;
  line-height: 1.8;
}

.info-item ul {
  color: rgba(255, 255, 255, 0.9);
  margin: 0;
  padding-left: 20px;
  font-size: 14px;
  line-height: 1.8;
}

.info-item li {
  margin-bottom: 10px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .top-decoration {
    height: 80px;
    gap: 15px;
  }
  
  .decoration-box {
    width: 60px;
    height: 60px;
  }
  
  .login-box {
    padding: 20px;
    margin: 0 20px 30px;
  }
  
  .feature-item {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .bottom-decoration {
    padding: 20px;
  }
  
  .feature-section,
  .system-info {
    padding: 20px;
  }
}
</style>