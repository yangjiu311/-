package com.example.studyroom.service;

import com.example.studyroom.model.Row;

import java.util.List;
import java.util.Optional;

public interface RowService {
    List<Row> getAllRows();
    Optional<Row> getRowById(Long id);
    Optional<Row> getRowByRowNumber(Integer rowNumber);
    Row saveRow(Row row);
    void deleteRow(Long id);
    boolean existsByRowNumber(Integer rowNumber);
}