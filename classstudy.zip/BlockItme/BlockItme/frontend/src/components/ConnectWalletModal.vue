<template>
  <div class="modal-overlay" v-if="visible" @click="close">
    <div class="modal-content" @click.stop>
      <div class="modal-header">
        <h3>连接钱包</h3>
        <button class="close-btn" @click="close">×</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="walletAddress">钱包地址</label>
          <input 
            type="text" 
            id="walletAddress" 
            v-model="walletAddress" 
            placeholder="请输入以太坊钱包地址"
            class="form-control"
          >
        </div>
        <div class="wallet-info" v-if="currentBalance || networkInfo">
          <p class="balance-info">当前余额: {{ currentBalance || '查询中...' }} ETH</p>
          <p class="network-info" v-if="networkInfo">当前网络: {{ networkInfo }}</p>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn secondary-btn" @click="close">取消</button>
        <button class="btn primary-btn" @click="connect" :disabled="!walletAddress || isConnecting">
          {{ isConnecting ? '连接中...' : '连接' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useUserStore } from '../stores/user'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  defaultAddress: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['close', 'connect'])

const userStore = useUserStore()
const walletAddress = ref(props.defaultAddress || userStore.walletAddress || '')
const isConnecting = ref(false)
const currentBalance = ref('')
const networkInfo = ref('')

// 监听默认地址变化
watch(() => props.defaultAddress, (newVal) => {
  walletAddress.value = newVal
})

// 监听钱包地址变化
watch(() => userStore.walletAddress, (newVal) => {
  if (newVal) {
    walletAddress.value = newVal
  }
})

// 关闭对话框
const close = () => {
  emit('close')
}

// 查询钱包信息
const queryWalletInfo = async () => {
  if (!walletAddress.value) return
  
  try {
    // 确保web3已初始化
    if (!userStore.web3) {
      await userStore.initWeb3()
    }
    
    // 获取网络信息
    const networkId = await userStore.web3.eth.net.getId()
    networkInfo.value = `ID: ${networkId}`
    console.log('当前网络ID:', networkId)
    
    // 直接使用Ganache查询余额，不依赖MetaMask网络
    const balance = await userStore.web3.eth.getBalance(walletAddress.value)
    currentBalance.value = userStore.web3.utils.fromWei(balance, 'ether')
    console.log('查询到的余额:', currentBalance.value, 'ETH')
  } catch (error) {
    console.error('查询钱包信息失败:', error)
    currentBalance.value = '查询失败'
  }
}

// 监听钱包地址变化，自动查询信息
watch(() => walletAddress.value, (newVal) => {
  if (newVal) {
    queryWalletInfo()
  }
})

// 监听对话框显示状态，自动查询信息
watch(() => props.visible, (newVal) => {
  if (newVal && walletAddress.value) {
    queryWalletInfo()
  }
})

// 连接钱包
const connect = async () => {
  if (!walletAddress.value) return
  
  isConnecting.value = true
  
  try {
    // 确保web3已初始化
    if (!userStore.web3) {
      await userStore.initWeb3()
    }
    
    // 查询钱包信息
    await queryWalletInfo()
    
    // 更新用户存储
    userStore.walletAddress = walletAddress.value
    localStorage.setItem('walletAddress', walletAddress.value)
    
    emit('connect', walletAddress.value)
    close()
  } catch (error) {
    console.error('连接钱包失败:', error)
    alert('连接钱包失败: ' + error.message)
  } finally {
    isConnecting.value = false
  }
}
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  padding: 20px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  color: #333;
  font-size: 18px;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #999;
  padding: 0;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
}

.close-btn:hover {
  background-color: #f5f5f5;
  color: #333;
}

.modal-body {
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  color: #333;
}

.form-control {
  width: 100%;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  transition: border-color 0.3s;
}

.form-control:focus {
  outline: none;
  border-color: #4CAF50;
}

.wallet-info {
  margin-top: 15px;
  padding: 10px;
  background-color: #f8f9fa;
  border-radius: 4px;
}

.balance-info {
  margin: 0;
  color: #666;
  font-size: 14px;
}

.network-info {
  margin: 5px 0 0 0;
  color: #4CAF50;
  font-size: 12px;
}

.modal-footer {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.btn {
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s;
  border: none;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover:not(:disabled) {
  background-color: #45a049;
  transform: translateY(-1px);
}

.primary-btn:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.secondary-btn {
  background-color: white;
  color: #4CAF50;
  border: 1px solid #4CAF50;
}

.secondary-btn:hover {
  background-color: #f1f8e9;
}
</style>
