package com.example.studyroom.repository;

import com.example.studyroom.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    @Query("SELECT u FROM User u WHERE u.deleted = false")
    List<User> findAllActiveUsers();
    
    Optional<User> findByUserIdAndDeleted(String userId, Boolean deleted);
    Optional<User> findByWalletAddressAndDeleted(String walletAddress, Boolean deleted);
    Optional<User> findByEmailAndDeleted(String email, Boolean deleted);
    Optional<User> findByPhoneAndDeleted(String phone, Boolean deleted);
    Optional<User> findByStudentIdAndDeleted(String studentId, Boolean deleted);
    
    boolean existsByUserIdAndDeleted(String userId, Boolean deleted);
    boolean existsByWalletAddressAndDeleted(String walletAddress, Boolean deleted);
    boolean existsByEmailAndDeleted(String email, Boolean deleted);
    boolean existsByPhoneAndDeleted(String phone, Boolean deleted);
    boolean existsByStudentIdAndDeleted(String studentId, Boolean deleted);
    
    // 添加获取学生用户数的方法
    @Query("SELECT COUNT(u) FROM User u WHERE u.role = :role AND u.deleted = false")
    long countByRoleAndDeleted(@Param("role") User.Role role);
}