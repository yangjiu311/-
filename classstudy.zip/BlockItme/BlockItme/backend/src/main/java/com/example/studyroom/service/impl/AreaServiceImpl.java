package com.example.studyroom.service.impl;

import com.example.studyroom.model.Area;
import com.example.studyroom.repository.AreaRepository;
import com.example.studyroom.service.AreaService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class AreaServiceImpl implements AreaService {
    private final AreaRepository areaRepository;

    @Override
    public List<Area> getAllAreas() {
        return areaRepository.findAll();
    }

    @Override
    public Optional<Area> getAreaById(@NonNull Long id) {
        return areaRepository.findById(id);
    }

    @Override
    public Area createArea(@NonNull Area area) {
        return areaRepository.save(area);
    }

    @Override
    public Area updateArea(@NonNull Long id, @NonNull Area area) {
        Optional<Area> existingArea = areaRepository.findById(id);
        if (existingArea.isPresent()) {
            Area updatedArea = existingArea.get();
            updatedArea.setClassroomName(area.getClassroomName());
            return areaRepository.save(updatedArea);
        }
        throw new RuntimeException("Area not found with id: " + id);
    }

    @Override
    public void deleteArea(@NonNull Long id) {
        areaRepository.deleteById(id);
    }

    @Override
    public boolean existsByClassroomName(@NonNull String classroomName) {
        return areaRepository.existsByClassroomName(classroomName);
    }
}

