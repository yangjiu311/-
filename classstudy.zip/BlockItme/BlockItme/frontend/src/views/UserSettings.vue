<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>个人设置</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 设置内容区域 -->
      <section class="settings-section">
        <!-- 通用设置 -->
        <div class="settings-card">
          <h2>通用设置</h2>
          <form class="settings-form">
            <div class="form-row">
              <div class="form-group">
                <label for="language">语言</label>
                <select id="language" class="form-control">
                  <option value="zh-CN">简体中文</option>
                  <option value="en-US">English</option>
                </select>
              </div>
              <div class="form-group">
                <label for="theme">主题</label>
                <select id="theme" class="form-control">
                  <option value="light">浅色主题</option>
                  <option value="dark">深色主题</option>
                  <option value="auto">跟随系统</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label for="timezone">时区</label>
                <select id="timezone" class="form-control">
                  <option value="Asia/Shanghai">亚洲/上海 (UTC+8)</option>
                  <option value="Asia/Beijing">亚洲/北京 (UTC+8)</option>
                  <option value="Asia/Hong_Kong">亚洲/香港 (UTC+8)</option>
                </select>
              </div>
              <div class="form-group">
                <label for="date-format">日期格式</label>
                <select id="date-format" class="form-control">
                  <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                  <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                  <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                </select>
              </div>
            </div>
          </form>
        </div>

        <!-- 通知设置 -->
        <div class="settings-card">
          <h2>通知设置</h2>
          <form class="settings-form">
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="email-notification" class="checkbox-input" checked />
                  <label for="email-notification" class="checkbox-label">
                    <span>邮箱通知</span>
                    <span class="checkbox-description">接收预约确认、提醒和取消通知</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="sms-notification" class="checkbox-input" />
                  <label for="sms-notification" class="checkbox-label">
                    <span>短信通知</span>
                    <span class="checkbox-description">接收预约确认和提醒短信</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="app-notification" class="checkbox-input" checked />
                  <label for="app-notification" class="checkbox-label">
                    <span>应用内通知</span>
                    <span class="checkbox-description">接收系统通知和提醒</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label for="reminder-time">预约提醒时间</label>
                <select id="reminder-time" class="form-control">
                  <option value="30">预约前30分钟</option>
                  <option value="60">预约前1小时</option>
                  <option value="120">预约前2小时</option>
                  <option value="240">预约前4小时</option>
                </select>
              </div>
              <div class="form-group">
                <label for="daily-notification">每日通知时间</label>
                <input type="time" id="daily-notification" class="form-control" value="08:00" />
              </div>
            </div>
          </form>
        </div>

        <!-- 隐私设置 -->
        <div class="settings-card">
          <h2>隐私设置</h2>
          <form class="settings-form">
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="profile-visibility" class="checkbox-input" checked />
                  <label for="profile-visibility" class="checkbox-label">
                    <span>公开个人资料</span>
                    <span class="checkbox-description">允许其他用户查看您的基本信息</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="reservation-visibility" class="checkbox-input" />
                  <label for="reservation-visibility" class="checkbox-label">
                    <span>公开预约记录</span>
                    <span class="checkbox-description">允许其他用户查看您的预约历史</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group full-width">
                <div class="checkbox-group">
                  <input type="checkbox" id="data-collection" class="checkbox-input" checked />
                  <label for="data-collection" class="checkbox-label">
                    <span>数据收集</span>
                    <span class="checkbox-description">允许系统收集使用数据以改进服务</span>
                  </label>
                </div>
              </div>
            </div>
          </form>
        </div>

        <!-- 操作按钮 -->
        <div class="settings-card">
          <div class="settings-actions">
            <button class="primary-btn save-btn" @click="saveSettings">保存设置</button>
            <button class="secondary-btn reset-btn" @click="resetSettings">重置为默认</button>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref } from 'vue'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 保存设置
const saveSettings = () => {
  console.log('保存设置')
  // 实际应用中应该发送设置到后端
  alert('设置已保存')
}

// 重置设置
const resetSettings = () => {
  if (confirm('确定要将所有设置重置为默认值吗？')) {
    console.log('重置设置')
    // 实际应用中应该重置表单为默认值
    alert('设置已重置为默认值')
  }
}
</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

/* 设置内容区域样式 */
.settings-section {
  padding: 20px 30px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.settings-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.settings-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.settings-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.form-row {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.form-group {
  flex: 1;
  min-width: 250px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  color: #495057;
  font-size: 14px;
}

.form-control {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  font-size: 14px;
  color: #495057;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  border-color: #4CAF50;
  outline: none;
  box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25);
}

.full-width {
  flex: 1 0 100% !important;
}

/* 复选框样式 */
.checkbox-group {
  display: flex;
  align-items: flex-start;
  gap: 10px;
}

.checkbox-input {
  margin-top: 4px;
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.checkbox-label {
  display: flex;
  flex-direction: column;
  gap: 2px;
  cursor: pointer;
  font-size: 14px;
  color: #495057;
}

.checkbox-label span:first-child {
  font-weight: 600;
}

.checkbox-description {
  font-size: 12px;
  color: #6c757d;
  font-weight: normal !important;
}

/* 操作按钮样式 */
.settings-actions {
  display: flex;
  gap: 20px;
  justify-content: flex-end;
}

.primary-btn,
.secondary-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
  border: none;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.secondary-btn {
  background-color: white;
  color: #4CAF50;
  border: 1px solid #4CAF50;
}

.secondary-btn:hover {
  background-color: #f1f8e9;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.2);
}

/* 用户信息和下拉菜单样式 */
.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.dropdown-item {
  width: 100%;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
  background-color: transparent;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
  text-align: left;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

.dropdown-item:first-child {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.dropdown-item:last-child {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.dropdown-item svg {
  color: #666;
}

.dropdown-item:hover svg {
  color: #4CAF50;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: auto;
  }

  .nav-menu {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    padding: 0;
  }

  .nav-item {
    flex: 0 0 auto;
  }

  .form-row {
    flex-direction: column;
  }

  .form-group {
    width: 100%;
  }

  .settings-actions {
    flex-direction: column;
  }

  .primary-btn,
  .secondary-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>