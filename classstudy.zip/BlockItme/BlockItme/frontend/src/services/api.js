import axios from 'axios'

// 创建axios实例
const api = axios.create({
  baseURL: '/api', // 恢复/api前缀，因为Vite代理需要这个前缀来转发请求
  timeout: 10000, // 请求超时时间
  headers: {
    'Content-Type': 'application/json'
  }
})

  // 请求拦截器
api.interceptors.request.use(
  config => {
    // 从本地存储获取token
    const token = localStorage.getItem('token')
    // 不再添加认证头，因为后端已禁用认证
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    console.log('API Response:', response)
    // 处理204 No Content响应，返回空对象而不是undefined
    if (response.status === 204) {
      return {}
    }
    return response.data
  },
  error => {
    // 处理响应错误
    console.log('API Error Details:', error)
    if (error.response) {
      // 服务器返回了错误状态码
      // 不打印409状态码的错误日志，因为这是预期的业务逻辑错误（如重复行/列号）
      if (error.response.status !== 409) {
        console.error('API Error:', error.response.data)
        console.error('API Error Status:', error.response.status)
      }
      // 如果是401未授权，可能需要重新登录
      if (error.response.status === 401) {
        // 可以在这里处理登录过期的逻辑
        localStorage.removeItem('token')
        localStorage.removeItem('userInfo')
        window.location.href = '/login'
      }
    } else if (error.request) {
      // 请求已发送但没有收到响应
      console.error('API Request Error:', error.request)
    } else {
      // 请求配置错误
      console.error('API Config Error:', error.message)
    }
    return Promise.reject(error)
  }
)

export default api

export const getAvailableSeatsCount = () => {
  return api.get('/seats/count/status/available');
};

export const getTotalSeatsCount = () => {
  return api.get('/seats/count/total');
};

export const getReservedSeatsCount = () => {
  return api.get('/seats/count/status/reserved');
};

export const getUsedSeatsCount = () => {
  return api.get('/seats/count/status/used');
};

export const getSeatsStatusDistribution = async () => {
  try {
    const [available, reserved, used] = await Promise.all([
      api.get('/seats/count/status/available'),
      api.get('/seats/count/status/reserved'),
      api.get('/seats/count/status/used')
    ]);
    return {
      available,
      reserved,
      used
    };
  } catch (error) {
    console.error('获取座位状态分布失败:', error);
    return {
      available: 0,
      reserved: 0,
      used: 0
    };
  }
};

export const getStudentUsersCount = () => {
  return api.get('/users/count/role/student');
};

// 获取最近预约记录
export const getRecentReservations = () => {
  return api.get('/reservations/recent');
};

// 获取所有预约记录
export const getAllReservations = () => {
  return api.get('/reservations');
};

// 获取所有座位信息
export const getAllSeats = () => {
  return api.get('/seats');
};

// 获取座位的预约信息
export const getReservationsBySeatId = (seatId) => {
  return api.get(`/reservations/seat/${seatId}`);
};

// 添加座位
export const addSeat = (seatData) => {
  return api.post('/seats', seatData);
};

// 获取所有区域
export const getAllAreas = () => {
  return api.get('/areas');
};

// 添加区域
export const addArea = (areaData) => {
  return api.post('/areas', areaData);
};

// 更新区域
export const updateArea = (id, areaData) => {
  return api.put(`/areas/${id}`, areaData);
};

// 删除区域
export const deleteArea = (id) => {
  return api.delete(`/areas/${id}`);
};

// 获取所有行
export const getAllRows = () => {
  return api.get('/rows');
};

// 获取单行
export const getRowByNumber = (rowNumber) => {
  return api.get(`/rows/number/${rowNumber}`);
};

// 添加行
export const addRow = (rowData) => {
  return api.post('/rows', rowData);
};

// 获取所有列
export const getAllColumns = () => {
  return api.get('/columns');
};

// 获取单列
export const getColumnByNumber = (columnNumber) => {
  return api.get(`/columns/number/${columnNumber}`);
};

// 添加列
export const addColumn = (columnData) => {
  return api.post('/columns', columnData);
};

// 删除行
export const deleteRow = (id) => {
  return api.delete(`/rows/${id}`);
};

// 删除列
export const deleteColumn = (id) => {
  return api.delete(`/columns/${id}`);
};

// 删除座位
export const deleteSeat = (id) => {
  return api.delete(`/seats/${id}`);
};

// 更新座位
export const updateSeat = (id, seatData) => {
  return api.put(`/seats/${id}`, seatData);
};

// 获取所有用户
export const getAllUsers = () => {
  return api.get('/users');
};

// 删除用户
export const deleteUser = (id) => {
  return api.delete(`/users/${id}`);
};

// 检查座位是否可用
export const checkSeatAvailability = (seatId, startTime, endTime) => {
  return api.get('/reservations/is-available', {
    params: {
      seatId,
      startTime,
      endTime
    }
  });
};

// 创建预约
export const createReservation = (reservationData) => {
  return api.post('/reservations', reservationData);
};

// 获取用户预约记录
export const getUserReservations = (userId) => {
  return api.get(`/reservations/user/${userId}`);
};

// 获取用户最近预约记录
export const getUserRecentReservations = (userId) => {
  return api.get(`/reservations/user/${userId}/recent`);
};

// 取消预约
export const cancelReservation = (reservationId) => {
  return api.put(`/reservations/${reservationId}/cancel`);
};

// 删除预约
export const deleteReservation = (reservationId) => {
  return api.delete(`/reservations/${reservationId}`);
};

// 签到预约
export const checkInReservation = (reservationId, depositRefundTxHash) => {
  return api.put(`/reservations/${reservationId}/check-in`, { depositRefundTxHash });
};

// 获取用户签到记录
export const getUserCheckIns = (params) => {
  return api.get('/checkins/user', { params });
};

// 获取当前用户信息
export const getCurrentUser = (userId) => {
  return api.get(`/users/user-id/${userId}`);
};

// 更新用户信息（使用PATCH方法进行部分更新）
export const updateUser = (id, userData) => {
  return api.patch(`/users/${id}`, userData);
};

// 删除签到记录（硬删除）
export const deleteCheckIn = (checkInId) => {
  return api.delete(`/check-ins/${checkInId}`);
};

// 获取所有签到记录（管理员用）
export const getAllCheckIns = () => {
  return api.get('/check-ins');
};

// 根据ID获取签到记录
export const getCheckInById = (id) => {
  return api.get(`/check-ins/${id}`);
};

// 根据状态获取签到记录
export const getCheckInsByStatus = (status) => {
  return api.get(`/check-ins/status/${status}`);
};

// 批量删除签到记录
export const batchDeleteCheckIns = (ids) => {
  return Promise.all(ids.map(id => deleteCheckIn(id)));
};

// 获取用户违约记录
export const getUserViolations = (userId) => {
  return api.get(`/violations/user/${userId}`);
};



// 获取所有预约详情（包含签到信息）
export const getAllReservationDetails = () => {
  return api.get('/reservations/details');
};



// 获取所有违约记录（管理员用）
export const getAllViolations = () => {
  return api.get('/violations');
};

// 删除违约记录
export const deleteViolation = (violationId) => {
  return api.delete(`/violations/${violationId}`);
};

// 更新违约记录状态
export const updateViolationStatus = (violationId, violationData) => {
  return api.put(`/violations/${violationId}`, violationData);
};

// 提取违约押金
export const withdrawViolationDeposit = (violationId, data) => {
  return api.post(`/violations/${violationId}/withdraw-deposit`, data);
};

// 获取违约金额统计信息
export const getViolationAmountStats = () => {
  return api.get('/deposit/violation-amount');
};

// 获取合约余额
export const getContractBalance = () => {
  return api.get('/deposit/contract-balance');
};

// 获取用户申诉记录
export const getUserAppeals = (userId) => {
  return api.get(`/appeals/user/${userId}`);
};

// 获取所有申诉记录（管理员用）
export const getAllAppeals = () => {
  return api.get('/appeals');
};

// 创建申诉
export const createAppeal = (appealData) => {
  return api.post('/appeals', appealData);
};

