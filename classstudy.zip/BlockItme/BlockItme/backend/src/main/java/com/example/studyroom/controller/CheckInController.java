package com.example.studyroom.controller;

import com.example.studyroom.model.CheckIn;
import com.example.studyroom.service.CheckInService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/check-ins")
@AllArgsConstructor
public class CheckInController {
    private final CheckInService checkInService;

    @GetMapping
    public ResponseEntity<List<CheckIn>> getAllCheckIns() {
        List<CheckIn> checkIns = checkInService.getAllCheckIns();
        return new ResponseEntity<>(checkIns, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CheckIn> getCheckInById(@PathVariable Long id) {
        Optional<CheckIn> checkIn = checkInService.getCheckInById(id);
        return checkIn.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/reservation/{reservationId}")
    public ResponseEntity<CheckIn> getCheckInByReservationId(@PathVariable Long reservationId) {
        Optional<CheckIn> checkIn = checkInService.getCheckInByReservationId(reservationId);
        return checkIn.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<CheckIn>> getCheckInsByUserId(@PathVariable String userId) {
        List<CheckIn> checkIns = checkInService.getCheckInsByUserId(userId);
        return new ResponseEntity<>(checkIns, HttpStatus.OK);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<CheckIn>> getCheckInsByStatus(@PathVariable CheckIn.Status status) {
        List<CheckIn> checkIns = checkInService.getCheckInsByStatus(status);
        return new ResponseEntity<>(checkIns, HttpStatus.OK);
    }

    @GetMapping("/user/{userId}/status/{status}")
    public ResponseEntity<List<CheckIn>> getCheckInsByUserIdAndStatus(
            @PathVariable String userId,
            @PathVariable CheckIn.Status status) {
        List<CheckIn> checkIns = checkInService.getCheckInsByUserIdAndStatus(userId, status);
        return new ResponseEntity<>(checkIns, HttpStatus.OK);
    }

    @GetMapping("/transaction/{transactionHash}")
    public ResponseEntity<CheckIn> getCheckInByTransactionHash(@PathVariable String transactionHash) {
        Optional<CheckIn> checkIn = checkInService.getCheckInByTransactionHash(transactionHash);
        return checkIn.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<CheckIn> createCheckIn(@RequestBody CheckIn checkIn) {
        CheckIn createdCheckIn = checkInService.createCheckIn(checkIn);
        return new ResponseEntity<>(createdCheckIn, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CheckIn> updateCheckIn(@PathVariable Long id, @RequestBody CheckIn checkIn) {
        try {
            CheckIn updatedCheckIn = checkInService.updateCheckIn(id, checkIn);
            return new ResponseEntity<>(updatedCheckIn, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCheckIn(@PathVariable Long id) {
        checkInService.deleteCheckIn(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/reservation/{reservationId}")
    public ResponseEntity<Boolean> existsByReservationId(@PathVariable Long reservationId) {
        boolean exists = checkInService.existsByReservationId(reservationId);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }

    @GetMapping("/user/{userId}/display")
    public ResponseEntity<List<CheckIn>> getCheckInsByUserIdAndDisplay(
            @PathVariable String userId,
            @RequestParam String display) {
        CheckIn.DisplayStatus displayStatus = CheckIn.DisplayStatus.fromValue(display);
        List<CheckIn> checkIns = checkInService.getCheckInsByUserIdAndDisplay(userId, displayStatus);
        return new ResponseEntity<>(checkIns, HttpStatus.OK);
    }

    @PutMapping("/{id}/display")
    public ResponseEntity<CheckIn> updateDisplayStatus(@PathVariable Long id, @RequestBody String displayValue) {
        try {
            CheckIn.DisplayStatus display = CheckIn.DisplayStatus.fromValue(displayValue);
            CheckIn updatedCheckIn = checkInService.updateDisplayStatus(id, display);
            return new ResponseEntity<>(updatedCheckIn, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}