package com.example.studyroom.service.impl;

import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.model.CheckIn;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.Seat;
import com.example.studyroom.repository.CheckInRepository;
import com.example.studyroom.repository.ReservationRepository;
import com.example.studyroom.repository.SeatRepository;
import com.example.studyroom.service.BlockchainService;
import com.example.studyroom.service.CheckInService;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CheckInServiceImpl implements CheckInService {
    private final CheckInRepository checkInRepository;
    private final ReservationRepository reservationRepository;
    private final BlockchainService blockchainService;
    private final SeatRepository seatRepository;

    @Override
    public List<CheckIn> getAllCheckIns() {
        return checkInRepository.findAll();
    }

    @Override
    public Optional<CheckIn> getCheckInById(@NonNull Long id) {
        return checkInRepository.findById(id);
    }

    @Override
    public Optional<CheckIn> getCheckInByReservationId(@NonNull Long reservationId) {
        return checkInRepository.findByReservationId(reservationId);
    }

    @Override
    public List<CheckIn> getCheckInsByUserId(@NonNull String userId) {
        return checkInRepository.findByUserId(userId);
    }

    @Override
    public List<CheckIn> getCheckInsByStatus(@NonNull CheckIn.Status status) {
        return checkInRepository.findByStatus(status);
    }

    @Override
    public List<CheckIn> getCheckInsByUserIdAndStatus(@NonNull String userId, @NonNull CheckIn.Status status) {
        return checkInRepository.findByUserIdAndStatus(userId, status);
    }

    @Override
    public Optional<CheckIn> getCheckInByTransactionHash(@NonNull String transactionHash) {
        return checkInRepository.findByTransactionHash(transactionHash);
    }

    @Override
    public CheckIn createCheckIn(@NonNull CheckIn checkIn) {
        // 检查是否已经存在相同reservationId的签到记录
        if (checkIn.getReservationId() != null) {
            Optional<CheckIn> existingCheckIn = checkInRepository.findByReservationId(checkIn.getReservationId());
            if (existingCheckIn.isPresent()) {
                // 如果已经存在签到记录，返回已有的记录
                return existingCheckIn.get();
            }
        }
        
        // 设置必填字段
        if (checkIn.getActualCheckInTime() == null) {
            checkIn.setActualCheckInTime(LocalDateTime.now());
        }
        if (checkIn.getCreatedAt() == null) {
            checkIn.setCreatedAt(LocalDateTime.now());
        }
        if (checkIn.getStatus() == null) {
            checkIn.setStatus(CheckIn.Status.checked_in);
        }
        if (checkIn.getDisplay() == null) {
            checkIn.setDisplay(CheckIn.DisplayStatus.TRUE);
        }
        if (checkIn.getCheckInId() == null) {
            checkIn.setCheckInId("checkin_" + System.currentTimeMillis() + "_" + checkIn.getUserId());
        }
        
        // 如果区域号和座位号为空，则从预约记录中获取
        if ((checkIn.getClassroomName() == null || checkIn.getSeatNumber() == null || checkIn.getReservationStartTime() == null || checkIn.getReservationEndTime() == null) && checkIn.getReservationId() != null) {
            Optional<Reservation> optionalReservation = reservationRepository.findById(checkIn.getReservationId());
            if (optionalReservation.isPresent()) {
                Reservation reservation = optionalReservation.get();
                if (checkIn.getClassroomName() == null) {
                    checkIn.setClassroomName(reservation.getClassroomName());
                }
                if (checkIn.getSeatNumber() == null) {
                    checkIn.setSeatNumber(reservation.getSeatNumber());
                }
                if (checkIn.getReservationStartTime() == null) {
                    checkIn.setReservationStartTime(reservation.getStartTime());
                }
                if (checkIn.getReservationEndTime() == null) {
                    checkIn.setReservationEndTime(reservation.getEndTime());
                }
            }
        }
        
        // 如果交易哈希和区块高度为空，则上传到区块链
        if (checkIn.getTransactionHash() == null || checkIn.getBlockHeight() == null) {
            try {
                BlockchainLog blockchainLog = blockchainService.uploadToBlockchain(
                        checkIn,
                        checkIn.getUserId(),
                        checkIn.getStuAdminId(),
                        checkIn.getReservationId(), // 使用reservationId作为targetId
                        BlockchainLog.OperationType.check_in
                );
                if (blockchainLog != null && blockchainLog.getStatus() == BlockchainLog.Status.success && blockchainLog.getTransactionHash() != null) {
                    // 设置区块链交易哈希和区块高度
                    checkIn.setTransactionHash(blockchainLog.getTransactionHash());
                    checkIn.setBlockHeight(blockchainLog.getBlockHeight());
                } else {
                    // Blockchain upload failed but we continue with check-in
                    System.out.println("Warning: Blockchain upload failed for check-in, but check-in was processed successfully");
                    checkIn.setTransactionHash("local_checkin_" + System.currentTimeMillis());
                    checkIn.setBlockHeight(null);
                }
            } catch (Exception e) {
                // Handle blockchain errors gracefully - don't fail the check-in
                System.out.println("Warning: Blockchain service error for check-in: " + e.getMessage());
                checkIn.setTransactionHash("error_checkin_" + System.currentTimeMillis());
                checkIn.setBlockHeight(null);
            }
        }
        
        // 保存签到记录到数据库
        return checkInRepository.save(checkIn);
    }

    @Override
    public CheckIn updateCheckIn(@NonNull Long id, @NonNull CheckIn checkIn) {
        Optional<CheckIn> existingCheckIn = checkInRepository.findById(id);
        if (existingCheckIn.isPresent()) {
            checkIn.setId(id);
            return checkInRepository.save(checkIn);
        } else {
            throw new RuntimeException("CheckIn not found with id: " + id);
        }
    }

    @Override
    public void deleteCheckIn(@NonNull Long id) {
        checkInRepository.deleteById(id);
    }

    @Override
    public boolean existsByReservationId(@NonNull Long reservationId) {
        return checkInRepository.existsByReservationId(reservationId);
    }

    @Override
    public CheckIn updateDisplayStatus(@NonNull Long id, @NonNull CheckIn.DisplayStatus display) {
        Optional<CheckIn> existingCheckIn = checkInRepository.findById(id);
        if (existingCheckIn.isPresent()) {
            CheckIn checkIn = existingCheckIn.get();
            checkIn.setDisplay(display);
            
            // 如果将display设置为FALSE，则更新对应座位的状态为available
            if (display == CheckIn.DisplayStatus.FALSE && checkIn.getSeatNumber() != null) {
                Optional<Seat> seat = seatRepository.findBySeatNumber(checkIn.getSeatNumber());
                if (seat.isPresent()) {
                    Seat seatEntity = seat.get();
                    seatEntity.setStatus(Seat.Status.available);
                    seatRepository.save(seatEntity);
                }
            }
            
            return checkInRepository.save(checkIn);
        } else {
            throw new RuntimeException("CheckIn not found with id: " + id);
        }
    }

    @Override
    public List<CheckIn> getCheckInsByUserIdAndDisplay(@NonNull String userId, @NonNull CheckIn.DisplayStatus display) {
        return checkInRepository.findByUserIdAndDisplay(userId, display);
    }

    @Override
    public void deleteCheckInByReservationId(@NonNull Long reservationId) {
        Optional<CheckIn> checkIn = checkInRepository.findByReservationId(reservationId);
        if (checkIn.isPresent()) {
            checkInRepository.delete(checkIn.get());
        }
    }
}
