// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract CheckIn {
    enum CheckInStatus {
        PENDING,
        COMPLETED,
        CANCELLED
    }

    struct CheckInRecord {
        string checkInId;
        string userId;
        string seatNumber;
        string areaName;
        uint256 checkInTime;
        uint256 checkOutTime;
        CheckInStatus status;
    }

    mapping(string => CheckInRecord) private checkInRecords;
    string[] private checkInIds;

    event CheckInCreated(
        string indexed checkInId,
        string userId,
        string seatNumber,
        string areaName,
        uint256 checkInTime
    );

    event CheckOutUpdated(
        string indexed checkInId,
        uint256 checkOutTime,
        CheckInStatus status
    );

    function createCheckIn(
        string memory _checkInId,
        string memory _userId,
        string memory _seatNumber,
        string memory _areaName
    ) external returns (bool) {
        require(bytes(checkInRecords[_checkInId].checkInId).length == 0, "Check-in record already exists");

        CheckInRecord memory newRecord = CheckInRecord({
            checkInId: _checkInId,
            userId: _userId,
            seatNumber: _seatNumber,
            areaName: _areaName,
            checkInTime: block.timestamp,
            checkOutTime: 0,
            status: CheckInStatus.PENDING
        });

        checkInRecords[_checkInId] = newRecord;
        checkInIds.push(_checkInId);

        emit CheckInCreated(
            _checkInId,
            _userId,
            _seatNumber,
            _areaName,
            block.timestamp
        );

        return true;
    }

    function getCheckInRecord(string memory _checkInId) external view returns (
        string memory,
        string memory,
        string memory,
        string memory,
        uint256,
        uint256,
        CheckInStatus
    ) {
        CheckInRecord memory record = checkInRecords[_checkInId];
        require(bytes(record.checkInId).length > 0, "Check-in record does not exist");

        return (
            record.checkInId,
            record.userId,
            record.seatNumber,
            record.areaName,
            record.checkInTime,
            record.checkOutTime,
            record.status
        );
    }

    function updateCheckOut(string memory _checkInId) external returns (bool) {
        CheckInRecord storage record = checkInRecords[_checkInId];
        require(bytes(record.checkInId).length > 0, "Check-in record does not exist");
        require(record.status == CheckInStatus.PENDING, "Check-in is not in pending status");

        record.checkOutTime = block.timestamp;
        record.status = CheckInStatus.COMPLETED;

        emit CheckOutUpdated(
            _checkInId,
            block.timestamp,
            CheckInStatus.COMPLETED
        );

        return true;
    }

    function getAllCheckInIds() external view returns (string[] memory) {
        return checkInIds;
    }

    function getCheckInCount() external view returns (uint256) {
        return checkInIds.length;
    }
}
