// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract Appeal {
    struct AppealRecord {
        string appealId;
        string userId;
        string violationId;
        string content;
        uint256 timestamp;
    }

    mapping(string => AppealRecord) private appealRecords;
    string[] private appealIds;

    event AppealCreated(
        string indexed appealId,
        string indexed userId,
        string violationId,
        string content,
        uint256 timestamp
    );

    function createAppeal(
        string calldata appealId,
        string calldata userId,
        string calldata violationId,
        string calldata content
    ) external returns (bool) {
        require(appealRecords[appealId].timestamp == 0, "Appeal exists");

        appealRecords[appealId] = AppealRecord({
            appealId: appealId,
            userId: userId,
            violationId: violationId,
            content: content,
            timestamp: block.timestamp
        });

        appealIds.push(appealId);

        emit AppealCreated(
            appealId,
            userId,
            violationId,
            content,
            block.timestamp
        );

        return true;
    }
}
