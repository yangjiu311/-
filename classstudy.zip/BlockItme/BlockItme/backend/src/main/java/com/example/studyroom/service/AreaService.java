package com.example.studyroom.service;

import com.example.studyroom.model.Area;
import java.util.List;
import java.util.Optional;

public interface AreaService {
    List<Area> getAllAreas();
    Optional<Area> getAreaById(Long id);
    Area createArea(Area area);
    Area updateArea(Long id, Area area);
    void deleteArea(Long id);
    boolean existsByClassroomName(String classroomName);
}

