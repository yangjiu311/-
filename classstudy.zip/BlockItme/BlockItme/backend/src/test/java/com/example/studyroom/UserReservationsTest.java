package com.example.studyroom;

import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.Seat;
import com.example.studyroom.model.User;
import com.example.studyroom.model.Area;
import com.example.studyroom.service.AreaService;
import com.example.studyroom.service.ReservationService;
import com.example.studyroom.service.SeatService;
import com.example.studyroom.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class UserReservationsTest {

    @Autowired
    private UserService userService;

    @Autowired
    private SeatService seatService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private AreaService areaService;

    private User testUser;
    private Seat testSeat;

    @BeforeEach
    public void setUp() {
        // 创建测试区域
        Area area = new Area();
        area.setClassroomName("Classroom 1");
        areaService.createArea(area);

        // 创建测试用户
        User user = new User();
        user.setUserId("test-user-123");
        user.setStudentId("STU001");
        user.setPassword("password123");
        user.setEmail("test@example.com");
        user.setPhone("13800138000");
        user.setRole(User.Role.student);
        user.setWalletAddress("0x742d35Cc6634C0532925a3b80152f7412f179892");
        user.setStatus(User.Status.enabled);
        user.setCreatedAt(LocalDateTime.now());
        user.setName("Test User");
        testUser = userService.createUser(user);

        // 创建测试座位
        Seat seat = new Seat();
        seat.setSeatNumber("A1");
        seat.setClassroomName("Classroom 1");
        seat.setStatus(Seat.Status.available);
        seat.setCreatedAt(LocalDateTime.now());
        seat.setRow(1);
        seat.setColumn(1);
        testSeat = seatService.createSeat(seat);
    }

    @Test
    public void testUserReservations() {
        // 为测试用户创建2个预约记录
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime tomorrow = now.plusDays(1);

        Reservation reservation1 = new Reservation();
        reservation1.setUserId(testUser.getUserId());
        reservation1.setSeatId(testSeat.getId());
        reservation1.setStartTime(now.plusHours(1));
        reservation1.setEndTime(now.plusHours(3));
        reservation1.setStatus(Reservation.Status.confirmed);
        reservation1.setReservationDate(now.toLocalDate());
        reservation1.setClassroomName(testSeat.getClassroomName());
        reservation1.setSeatNumber(testSeat.getSeatNumber());
        reservation1.setStuAdminId(testUser.getStudentId());
        reservationService.createReservation(reservation1);

        Reservation reservation2 = new Reservation();
        reservation2.setUserId(testUser.getUserId());
        reservation2.setSeatId(testSeat.getId());
        reservation2.setStartTime(tomorrow.plusHours(1));
        reservation2.setEndTime(tomorrow.plusHours(3));
        reservation2.setStatus(Reservation.Status.confirmed);
        reservation2.setReservationDate(tomorrow.toLocalDate());
        reservation2.setClassroomName(testSeat.getClassroomName());
        reservation2.setSeatNumber(testSeat.getSeatNumber());
        reservation2.setStuAdminId(testUser.getStudentId());
        reservationService.createReservation(reservation2);

        // 调用getUserReservations API
        List<Reservation> userReservations = reservationService.getReservationsByUserId(testUser.getUserId());

        // 验证返回的预约记录数量和内容
        assertEquals(2, userReservations.size());
        for (Reservation res : userReservations) {
            assertEquals(testUser.getUserId(), res.getUserId());
            assertTrue(res.getStatus() == Reservation.Status.confirmed);
            // 验证其他字段
            assertNotNull(res.getId());
            assertNotNull(res.getSeatNumber());
            assertNotNull(res.getReservationDate());
            assertNotNull(res.getStartTime());
            assertNotNull(res.getEndTime());
            assertNotNull(res.getStatus());
        }

        System.out.println("\n=== User Reservations Test Results ===");
        System.out.println("User ID: " + testUser.getUserId());
        System.out.println("Total Reservations: " + userReservations.size());
        for (Reservation res : userReservations) {
            System.out.println("\nReservation ID: " + res.getId());
            System.out.println("Seat Number: " + res.getSeatNumber());
            System.out.println("Date: " + res.getReservationDate());
            System.out.println("Start Time: " + res.getStartTime());
            System.out.println("End Time: " + res.getEndTime());
            System.out.println("Status: " + res.getStatus());
            System.out.println("Transaction Hash: " + res.getTransactionHash());
        }
        System.out.println("\n=== Test Passed Successfully ===");
    }
}