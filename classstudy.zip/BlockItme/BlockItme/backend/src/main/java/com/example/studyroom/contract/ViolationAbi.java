package com.example.studyroom.contract;

import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

public class ViolationAbi extends Contract {
    protected ViolationAbi(String contractBinary, String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(contractBinary, contractAddress, web3j, credentials, contractGasProvider);
    }

    protected ViolationAbi(String contractBinary, String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(contractBinary, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static ViolationAbi load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new ViolationAbi(null, contractAddress, web3j, credentials, contractGasProvider);
    }

    public static ViolationAbi load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new ViolationAbi(null, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public TransactionReceipt createViolation(String violationId, String userId, String seatNumber, String areaName, String violationType) throws Exception {
        final Function function = new Function(
                "createViolation",
                Arrays.asList(new Utf8String(violationId), new Utf8String(userId), new Utf8String(seatNumber), new Utf8String(areaName), new Utf8String(violationType)),
                Collections.emptyList()
        );
        return executeRemoteCallTransaction(function).send();
    }
}
