package com.example.studyroom.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "violation")
public class Violation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "stu_admin_id", length = 50)
    private String stuAdminId;

    @Column(name = "reservation_id", nullable = false)
    private Long reservationId;

    @Enumerated(EnumType.STRING)
    @Column(name = "violation_type", nullable = false)
    private ViolationType violationType;

    @Column(name = "violation_time", nullable = false)
    private LocalDateTime violationTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(name = "penalty_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal penaltyAmount;

    @Column(name = "seat_number", length = 20)
    private String seatNumber;

    @Column(name = "classroom_name", length = 20)
    private String classroomName;

    @Column(name = "transaction_hash", unique = true, length = 255)
    private String transactionHash;

    @Column(name = "block_height")
    private Long blockHeight;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // 临时字段，用于标记是否需要上链，不存储到数据库
    @Transient
    private Boolean uploadToBlockchain;

    // Getter and setter for uploadToBlockchain
    public Boolean getUploadToBlockchain() {
        return uploadToBlockchain;
    }

    public void setUploadToBlockchain(Boolean uploadToBlockchain) {
        this.uploadToBlockchain = uploadToBlockchain;
    }

    public enum ViolationType {
        long_late, no_show, early_leave, other
    }

    public enum Status {
        unpaid, paid, cancelled
    }
}