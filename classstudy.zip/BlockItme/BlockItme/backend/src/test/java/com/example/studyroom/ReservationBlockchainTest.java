package com.example.studyroom;

import com.example.studyroom.service.ReservationService;
import com.example.studyroom.service.UserService;
import com.example.studyroom.service.SeatService;
import com.example.studyroom.service.AreaService;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.User;
import com.example.studyroom.model.Seat;
import com.example.studyroom.model.Area;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Transactional
public class ReservationBlockchainTest {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private UserService userService;

    @Autowired
    private SeatService seatService;

    @Autowired
    private AreaService areaService;

    private User testUser;
    private Seat testSeat;

    @BeforeEach
    public void setup() {
        // 创建测试用户
        testUser = new User();
        testUser.setUserId("test-user-blockchain");
        testUser.setStudentId("STU999");
        testUser.setPassword("password123");
        testUser.setEmail("blockchain@example.com");
        testUser.setPhone("13800138999");
        testUser.setRole(User.Role.student);
        testUser.setWalletAddress("0x742d35Cc6634C0532925a3b80152f7412f179892");
        testUser.setStatus(User.Status.enabled);
        testUser.setBalance(new BigDecimal("100.0")); // 设置足够的余额
        testUser.setName("区块链测试用户"); // 设置用户名
        testUser = userService.createUser(testUser);
        assertNotNull(testUser, "测试用户创建失败");

        // 创建测试区域
        Area testArea = new Area();
        testArea.setClassroomName("测试教室");
        testArea = areaService.createArea(testArea);
        assertNotNull(testArea, "测试区域创建失败");

        // 创建测试座位
        testSeat = new Seat();
        testSeat.setSeatNumber("A1-01");
        testSeat.setClassroomName("测试教室");
        testSeat.setClassroomId(testArea.getId());
        testSeat.setStatus(Seat.Status.available);
        testSeat.setRow(1);
        testSeat.setColumn(1);
        testSeat = seatService.createSeat(testSeat);
        assertNotNull(testSeat, "测试座位创建失败");
    }

    @Test
    public void testReservationOnChain() {
        // 创建预约实体
        Reservation reservation = new Reservation();
        reservation.setUserId(testUser.getUserId());
        reservation.setSeatId(testSeat.getId());
        reservation.setStartTime(LocalDateTime.now().plusHours(1));
        reservation.setEndTime(LocalDateTime.now().plusHours(2));
        reservation.setStatus(Reservation.Status.confirmed);
        reservation.setReservationDate(LocalDateTime.now().toLocalDate());
        reservation.setClassroomName(testSeat.getClassroomName());
        reservation.setSeatNumber(testSeat.getSeatNumber());
        reservation.setStuAdminId(testUser.getStudentId());
        reservation.setDepositAmount("10.0"); // 设置押金金额

        // 执行预约创建（应该触发上链）
        Reservation createdReservation = reservationService.createReservation(reservation);
        assertNotNull(createdReservation, "预约创建失败");
        assertNotNull(createdReservation.getId(), "预约ID为空");

        // 获取创建的预约信息
        List<Reservation> userReservations = reservationService.getReservationsByUserId(testUser.getUserId());
        assertNotNull(userReservations, "用户预约列表为空");
        assertTrue(userReservations.size() > 0, "用户无预约记录");

        Reservation retrievedReservation = userReservations.get(0);
        
        // 验证上链信息
        assertNotNull(retrievedReservation.getTransactionHash(), "区块链哈希为空");
        assertNotNull(retrievedReservation.getBlockHeight(), "区块高度为空");
        assertTrue(retrievedReservation.getBlockHeight() > 0, "区块高度应该大于0");
        
        System.out.println("区块链哈希: " + retrievedReservation.getTransactionHash());
        System.out.println("区块高度: " + retrievedReservation.getBlockHeight());

        // 验证用户余额是否被扣除
        User updatedUser = userService.getUserByUserId(testUser.getUserId()).orElse(null);
        assertNotNull(updatedUser, "用户不存在");
        
        // 打印余额信息进行调试
        System.out.println("DEBUG: testUser balance before: " + testUser.getBalance());
        System.out.println("DEBUG: updatedUser balance after: " + updatedUser.getBalance());
        System.out.println("DEBUG: compareTo result: " + updatedUser.getBalance().compareTo(testUser.getBalance()));
        
        // 修正断言逻辑，直接检查余额是否等于预期值
        assertTrue(updatedUser.getBalance().compareTo(new BigDecimal("90.0")) == 0, "用户余额未正确扣除");

        System.out.println("预约上链测试成功！");
        System.out.println("预约ID: " + retrievedReservation.getId());
        System.out.println("区块链哈希: " + retrievedReservation.getTransactionHash());
        System.out.println("区块高度: " + retrievedReservation.getBlockHeight());
        System.out.println("用户原余额: " + testUser.getBalance());
        System.out.println("用户现余额: " + updatedUser.getBalance());
        System.out.println("扣除金额: " + (testUser.getBalance().subtract(updatedUser.getBalance())));
    }
}