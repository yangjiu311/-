package com.example.studyroom.service;

import com.example.studyroom.model.Appeal;
import java.util.List;
import java.util.Optional;

public interface AppealService {
    List<Appeal> getAllAppeals();
    Optional<Appeal> getAppealById(Long id);
    Optional<Appeal> getAppealByViolationId(Long violationId);
    List<Appeal> getAppealsByUserId(String userId);
    List<Appeal> getAppealsByAppealStatus(Appeal.AppealStatus status);
    List<Appeal> getAppealsByUserIdAndAppealStatus(String userId, Appeal.AppealStatus status);
    Optional<Appeal> getAppealByTransactionHash(String transactionHash);
    Appeal createAppeal(Appeal appeal);
    Appeal updateAppeal(Long id, Appeal appeal);
    void deleteAppeal(Long id);
    boolean existsByViolationId(Long violationId);
}