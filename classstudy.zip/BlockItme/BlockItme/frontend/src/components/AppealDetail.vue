<template>
  <div class="appeal-detail">
    <div class="modal-header">
      <h3>申诉记录详情</h3>
      <button class="close-btn" @click="closeModal">&times;</button>
    </div>
    <div class="modal-body">
      <div class="detail-item">
        <span class="label">申诉ID:</span>
        <span class="value">{{ appeal.id }}</span>
      </div>
      <div class="detail-item">
        <span class="label">违约ID:</span>
        <span class="value">{{ appeal.violationId }}</span>
      </div>
      <div class="detail-item">
        <span class="label">用户ID:</span>
        <span class="value">{{ appeal.userId }}</span>
      </div>
      <div class="detail-item">
        <span class="label">学号/工号:</span>
        <span class="value">{{ appeal.stuAdminId }}</span>
      </div>
      <div class="detail-item">
        <span class="label">申诉内容:</span>
        <span class="value">{{ appeal.appealContent }}</span>
      </div>
      <div class="detail-item">
        <span class="label">申诉状态:</span>
        <span class="value status-{{ appeal.appealStatus }}">
          {{ getStatusText(appeal.appealStatus) }}
        </span>
      </div>
      <div class="detail-item" v-if="appeal.processedBy">
        <span class="label">处理人:</span>
        <span class="value">{{ appeal.processedBy }}</span>
      </div>
      <div class="detail-item" v-if="appeal.processingResult">
        <span class="label">处理结果:</span>
        <span class="value">{{ appeal.processingResult }}</span>
      </div>
      <div class="detail-item">
        <span class="label">申诉哈希:</span>
        <span class="value hash">{{ appeal.transactionHash }}</span>
      </div>
      <div class="detail-item">
        <span class="label">区块高度:</span>
        <span class="value">{{ appeal.blockHeight }}</span>
      </div>
      <div class="detail-item">
        <span class="label">创建时间:</span>
        <span class="value">{{ formatDate(appeal.createdAt) }}</span>
      </div>
      

    </div>
    <div class="modal-footer">
      <button class="btn-close" @click="closeModal">关闭</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AppealDetail',
  props: {
    appeal: {
      type: Object,
      required: true
    }
  },

  methods: {
    closeModal() {
      this.$emit('close');
    },
    getStatusText(status) {
      const statusMap = {
        pending: '待处理',
        processing: '处理中',
        approved: '已通过',
        rejected: '已拒绝'
      };
      return statusMap[status] || status;
    },
    formatDate(date) {
      if (!date) return '';
      const d = new Date(date);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    },
    formatDateTime(date) {
      if (!date) return '';
      const d = new Date(date);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
    }
  }
};
</script>

<style scoped>
.appeal-detail {
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  width: 100%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e8e8e8;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #999;
}

.modal-body {
  padding: 20px;
}

.detail-item {
  display: flex;
  margin-bottom: 16px;
  align-items: flex-start;
}

.label {
  width: 100px;
  font-weight: 500;
  color: #666;
}

.value {
  flex: 1;
  color: #333;
  word-break: break-all;
}

.status-pending {
  color: #faad14;
}

.status-approved {
  color: #52c41a;
}

.status-rejected {
  color: #f5222d;
}

.hash {
  font-family: monospace;
  font-size: 14px;
  line-height: 1.4;
}



.modal-footer {
  padding: 16px 20px;
  border-top: 1px solid #e8e8e8;
  display: flex;
  justify-content: flex-end;
}

.btn-close {
  padding: 8px 16px;
  background: #f5f5f5;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  color: #333;
}

.btn-close:hover {
  background: #e6f7ff;
  border-color: #91d5ff;
  color: #1890ff;
}

@media (max-width: 576px) {
  .appeal-detail {
    margin: 0 20px;
  }
  
  .detail-item {
    flex-direction: column;
  }
  
  .label {
    width: 100%;
    margin-bottom: 4px;
  }
}
</style>
