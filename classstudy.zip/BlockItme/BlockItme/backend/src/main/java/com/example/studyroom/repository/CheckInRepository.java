package com.example.studyroom.repository;

import com.example.studyroom.model.CheckIn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CheckInRepository extends JpaRepository<CheckIn, Long> {
    Optional<CheckIn> findByReservationId(Long reservationId);
    List<CheckIn> findByUserId(String userId);
    List<CheckIn> findByStatus(CheckIn.Status status);
    Optional<CheckIn> findByTransactionHash(String transactionHash);
    List<CheckIn> findByUserIdAndStatus(String userId, CheckIn.Status status);
    boolean existsByReservationId(Long reservationId);
    List<CheckIn> findByUserIdAndDisplay(String userId, CheckIn.DisplayStatus display);
    
    @Modifying
    @Query("UPDATE CheckIn c SET c.display = :display WHERE c.id = :id")
    int updateDisplayStatus(@Param("id") Long id, @Param("display") CheckIn.DisplayStatus display);
}