package com.example.studyroom.controller;

import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.model.Reservation;
import com.example.studyroom.repository.BlockchainLogRepository;
import com.example.studyroom.repository.ReservationRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 区块链日志控制器
 */
@RestController
@RequestMapping("/blockchain-logs")
@AllArgsConstructor
public class BlockchainLogController {
    
    private final BlockchainLogRepository blockchainLogRepository;
    private final ReservationRepository reservationRepository;
    
    /**
     * 根据交易哈希获取区块链日志
     */
    @GetMapping("/transaction/{transactionHash}")
    public ResponseEntity<BlockchainLog> getBlockchainLogByTransactionHash(@PathVariable String transactionHash) {
        Optional<BlockchainLog> blockchainLog = blockchainLogRepository.findByTransactionHash(transactionHash);
        return blockchainLog.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
    
    /**
     * 根据预约ID获取所有相关的区块链日志
     */
    @GetMapping("/reservation/{reservationId}")
    public ResponseEntity<List<BlockchainLog>> getBlockchainLogsByReservationId(@PathVariable Long reservationId) {
        List<BlockchainLog> logs = blockchainLogRepository.findByTargetId(reservationId);
        return ResponseEntity.ok(logs);
    }
    
    /**
     * 根据用户ID获取所有区块链日志
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BlockchainLog>> getBlockchainLogsByUserId(@PathVariable String userId) {
        List<BlockchainLog> logs = blockchainLogRepository.findByUserId(userId);
        return ResponseEntity.ok(logs);
    }
    
    /**
     * 获取所有区块链日志
     */
    @GetMapping
    public ResponseEntity<List<BlockchainLog>> getAllBlockchainLogs() {
        List<BlockchainLog> logs = blockchainLogRepository.findAll();
        return ResponseEntity.ok(logs);
    }
    
    /**
     * 获取预约的上链信息和区块链日志
     * 返回预约详情和相关的区块链日志
     */
    @GetMapping("/reservation-info/{transactionHash}")
    public ResponseEntity<Map<String, Object>> getReservationBlockchainInfo(@PathVariable String transactionHash) {
        Map<String, Object> result = new HashMap<>();
        
        // 获取区块链日志
        Optional<BlockchainLog> blockchainLog = blockchainLogRepository.findByTransactionHash(transactionHash);
        if (blockchainLog.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        BlockchainLog log = blockchainLog.get();
        
        // 直接返回区块链日志的字段
        result.put("blockHeight", log.getBlockHeight());
        result.put("operationType", log.getOperationType());
        result.put("status", log.getStatus());
        result.put("createdAt", log.getCreatedAt());
        result.put("transactionHash", log.getTransactionHash());
        
        return ResponseEntity.ok(result);
    }
}


