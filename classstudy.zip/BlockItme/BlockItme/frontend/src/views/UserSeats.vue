<template>
  <div class="user-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>用户中心</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/user" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>首页</span>
        </router-link>
        <router-link to="/user/seats" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>座位预约</span>
        </router-link>
        <router-link to="/user/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/user/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/user/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/user/profile" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>个人信息</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <div class="nav-left">
          <h1>座位预约</h1>
        </div>
        <div class="nav-right">
          <div class="user-info" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
            <span class="username">{{ userStore.userInfo?.name || '用户' }}</span>
            <div class="user-dropdown" v-if="showDropdown" @mouseenter="showDropdown = true" @mouseleave="showDropdown = false">
              <button class="dropdown-item" @click="router.push('/user/profile')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                个人信息
              </button>
              <button class="dropdown-item" @click="connectWallet">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                {{ userStore.walletAddress ? '钱包已连接' : '连接钱包' }}
              </button>
              <button class="dropdown-item" @click="router.push('/user/change-password')">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                修改密码
              </button>
              <button class="dropdown-item" @click="logout">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M16 17L21 12L16 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <!-- 预约信息选择区域 -->
      <section class="reservation-info">
        <div class="info-card">
          <h2>选择预约信息</h2>
          <div class="info-form">
            <div class="form-group">
              <label for="date-picker">选择日期</label>
              <input type="date" id="date-picker" class="form-control" v-model="selectedDate" />
            </div>
            <div class="form-group">
              <label for="start-time">开始时间</label>
              <div class="custom-select">
                <input 
                  type="text" 
                  id="start-time" 
                  class="form-control" 
                  v-model="selectedStartTime" 
                  placeholder="例如：08:00" 
                  @click="showStartTimeDropdown = !showStartTimeDropdown"
                  @focus="showStartTimeDropdown = true"
                  @blur="hideStartTimeDropdown"
                />
                <div class="select-icon" @click="showStartTimeDropdown = !showStartTimeDropdown">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div v-if="showStartTimeDropdown" class="time-dropdown" @mousedown.stop>
                  <div 
                    v-for="time in timeOptions" 
                    :key="'start-' + time.value" 
                    class="time-option"
                    @click="selectStartTime(time.value)"
                  >
                    {{ time.label }}
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="end-time">结束时间</label>
              <div class="custom-select">
                <input 
                  type="text" 
                  id="end-time" 
                  class="form-control" 
                  v-model="selectedEndTime" 
                  placeholder="例如：10:00" 
                  @click="showEndTimeDropdown = !showEndTimeDropdown"
                  @focus="showEndTimeDropdown = true"
                  @blur="hideEndTimeDropdown"
                />
                <div class="select-icon" @click="showEndTimeDropdown = !showEndTimeDropdown">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div v-if="showEndTimeDropdown" class="time-dropdown" @mousedown.stop>
                  <div 
                    v-for="time in timeOptions" 
                    :key="'end-' + time.value" 
                    class="time-option"
                    @click="selectEndTime(time.value)"
                  >
                    {{ time.label }}
                  </div>
                </div>
              </div>
            </div>
            <!-- 添加可输入可选择的区域下拉框 -->
            <div class="form-group">
              <label for="seat-area">选择区域</label>
              <div class="custom-select">
                <input 
                  type="text" 
                  id="seat-area" 
                  class="form-control" 
                  v-model="selectedArea" 
                  placeholder="例如：A区" 
                  @click="showAreaDropdown = !showAreaDropdown"
                  @focus="showAreaDropdown = true"
                  @blur="hideAreaDropdown"
                />
                <div class="select-icon" @click="showAreaDropdown = !showAreaDropdown">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div v-if="showAreaDropdown" class="time-dropdown" @mousedown.stop>
                  <div 
                    v-for="area in areaOptions" 
                    :key="area.value" 
                    class="time-option"
                    @click="selectArea(area.label)"
                  >
                    {{ area.label }}
                  </div>
                </div>
              </div>
            </div>
            <div class="form-actions">
              <button class="primary-btn" @click="searchSeats">查询可用座位</button>
              <button class="secondary-btn" @click="resetForm">重置</button>
            </div>
          </div>
        </div>
      </section>

      <!-- 座位选择区域 -->
      <section class="seat-selection">
        <div class="seat-card">
          <h2>座位选择（{{ currentAreaTitle }}）</h2>
          
          <!-- 可视化座位表 -->
          <SeatVisualization 
            :area-name="currentAreaTitle" 
            :seats="seats" 
            @seat-click="selectSeat"
          />
          
          <!-- 原有的座位选择区域可以保留，或者根据需求决定是否移除 -->
        </div>
      </section>

      <!-- 预约确认区域 -->
      <section class="reservation-confirmation">
        <div class="confirm-card">
          <h2>预约确认</h2>
          <div class="confirm-info">
            <div class="info-item">
              <span class="info-label">已选座位：</span>
              <span class="info-value selected-seat">{{ selectedSeat || '未选择' }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">区域：</span>
              <span class="info-value">{{ selectedArea || '未选择' }}</span>
            </div>
             <div class="info-item">
               <span class="info-label">日期：</span>
               <span class="info-value">{{ selectedDate || '未选择' }}</span>
             </div>
             <div class="info-item">
               <span class="info-label">开始时间：</span>
               <span class="info-value">{{ selectedStartTime || '未选择' }}</span>
             </div>
             <div class="info-item">
               <span class="info-label">结束时间：</span>
               <span class="info-value">{{ selectedEndTime || '未选择' }}</span>
             </div>
             <div class="info-item">
               <span class="info-label">学号/工号：</span>
               <span class="info-value">{{ userStore.userInfo?.stu_admin_id || userStore.userInfo?.stuAdminId || userStore.userInfo?.studentId || '未获取' }}</span>
             </div>
             <div class="info-item">
               <span class="info-label">押金：</span>
               <span class="info-value">{{ depositAmount || '未设置' }}</span>
             </div>
          </div>
          <div class="confirm-actions">
            <button class="primary-btn" @click="confirmReservation">确认预约</button>
            <button class="secondary-btn" @click="cancelSelection">取消选择</button>
          </div>
        </div>
      </section>
    </main>
    
    <!-- 连接钱包对话框 -->
    <ConnectWalletModal 
      :visible="showConnectWalletModal"
      :default-address="userWalletAddress"
      @close="showConnectWalletModal = false"
      @connect="handleWalletConnected"
    />
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, onMounted, computed, watch } from 'vue'
import { getAllSeats, getAllAreas, createReservation, checkSeatAvailability, getCurrentUser } from '../services/api'
import SeatVisualization from '../components/SeatVisualization.vue'
import ConnectWalletModal from '../components/ConnectWalletModal.vue'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 用户信息
const username = ref('用户')
const userWalletAddress = ref('')

// 选择的预约信息
const selectedSeat = ref('')
const selectedArea = ref('')
const selectedDate = ref('')
const selectedStartTime = ref('')
const selectedEndTime = ref('')
const depositAmount = ref('1')

// 连接钱包对话框
const showConnectWalletModal = ref(false)

// 下拉框状态
const showAreaDropdown = ref(false)
const showStartTimeDropdown = ref(false)
const showEndTimeDropdown = ref(false)

// 区域选项
const areaOptions = ref([
  { label: 'A区', value: 'A' },
  { label: 'B区', value: 'B' },
  { label: 'C区', value: 'C' },
  { label: 'D区', value: 'D' }
])

// 时间段选项
const timeOptions = ref([
  { label: '08:00', value: '08:00' },
  { label: '10:00', value: '10:00' },
  { label: '12:00', value: '12:00' },
  { label: '14:00', value: '14:00' },
  { label: '16:00', value: '16:00' },
  { label: '18:00', value: '18:00' },
  { label: '20:00', value: '20:00' }
])

// 座位数据
const seats = ref([])

// 当前区域标题
const currentAreaTitle = computed(() => {
  return selectedArea.value || 'A区'
})

// 获取区域信息
const fetchAreas = async () => {
  try {
    const areas = await getAllAreas()
    if (areas && areas.length > 0) {
      areaOptions.value = areas.map(area => ({
        label: area.classroomName,
        value: area.classroomName
      }))
    }
  } catch (error) {
    console.error('获取区域信息失败:', error)
    // 失败时使用默认区域选项
    areaOptions.value = [
      { label: 'A区', value: 'A' },
      { label: 'B区', value: 'B' },
      { label: 'C区', value: 'C' },
      { label: 'D区', value: 'D' }
    ]
  }
}

// 获取所有座位信息
const fetchSeats = async () => {
  try {
    const seatsData = await getAllSeats()
    seats.value = seatsData || []
  } catch (error) {
    console.error('获取座位信息失败:', error)
    seats.value = []
  }
}

// 获取用户信息
const fetchUserInfo = async () => {
  try {
    const userId = userStore.userInfo?.userId
    if (userId) {
      const userData = await getCurrentUser(userId)
      if (userData && userData.walletAddress) {
        userWalletAddress.value = userData.walletAddress
      }
    }
  } catch (error) {
    console.error('获取用户信息失败:', error)
  }
}

// 组件挂载时获取区域和座位信息
onMounted(() => {
  fetchAreas()
  fetchSeats()
  fetchUserInfo()
})



const isClickingDropdown = ref(false)

const selectStartTime = (time) => {
  isClickingDropdown.value = true
  selectedStartTime.value = time
  showStartTimeDropdown.value = false
  setTimeout(() => {
    isClickingDropdown.value = false
  }, 100)
}

const hideStartTimeDropdown = () => {
  if (!isClickingDropdown.value) {
    setTimeout(() => {
      if (!isClickingDropdown.value) {
        showStartTimeDropdown.value = false
      }
    }, 150)
  }
}

const selectEndTime = (time) => {
  isClickingDropdown.value = true
  selectedEndTime.value = time
  showEndTimeDropdown.value = false
  setTimeout(() => {
    isClickingDropdown.value = false
  }, 100)
}

const hideEndTimeDropdown = () => {
  if (!isClickingDropdown.value) {
    setTimeout(() => {
      if (!isClickingDropdown.value) {
        showEndTimeDropdown.value = false
      }
    }, 150)
  }
}

const selectArea = (area) => {
  isClickingDropdown.value = true
  selectedArea.value = area
  showAreaDropdown.value = false
  setTimeout(() => {
    isClickingDropdown.value = false
  }, 100)
}

const hideAreaDropdown = () => {
  if (!isClickingDropdown.value) {
    setTimeout(() => {
      if (!isClickingDropdown.value) {
        showAreaDropdown.value = false
      }
    }, 150)
  }
}

// 查询座位
const searchSeats = () => {
   console.log('查询可用座位:', {
     area: selectedArea.value,
     date: selectedDate.value,
     startTime: selectedStartTime.value,
     endTime: selectedEndTime.value
   })
   // 这里可以添加调用API获取可用座位的逻辑
 }

// 重置表单
const resetForm = () => {
   console.log('重置表单')
   selectedSeat.value = ''
   selectedArea.value = ''
   selectedDate.value = ''
   selectedStartTime.value = ''
   selectedEndTime.value = ''
 }

// 确认预约
const confirmReservation = async () => {
  // 表单验证
  if (!selectedDate.value) {
    alert('请选择预约日期')
    return
  }
  
  if (!selectedStartTime.value) {
    alert('请选择开始时间')
    return
  }
  
  if (!selectedEndTime.value) {
    alert('请选择结束时间')
    return
  }
  
  if (!selectedArea.value) {
    alert('请选择区域')
    return
  }
  
  if (!selectedSeat.value) {
    alert('请先选择座位')
    return
  }
  
  // 验证时间顺序
  const startDateTime = new Date(`${selectedDate.value}T${selectedStartTime.value}`)
  const endDateTime = new Date(`${selectedDate.value}T${selectedEndTime.value}`)
  
  if (endDateTime <= startDateTime) {
    alert('结束时间必须晚于开始时间')
    return
  }
  
  // 验证当前时间
  const now = new Date()
  if (startDateTime <= now) {
    alert('开始时间必须是未来的时间')
    return
  }
  
  try {
      // 获取当前登录用户信息
      const userInfo = JSON.parse(localStorage.getItem('userInfo'))
      
      // 检查用户钱包地址
      if (!userStore.walletAddress) {
        alert('请先连接以太坊钱包')
        return
      }
      
      // 显示当前连接的钱包地址，方便调试
      console.log('当前连接的钱包地址:', userStore.walletAddress)
      
      // 检查MetaMask是否连接到当前账户
      if (window.ethereum) {
        try {
          console.log('检查MetaMask连接状态...')
          let accounts = await window.ethereum.request({ method: 'eth_accounts' })
          console.log('当前MetaMask账户列表:', accounts)
          
          // 如果没有连接，自动请求连接
          if (!accounts || accounts.length === 0) {
            console.log('MetaMask未连接，请求连接...')
            try {
              console.log('发送eth_requestAccounts请求...')
              accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
              console.log('eth_requestAccounts返回:', accounts)
            } catch (requestError) {
              console.error('用户拒绝连接MetaMask:', requestError)
              alert('请在MetaMask中点击"连接"按钮来授权网站访问您的钱包')
              return
            }
            
            if (!accounts || accounts.length === 0) {
              alert('请在MetaMask中连接钱包')
              return
            }
          }
          
          console.log('MetaMask当前账户:', accounts[0])
          
          // 更新用户存储中的钱包地址（如果不匹配）
          if (accounts[0].toLowerCase() !== userStore.walletAddress.toLowerCase()) {
            console.log('钱包地址不匹配，更新为MetaMask当前账户')
            userStore.walletAddress = accounts[0]
            localStorage.setItem('walletAddress', accounts[0])
          }
        } catch (error) {
          console.error('获取MetaMask账户失败:', error)
          alert('无法连接MetaMask钱包，请检查MetaMask是否已安装并登录')
          return
        }
      } else {
        console.error('MetaMask未安装')
        alert('请安装MetaMask扩展后再进行预约')
        return
      }
      
      // 检查钱包余额（使用Ganache查询）
      const balance = await userStore.web3.eth.getBalance(userStore.walletAddress)
      const balanceInEth = userStore.web3.utils.fromWei(balance, 'ether')
      console.log('当前钱包余额 (Ganache):', balanceInEth, 'ETH')
      
      
      // 检查余额是否足够（需要至少1 ETH）
      if (parseFloat(balanceInEth) < 1) {
        alert(`当前钱包余额不足！需要至少1 ETH，当前余额：${balanceInEth} ETH\n请在MetaMask中切换到有足够余额的账户后重新连接钱包。`)
        return
      }
      
      // 智能合约地址（已部署，支持直接转账）
      const depositManagerContractAddress = '0x9fEfb53DC3f9170018c7eF660c6b9023736A3CcC'
      
      // 智能合约ABI（简化版，只包含deposit函数）
      const depositManagerAbi = [
        {
          "inputs": [],
          "name": "deposit",
          "outputs": [],
          "stateMutability": "payable",
          "type": "function"
        }
      ]
      
      // 初始化Web3
      if (!userStore.web3) {
        userStore.initWeb3()
      }
      
      let depositTxHash
      
      // 使用MetaMask调用智能合约（需要用户确认）
      if (window.ethereum) {
        // 检查MetaMask网络
        const currentNetworkId = await window.ethereum.request({ method: 'net_version' })
        const ganacheNetworkId = '1337'
        
        if (currentNetworkId !== ganacheNetworkId) {
          alert(`网络不匹配！\n\n当前MetaMask网络ID: ${currentNetworkId}（Sepolia测试网）\n需要网络ID: ${ganacheNetworkId}（Ganache本地网络）\n\n请在MetaMask中切换到Ganache网络后重新尝试预约。\n\nGanache网络配置：\n- RPC URL: http://127.0.0.1:7545\n- 链ID: 1337\n- 符号: ETH`)
          return
        }
        
        // 创建合约实例
        const contract = new userStore.web3.eth.Contract(depositManagerAbi, depositManagerContractAddress)
        
        // 1 ETH in wei (使用toWei函数确保正确的wei值)
        const oneEthInWei = userStore.web3.utils.toWei('1', 'ether')
        
        console.log('=== 调试信息 ===')
        console.log('智能合约地址:', depositManagerContractAddress)
        console.log('Web3实例:', userStore.web3)
        console.log('钱包地址:', userStore.walletAddress)
        console.log('1 ETH in wei:', oneEthInWei)
        console.log('转换回ETH:', userStore.web3.utils.fromWei(oneEthInWei, 'ether'))
        
        // 使用十六进制格式的wei值（1 ETH = 0xde0b6b3a7640000）
        const transaction = {
          from: userStore.walletAddress,
          to: depositManagerContractAddress,
          value: '0xde0b6b3a7640000', // 1 ETH的十六进制表示
          data: contract.methods.deposit().encodeABI()
          // gas和gasPrice由MetaMask自动处理
        }
        
        console.log('发送的合约调用交易:', JSON.stringify(transaction, null, 2))
        
        // 发送交易（会弹出MetaMask确认窗口，用户必须点击确认）
        try {
          console.log('准备发送合约调用交易到MetaMask...')
          console.log('交易参数:', transaction)
          
          depositTxHash = await window.ethereum.request({
            method: 'eth_sendTransaction',
            params: [transaction]
          })
          
          console.log('押金交易成功:', depositTxHash)
        } catch (txError) {
          console.error('交易失败详情:', txError)
          console.error('错误类型:', typeof txError)
          console.error('错误消息:', txError.message)
          console.error('错误代码:', txError.code)
          console.error('错误对象:', JSON.stringify(txError, null, 2))
          
          // 更准确地识别错误类型
          if (txError.code === 4001 || 
              txError.message.includes('User rejected') || 
              txError.message.includes('user rejected')) {
            alert('交易已取消！您点击了拒绝按钮或关闭了MetaMask窗口。')
          } else if (txError.code === -32000 || 
                     txError.message.includes('insufficient funds')) {
            alert('交易失败：账户余额不足！请确保您的钱包中有足够的ETH。')
          } else if (txError.message.includes('gas') || 
                     txError.message.includes('Gas')) {
            alert('交易失败：Gas费用不足或Gas价格设置错误。')
          } else if (txError.code === -32603 && 
                     txError.message.includes('aborted')) {
            alert('交易失败：MetaMask内部错误。请尝试重新连接钱包或重启MetaMask扩展后重试。')
          } else {
            alert('交易失败：' + txError.message)
          }
          return
        }
      } else {
        // 如果没有MetaMask，使用Ganache直接调用合约
        // 创建合约实例
        const contract = new userStore.web3.eth.Contract(depositManagerAbi, depositManagerContractAddress)
        
        // 1 ETH in wei (使用toWei函数确保正确的wei值)
        const oneEthInWei = userStore.web3.utils.toWei('1', 'ether')
        
        // 发送交易（使用Ganache，不需要用户确认）
        alert('正在发送预约押金交易...')
        const txResult = await contract.methods.deposit().send({
          from: userStore.walletAddress,
          value: oneEthInWei,
          gas: 100000 // 合约调用需要更多gas
        })
        depositTxHash = txResult.transactionHash
        console.log('押金交易成功:', depositTxHash)
      }
    
    // 找到选择的座位对象
    const selectedSeatObj = seats.value.find(seat => seat.seatNumber === selectedSeat.value)
    
    if (!selectedSeatObj) {
      alert('找不到选择的座位信息')
      return
    }
    
    // 准备预约数据 - 直接使用用户选择的时间，不进行时区转换
    const reservationData = {
      userId: userInfo.userId,
      stuAdminId: userInfo.stuAdminId || userInfo.studentId || userInfo.userId, // 使用用户的stuAdminId或studentId，如果都没有则使用userId
      seatId: selectedSeatObj.id,
      startTime: `${selectedDate.value}T${selectedStartTime.value}:00`,
      endTime: `${selectedDate.value}T${selectedEndTime.value}:00`,
      status: 'reserved', // 设置为"已预约"状态
      depositAmount: depositAmount.value, // 押金金额
      depositTxHash: depositTxHash // 押金交易哈希（字符串类型）
    }
    
    console.log('发送预约请求:', reservationData)
    
    // 跳过座位可用性检查，直接创建预约
    console.log('跳过座位可用性检查，直接创建预约...')
    
    // 调用API创建预约
    const response = await createReservation(reservationData)
    
    console.log('预约响应:', response)
    
    // 显示预约成功信息
    alert(`预约成功！\n座位号: ${selectedSeat.value}\n预约时间: ${selectedDate.value} ${selectedStartTime.value} - ${selectedEndTime.value}\n押金交易哈希: ${depositTxHash}\n区块链交易哈希: ${response.transactionHash || '处理中'}`)
    
    // 重置表单
    resetForm()
    
    // 重新加载座位数据，更新可视化座位表
    await fetchSeats()
    
  } catch (error) {
    console.error('预约失败:', error)
    alert(`预约失败: ${error.response?.data?.message || error.message || '未知错误'}`)
  }
}

// 取消选择
const cancelSelection = () => {
  selectedSeat.value = ''
}

// 选择座位
const selectSeat = (seat) => {
  if (seat.status === 'available') {
    selectedSeat.value = seat.seatNumber
    console.log('选择座位:', seat.seatNumber)
  } else {
    alert(`座位 ${seat.seatNumber} 当前状态为 ${seat.status === 'reserved' ? '已预约' : seat.status === 'used' ? '已占用' : '维护中'}，无法选择`)
  }
}

// 连接钱包
const connectWallet = () => {
  showConnectWalletModal.value = true
}

// 处理钱包连接成功
const handleWalletConnected = (address) => {
  console.log('钱包连接成功:', address)
  alert('钱包连接成功！')
}
</script>

<style scoped>
.user-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 200px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-item.active {
  background-color: #34495e;
  color: white;
  border-left-color: #4CAF50;
}

.nav-icon {
  margin-right: 12px;
}

/* 主内容区域样式 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

/* 顶部导航栏 */
.top-nav {
  height: 60px;
  background-color: white;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.top-nav h1 {
  margin: 0;
  font-size: 20px;
  color: #2c3e50;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-weight: 600;
  color: #2c3e50;
  cursor: pointer;
}

/* 预约信息选择区域样式 */
.reservation-info {
  padding: 30px;
}

.info-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.info-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.info-form {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.form-row {
  display: flex;
  gap: 20px;
  width: 100%;
}

.half-width {
  flex: 1;
  min-width: 180px;
}

.form-group {
  flex: 1;
  min-width: 220px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  color: #495057;
  font-size: 14px;
}

/* 优化后的输入框和下拉框样式 */
.form-control {
  width: 100%;
  padding: 12px 15px;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 15px;
  transition: all 0.3s ease;
  background-color: #ffffff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

/* 针对下拉选择框的特殊样式 */
select.form-control {
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 15px center;
  padding-right: 40px;
  cursor: pointer;
}

/* 下拉选择框的选项样式 */
select.form-control option {
  padding: 10px;
  font-size: 15px;
  background-color: white;
  color: #2c3e50;
}

select.form-control option:hover {
  background-color: #f1f8e9;
}

.form-control:focus {
  border-color: #4CAF50;
  outline: none;
  box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
  transform: translateY(-1px);
}

.form-control:hover:not(:focus) {
  border-color: #cbd5e1;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
}

.form-actions {
  display: flex;
  gap: 15px;
  align-items: flex-end;
  margin-top: 15px;
}

.primary-btn,
.secondary-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s ease;
  border: none;
}

.primary-btn {
  background-color: #4CAF50;
  color: white;
}

.primary-btn:hover {
  background-color: #43a047;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.secondary-btn {
  background-color: white;
  color: #4CAF50;
  border: 1px solid #4CAF50;
}

.secondary-btn:hover {
  background-color: #f1f8e9;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(76, 175, 80, 0.2);
}

/* 座位选择区域样式 */
.seat-selection {
  padding: 0 30px 30px 30px;
}

.seat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.seat-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
}

.seat-map {
  background-color: #f8f9fa;
  border-radius: 4px;
  padding: 20px;
  margin-bottom: 20px;
}

.seat-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 15px;
}

.seat-label {
  width: 40px;
  text-align: center;
  font-weight: 600;
  color: #495057;
}

.seat {
  width: 60px;
  height: 60px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
}

.seat.available {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.seat.available:hover {
  background-color: #c3e6cb;
  transform: scale(1.05);
}

.seat.reserved {
  background-color: #fff3cd;
  color: #856404;
  border: 1px solid #ffeaa7;
  cursor: not-allowed;
}

.seat.unavailable {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
  cursor: not-allowed;
}

.seat.selected {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #45a049;
}

.seat.selected:hover {
  background-color: #43a047;
  transform: scale(1.05);
}

.seat-number {
  font-size: 14px;
  font-weight: 600;
}

.seat-legend {
  display: flex;
  gap: 20px;
  justify-content: center;
  flex-wrap: wrap;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  color: #495057;
}

.legend-seat {
  width: 20px;
  height: 20px;
}

/* 预约确认区域样式 */
.reservation-confirmation {
  padding: 0 30px 30px 30px;
}

.confirm-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  max-width: 600px;
  margin: 0 auto;
}

.confirm-card h2 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #2c3e50;
  text-align: center;
}

.confirm-info {
  background-color: #f8f9fa;
  border-radius: 4px;
  padding: 20px;
  margin-bottom: 20px;
}

.info-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding: 5px 0;
  border-bottom: 1px solid #e9ecef;
}

.info-item:last-child {
  border-bottom: none;
  margin-bottom: 0;
}

.info-label {
  font-weight: 600;
  color: #495057;
}

.info-value {
  color: #2c3e50;
}

.selected-seat {
  font-weight: 600;
  color: #4CAF50;
}

.confirm-actions {
  display: flex;
  gap: 15px;
  justify-content: center;
  flex-wrap: wrap;
}

/* 用户信息和下拉菜单样式 */
.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  width: 180px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  padding: 0;
}

/* 自定义时间段下拉框样式 */
.custom-select {
  position: relative;
  width: 100%;
}

.custom-select .form-control {
  padding-right: 35px;
}

.custom-select .select-icon {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  color: #666;
  pointer-events: none;
  z-index: 10;
}

.custom-select .time-dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  margin-top: 5px;
  background-color: white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  z-index: 9999;
  max-height: 240px;
  overflow-y: auto;
}

.custom-select .time-option {
  padding: 10px 15px;
  cursor: pointer;
  font-size: 14px;
  color: #333;
  transition: background-color 0.3s ease;
}

.custom-select .time-option:hover {
  background-color: #f1f8e9;
  color: #4CAF50;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .user-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: auto;
  }

  .nav-menu {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    padding: 0;
  }

  .nav-item {
    flex: 0 0 auto;
  }

  .info-form {
    flex-direction: column;
  }

  .form-group {
    width: 100%;
  }

  .form-actions {
    width: 100%;
  }

  .primary-btn,
  .secondary-btn {
    width: 100%;
    justify-content: center;
  }

  .seat-row {
    flex-wrap: wrap;
    justify-content: center;
  }

  .seat {
    flex: 0 0 60px;
  }

  .confirm-actions {
    flex-direction: column;
  }
}
</style>









