package com.example.studyroom.controller;

import com.example.studyroom.model.Appeal;
import com.example.studyroom.service.AppealService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/appeals")
@AllArgsConstructor
public class AppealController {
    private final AppealService appealService;

    @GetMapping
    public ResponseEntity<List<Appeal>> getAllAppeals() {
        List<Appeal> appeals = appealService.getAllAppeals();
        return new ResponseEntity<>(appeals, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Appeal> getAppealById(@PathVariable Long id) {
        Optional<Appeal> appeal = appealService.getAppealById(id);
        return appeal.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Appeal>> getAppealsByUserId(@PathVariable String userId) {
        List<Appeal> appeals = appealService.getAppealsByUserId(userId);
        return new ResponseEntity<>(appeals, HttpStatus.OK);
    }

    @GetMapping("/violation/{violationId}")
    public ResponseEntity<Appeal> getAppealByViolationId(@PathVariable Long violationId) {
        Optional<Appeal> appeal = appealService.getAppealByViolationId(violationId);
        return appeal.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Appeal>> getAppealsByAppealStatus(@PathVariable Appeal.AppealStatus status) {
        List<Appeal> appeals = appealService.getAppealsByAppealStatus(status);
        return new ResponseEntity<>(appeals, HttpStatus.OK);
    }

    @GetMapping("/user/{userId}/status/{status}")
    public ResponseEntity<List<Appeal>> getAppealsByUserIdAndAppealStatus(
            @PathVariable String userId,
            @PathVariable Appeal.AppealStatus status) {
        List<Appeal> appeals = appealService.getAppealsByUserIdAndAppealStatus(userId, status);
        return new ResponseEntity<>(appeals, HttpStatus.OK);
    }

    @GetMapping("/transaction/{transactionHash}")
    public ResponseEntity<Appeal> getAppealByTransactionHash(@PathVariable String transactionHash) {
        Optional<Appeal> appeal = appealService.getAppealByTransactionHash(transactionHash);
        return appeal.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Appeal> createAppeal(@RequestBody Appeal appeal) {
        Appeal createdAppeal = appealService.createAppeal(appeal);
        return new ResponseEntity<>(createdAppeal, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Appeal> updateAppeal(@PathVariable Long id, @RequestBody Appeal appeal) {
        try {
            Appeal updatedAppeal = appealService.updateAppeal(id, appeal);
            return new ResponseEntity<>(updatedAppeal, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAppeal(@PathVariable Long id) {
        appealService.deleteAppeal(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/exists/violation/{violationId}")
    public ResponseEntity<Boolean> existsByViolationId(@PathVariable Long violationId) {
        boolean exists = appealService.existsByViolationId(violationId);
        return new ResponseEntity<>(exists, HttpStatus.OK);
    }
}
