package com.example.studyroom.controller;

import com.example.studyroom.service.DepositService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 押金管理控制器
 */
@RestController
@RequestMapping("/api/deposit")
public class DepositController {

    @Autowired
    private DepositService depositService;

    /**
     * 获取违约金额统计信息
     * @return 违约金额统计数据
     */
    @GetMapping("/violation-amount")
    public Map<String, Object> getViolationAmount() {
        Map<String, Object> result = new HashMap<>();
        
        // 获取合约总余额
        BigDecimal contractBalance = depositService.getContractBalance();
        
        // 获取未违约预约押金总额
        BigDecimal nonViolatedDeposits = depositService.getNonViolatedReservationDeposits();
        
        // 获取签到退还押金总额
        BigDecimal refundedDeposits = depositService.getCheckInRefundedDeposits();
        
        // 计算总违约金额
        BigDecimal totalViolationAmount = depositService.calculateTotalViolationAmount();
        
        // 构建返回结果
        result.put("contractBalance", contractBalance);
        result.put("nonViolatedDeposits", nonViolatedDeposits);
        result.put("refundedDeposits", refundedDeposits);
        result.put("totalViolationAmount", totalViolationAmount);
        
        return result;
    }

    /**
     * 获取合约余额
     * @return 合约余额
     */
    @GetMapping("/contract-balance")
    public Map<String, Object> getContractBalance() {
        Map<String, Object> result = new HashMap<>();
        BigDecimal balance = depositService.getContractBalance();
        result.put("balance", balance);
        return result;
    }
}
