// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract Reservation {
    enum ReservationStatus {
        PENDING,
        CONFIRMED,
        COMPLETED,
        CANCELLED,
        EXPIRED
    }

    struct ReservationRecord {
        string reservationId;
        string userId;
        string seatNumber;
        string areaName;
        uint256 startTime;
        uint256 endTime;
        ReservationStatus status;
        uint256 createdAt;
        uint256 updatedAt;
    }

    mapping(string => ReservationRecord) private reservationRecords;
    string[] private reservationIds;

    event ReservationCreated(
        string indexed reservationId,
        string indexed userId,
        string seatNumber,
        string areaName,
        uint256 startTime,
        uint256 endTime
    );

    event ReservationUpdated(
        string indexed reservationId,
        ReservationStatus status
    );

    event ReservationCancelled(
        string indexed reservationId,
        string userId
    );

    function createReservation(
        string calldata reservationId,
        string calldata userId,
        string calldata seatNumber,
        string calldata areaName,
        uint256 startTime,
        uint256 endTime
    ) external returns (bool) {
        require(reservationRecords[reservationId].createdAt == 0, "Reservation already exists");
        require(startTime < endTime, "Start time must be before end time");

        reservationRecords[reservationId] = ReservationRecord({
            reservationId: reservationId,
            userId: userId,
            seatNumber: seatNumber,
            areaName: areaName,
            startTime: startTime,
            endTime: endTime,
            status: ReservationStatus.CONFIRMED,
            createdAt: block.timestamp,
            updatedAt: block.timestamp
        });

        reservationIds.push(reservationId);

        emit ReservationCreated(
            reservationId,
            userId,
            seatNumber,
            areaName,
            startTime,
            endTime
        );

        return true;
    }

    function updateReservationStatus(
        string calldata reservationId,
        ReservationStatus status
    ) external returns (bool) {
        require(reservationRecords[reservationId].createdAt != 0, "Reservation not found");

        reservationRecords[reservationId].status = status;
        reservationRecords[reservationId].updatedAt = block.timestamp;

        emit ReservationUpdated(reservationId, status);

        return true;
    }

    function cancelReservation(
        string calldata reservationId,
        string calldata userId
    ) external returns (bool) {
        require(reservationRecords[reservationId].createdAt != 0, "Reservation not found");
        require(keccak256(bytes(reservationRecords[reservationId].userId)) == keccak256(bytes(userId)), "Unauthorized");

        reservationRecords[reservationId].status = ReservationStatus.CANCELLED;
        reservationRecords[reservationId].updatedAt = block.timestamp;

        emit ReservationCancelled(reservationId, userId);

        return true;
    }

    function getReservationRecord(
        string calldata reservationId
    ) external view returns (
        string memory,
        string memory,
        string memory,
        string memory,
        uint256,
        uint256,
        ReservationStatus,
        uint256,
        uint256
    ) {
        ReservationRecord storage record = reservationRecords[reservationId];
        require(record.createdAt != 0, "Reservation not found");

        return (
            record.reservationId,
            record.userId,
            record.seatNumber,
            record.areaName,
            record.startTime,
            record.endTime,
            record.status,
            record.createdAt,
            record.updatedAt
        );
    }

    function getAllReservationIds() external view returns (string[] memory) {
        return reservationIds;
    }

    function getReservationCount() external view returns (uint256) {
        return reservationIds.length;
    }
}
