package com.example.studyroom.service.impl;

import com.example.studyroom.model.Reservation;
import com.example.studyroom.model.CheckIn;
import com.example.studyroom.repository.ReservationRepository;
import com.example.studyroom.repository.CheckInRepository;
import com.example.studyroom.service.DepositService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Convert;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * 押金管理服务实现
 */
@Service
public class DepositServiceImpl implements DepositService {

    @Autowired
    private ReservationRepository reservationRepository;
    
    @Autowired
    private CheckInRepository checkInRepository;
    
    @Value("${blockchain.rpc.url:http://localhost:7545}")
    private String rpcUrl;
    
    @Value("${blockchain.contract.depositManager:}")
    private String depositManagerAddress;
    
    @Override
    public BigDecimal getContractBalance() {
        try {
            Web3j web3j = Web3j.build(new HttpService(rpcUrl));
            BigInteger balanceWei = web3j.ethGetBalance(depositManagerAddress, DefaultBlockParameter.valueOf("latest")).send().getBalance();
            return Convert.fromWei(new BigDecimal(balanceWei), Convert.Unit.ETHER);
        } catch (Exception e) {
            System.err.println("获取合约余额失败: " + e.getMessage());
            return BigDecimal.ZERO;
        }
    }
    
    @Override
    public BigDecimal getNonViolatedReservationDeposits() {
        // 获取所有预约
        List<Reservation> allReservations = reservationRepository.findAll();
        
        BigDecimal totalDeposit = BigDecimal.ZERO;
        for (Reservation reservation : allReservations) {
            // 排除违规状态的预约
            if (reservation.getStatus() != Reservation.Status.violated) {
                if (reservation.getDepositAmount() != null && !reservation.getDepositAmount().isEmpty()) {
                    try {
                        totalDeposit = totalDeposit.add(new BigDecimal(reservation.getDepositAmount()));
                    } catch (NumberFormatException e) {
                        System.err.println("押金金额格式错误: " + reservation.getDepositAmount() + ", 错误信息: " + e.getMessage());
                    }
                }
            }
        }
        return totalDeposit;
    }
    
    @Override
    public BigDecimal getCheckInRefundedDeposits() {
        // 获取所有签到记录
        List<CheckIn> checkIns = checkInRepository.findAll();
        
        BigDecimal totalRefund = BigDecimal.ZERO;
        for (CheckIn checkIn : checkIns) {
            // 从签到记录关联的预约中获取押金金额
            if (checkIn.getReservationId() != null) {
                Reservation reservation = reservationRepository.findById(checkIn.getReservationId()).orElse(null);
                if (reservation != null && reservation.getDepositAmount() != null && !reservation.getDepositAmount().isEmpty()) {
                    try {
                        totalRefund = totalRefund.add(new BigDecimal(reservation.getDepositAmount()));
                    } catch (NumberFormatException e) {
                        System.err.println("解析押金金额失败: " + reservation.getDepositAmount());
                    }
                }
            }
        }
        return totalRefund;
    }
    
    @Override
    public BigDecimal calculateTotalViolationAmount() {
        // 获取合约总余额
        BigDecimal contractBalance = getContractBalance();
        
        // 获取未违约预约押金总额
        BigDecimal nonViolatedDeposits = getNonViolatedReservationDeposits();
        
        // 获取签到退还押金总额
        BigDecimal refundedDeposits = getCheckInRefundedDeposits();
        
        // 计算公式：总违约金额 = 合约总金额 - (系统未判定违约的预约押金金额 - 签到退还金额)
        BigDecimal violationAmount = contractBalance.subtract(nonViolatedDeposits.subtract(refundedDeposits));
        
        // 确保结果不为负数
        return violationAmount.max(BigDecimal.ZERO);
    }
}
