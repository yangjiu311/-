// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DepositManager {
    address public admin;
    mapping(address => uint256) public userDeposits;
    
    event DepositReceived(address user, uint256 amount);
    event DepositRefunded(address user, uint256 amount);
    event DepositForfeited(address user, uint256 amount);
    
    constructor() {
        admin = msg.sender;
    }
    
    // 用户存入押金（预约时调用）
    function deposit() external payable {
        require(msg.value == 1 ether, "Deposit must be 1 ETH");
        userDeposits[msg.sender] = msg.value;
        emit DepositReceived(msg.sender, msg.value);
    }
    
    // 退还押金（签到时调用）
    function refund(address user) external onlyAdmin {
        uint256 deposit = userDeposits[user];
        require(deposit > 0, "No deposit to refund");
        
        userDeposits[user] = 0;
        payable(user).transfer(deposit);
        emit DepositRefunded(user, deposit);
    }
    
    // 没收押金（违约时调用）
    function forfeit(address user) external onlyAdmin {
        uint256 deposit = userDeposits[user];
        require(deposit > 0, "No deposit to forfeit");
        
        userDeposits[user] = 0;
        emit DepositForfeited(user, deposit);
    }
    
    // 管理员提取合约余额
    function withdraw() external onlyAdmin {
        uint256 balance = address(this).balance;
        require(balance > 0, "No funds to withdraw");
        
        payable(admin).transfer(balance);
    }
    
    modifier onlyAdmin() {
        require(msg.sender == admin, "Not admin");
        _;
    }
}