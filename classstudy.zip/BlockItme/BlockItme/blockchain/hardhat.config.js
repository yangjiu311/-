import "@nomicfoundation/hardhat-toolbox";

/** @type import('hardhat/config').HardhatUserConfig */
export default {
  solidity: "0.8.24",       
  networks: {
    ganache: {
      url: "http://127.0.0.1:7545",   // Ganache 默认 RPC 地址
      chainId: 1337,                  // Ganache 默认链 ID
     
      accounts: ["0x222115a9d37beae47322023b5804a6b28746cd40415e87dfbfa2b79ba61e51e6"],
    },
  },
};
