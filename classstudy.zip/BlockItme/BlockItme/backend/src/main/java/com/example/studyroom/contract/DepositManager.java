package com.example.studyroom.contract;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Address;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.gas.DefaultGasProvider;

public class DepositManager extends Contract {
    protected DepositManager(String contractBinary, String contractAddress, Web3j web3j, Credentials credentials, DefaultGasProvider gasProvider) {
        super(contractBinary, contractAddress, web3j, credentials, gasProvider);
    }

    public static DepositManager load(String contractAddress, Web3j web3j, Credentials credentials, DefaultGasProvider gasProvider) {
        return new DepositManager(null, contractAddress, web3j, credentials, gasProvider);
    }

    public TransactionReceipt refundEthAfterAppeal(String userAddress) throws Exception {
        final Function function = new Function(
                "refundEthAfterAppeal",
                Arrays.asList(new Address(userAddress)),
                Collections.emptyList()
        );
        
        return executeRemoteCallTransaction(function).send();
    }
}
