package com.example.studyroom.contract;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.DynamicArray;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Uint;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

public class CheckIn extends Contract {
    public static final String BINARY = "";

    public static final String FUNC_CREATCHECKIN = "createCheckIn";

    public static final String FUNC_GETALLCHECKINIDS = "getAllCheckInIds";

    public static final String FUNC_GETCHECKINCOUNT = "getCheckInCount";

    public static final String FUNC_GETCHECKINRECORD = "getCheckInRecord";

    public static final String FUNC_UPDATECHECKOUT = "updateCheckOut";

    public static final Event CHECKINCREATED_EVENT = new Event(
            "CheckInCreated", 
            Arrays.<TypeReference<?>>asList(
                    new TypeReference<Utf8String>(true) {},
                    new TypeReference<Utf8String>(false) {},
                    new TypeReference<Utf8String>(false) {},
                    new TypeReference<Utf8String>(false) {},
                    new TypeReference<Uint>(false) {}
            ));

    public static final Event CHECKOUTUPDATED_EVENT = new Event(
            "CheckOutUpdated", 
            Arrays.<TypeReference<?>>asList(
                    new TypeReference<Utf8String>(true) {},
                    new TypeReference<Uint>(false) {},
                    new TypeReference<Uint>(false) {}
            ));

    protected CheckIn(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    protected CheckIn(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<TransactionReceipt> createCheckIn(String _checkInId, String _userId, String _seatNumber, String _areaName) {
        final Function function = new Function(
                FUNC_CREATCHECKIN,
                Arrays.asList(new Utf8String(_checkInId), new Utf8String(_userId), new Utf8String(_seatNumber), new Utf8String(_areaName)),
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public RemoteCall<java.util.List<String>> getAllCheckInIds() {
        final Function function = new Function(
                FUNC_GETALLCHECKINIDS,
                Collections.<Type>emptyList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<DynamicArray<Utf8String>>() {}));
        return new RemoteCall<>(() -> {
            List<Type> results = executeCallMultipleValueReturn(function);
            List<String> resultList = new ArrayList<>();
            if (!results.isEmpty()) {
                DynamicArray<Utf8String> dynamicArray = (DynamicArray<Utf8String>) results.get(0);
                for (Utf8String value : dynamicArray.getValue()) {
                    resultList.add(value.getValue());
                }
            }
            return resultList;
        });
    }

    public RemoteCall<BigInteger> getCheckInCount() {
        final Function function = new Function(
                FUNC_GETCHECKINCOUNT,
                Collections.<Type>emptyList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteFunctionCall<java.util.List<Type>> getCheckInRecord(String _checkInId) {
        final Function function = new Function(
                FUNC_GETCHECKINRECORD,
                Arrays.asList(new Utf8String(_checkInId)),
                Arrays.<TypeReference<?>>asList(
                        new TypeReference<Utf8String>() {},
                        new TypeReference<Utf8String>() {},
                        new TypeReference<Utf8String>() {},
                        new TypeReference<Utf8String>() {},
                        new TypeReference<Uint>() {},
                        new TypeReference<Uint>() {},
                        new TypeReference<Uint>() {}
                ));
        return executeRemoteCallMultipleValueReturn(function);
    }

    public RemoteCall<TransactionReceipt> updateCheckOut(String _checkInId) {
        final Function function = new Function(
                FUNC_UPDATECHECKOUT,
                Arrays.asList(new Utf8String(_checkInId)),
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public static RemoteCall<CheckIn> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(CheckIn.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    public static CheckIn load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new CheckIn(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static CheckIn load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new CheckIn(contractAddress, web3j, transactionManager, contractGasProvider);
    }
}