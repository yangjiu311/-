<template>
  <div class="admin-container">
    <!-- 侧边栏导航 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="blockchain-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>管理员后台</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/admin" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          仪表盘
        </router-link>
        <router-link to="/admin/seats" class="nav-item active">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="3" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="14" y="12" width="7" height="9" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="3" y="16" width="7" height="5" rx="1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          座位管理
        </router-link>
        <router-link to="/admin/users" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21V19C16 17.9391 15.5786 16.9217 14.8284 16.1716C14.0783 15.4214 13.0609 15 12 15C10.9391 15 9.92172 15.4214 9.17157 16.1716C8.42143 16.9217 8 17.9391 8 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 7C14.2091 7 16 5.20914 16 3C16 0.790861 14.2091 -1.38778e-16 12 -1.38778e-16C9.79086 -1.38778e-16 8 0.790861 8 3C8 5.20914 9.79086 7 12 7Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          用户管理
        </router-link>
        <router-link to="/admin/reservations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <rect x="4" y="4" width="16" height="18" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 10h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>预约记录</span>
        </router-link>
        <router-link to="/admin/checkins" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 11l3 3L22 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>签到记录</span>
        </router-link>
        <router-link to="/admin/violations" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>违约记录</span>
        </router-link>
        <router-link to="/admin/appeals" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>申诉记录</span>
        </router-link>
        <router-link to="/admin/settings" class="nav-item">
          <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>系统设置</span>
        </router-link>
      </nav>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部导航栏 -->
      <header class="top-nav">
        <h1>座位管理</h1>
        <div class="user-info" @click="showDropdown = !showDropdown">
          <span class="username">管理员</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <!-- 用户下拉菜单 -->
          <div class="user-dropdown" v-if="showDropdown">
            <button class="dropdown-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              修改密码
            </button>
            <button class="dropdown-item" @click="logout">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M21 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M15 15L21 12L15 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>

            </button>
          </div>
        </div>
      </header>

      <!-- 座位管理内容区域 -->
      <section class="seats-management">
        <transition name="slide-fade" mode="out-in">
          <div class="management-actions" key="actions">
            <!-- 统计卡片 -->
            <div class="stats-cards">
              <div class="stat-card">
                <div class="stat-icon total">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <div class="stat-label">总座位数</div>
                  <div class="stat-value">{{ totalSeats }}</div>
                </div>
              </div>
              <div class="stat-card">
                <div class="stat-icon available">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22 11.08V12C21.9988 14.1564 21.3005 16.2547 20.0093 17.9818C18.7182 19.709 16.9033 20.9725 14.8354 21.5839C12.7674 22.1953 10.5573 22.1219 8.53447 21.3746C6.51168 20.6273 4.78465 19.2461 3.61096 17.4371C2.43727 15.628 1.87979 13.4881 2.02168 11.3363C2.16356 9.18455 2.99721 7.13631 4.39828 5.49706C5.79935 3.85781 7.69279 2.71537 9.79619 2.24013C11.8996 1.7649 14.1003 1.98232 16.07 2.85999" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M22 4L12 14.01L9 11.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <div class="stat-label">可用座位</div>
                  <div class="stat-value">{{ availableSeats }}</div>
                </div>
              </div>
              <div class="stat-card">
                <div class="stat-icon reserved">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <div class="stat-label">已预约</div>
                  <div class="stat-value">{{ reservedSeats }}</div>
                </div>
              </div>
            </div>
          </div>
        </transition>

        <!-- 功能按钮区域 -->
        <div class="action-buttons">
          <button class="action-btn add-area" @click="showAddAreaModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            添加区域
          </button>
          <button class="action-btn add-row-col" @click="showAddRowColModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            添加行/列
          </button>
          <button class="action-btn add-seat" @click="showAddSeatModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            添加座位
          </button>
          <button class="action-btn delete-area" @click="showDeleteAreaModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            删除区域
          </button>
          <button class="action-btn delete-row-col" @click="showDeleteRowColModal = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            删除行/列
          </button>
        </div>

        <!-- 搜索栏 -->
        <div class="search-bar">
          <select v-model="searchType" class="search-select">
            <option value="seatNumber">座位号</option>
            <option value="area">区域</option>
            <option value="status">状态</option>
          </select>
          <input type="text" v-model="searchKeyword" class="search-input" placeholder="搜索座位...">
          <button class="search-btn" @click="handleSearch">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.65 16.65M16.65 16.65C18.2995 15.0005 19.2596 12.7852 19.25 10.375C19.25 7.96478 18.2995 5.74948 16.65 4.1C14.9995 2.45052 12.7842 1.5 10.375 1.5C7.9658 1.5 5.75049 2.45052 4.1 4.1C2.45052 5.74948 1.5 7.96478 1.5 10.375C1.5 12.7842 2.45052 14.9995 4.1 16.65C5.7494 18.2995 7.96478 19.2596 10.375 19.25C12.7852 19.2596 14.9995 18.2995 16.65 16.65M19 10.375C19.2596 12.7852 18.2995 14.9995 16.65 16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            搜索
          </button>
        </div>

        <!-- 可视化座位表 -->
        <div class="visualization-section">
          <div class="visualization-header">
            <h2>可视化座位表</h2>
            <div class="area-selector">
              <label>选择区域：</label>
              <select v-model="selectedVisualizationArea" class="area-select">
                <option value="">全部区域</option>
                <option v-for="area in areas" :key="area.id" :value="area.classroomName">
                  {{ area.classroomName }}
                </option>
              </select>
            </div>
          </div>
          <SeatVisualization 
            v-if="selectedVisualizationArea"
            :area-name="selectedVisualizationArea" 
            :seats="seats"
          />
          <div v-else class="no-area-selected">
            <p>请选择一个区域以查看可视化座位表</p>
          </div>
        </div>

        <transition name="slide-fade" mode="out-in">
          <!-- 座位列表 -->
          <div class="seats-list" key="list">
            <table class="seats-table">
              <thead>
                <tr>
                  <th><input type="checkbox" class="select-all"></th>
                  <th>座位号</th>
                  <th>区域</th>
                  <th>行</th>
                  <th>列</th>
                  <th>状态</th>
                  <th>描述</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="seat in filteredSeats" :key="seat.id">
                  <td><input type="checkbox" class="select-seat"></td>
                  <td>{{ seat.seatNumber }}</td>
                  <td>{{ seat.classroomName }}</td>
                  <td>{{ seat.row }}</td>
                  <td>{{ seat.column }}</td>
                  <td>
                    <span :class="['status', seat.status]">
                      {{ statusText[seat.status] || seat.status }}
                    </span>
                  </td>
                  <td>{{ seat.description || '-' }}</td>
                  <td>
                    <button class="btn-view" @click="handleViewSeat(seat)">查看</button>
                    <button class="btn-delete" @click="handleDeleteSeat(seat.id)">删除</button>
                  </td>
                </tr>
                <tr v-if="filteredSeats.length === 0">
                  <td colspan="8" style="text-align: center; padding: 40px; color: #999;">
                    暂无座位数据
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </transition>


      </section>

      <!-- 添加区域对话框 -->
      <div v-if="showAddAreaModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>添加区域</h3>
            <button class="close-btn" @click="showAddAreaModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>区域名称 <span class="required">*</span></label>
              <input type="text" v-model="areaForm.name" placeholder="请输入区域名称，如：A区" />
            </div>
            <div class="form-group">
              <label>区域描述</label>
              <input type="text" v-model="areaForm.description" placeholder="请输入区域描述（选填）" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showAddAreaModal = false">取消</button>
            <button class="btn-confirm" @click="handleAddArea">确定</button>
          </div>
        </div>
      </div>

      <!-- 添加行/列对话框 -->
      <div v-if="showAddRowColModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>添加行/列</h3>
            <button class="close-btn" @click="showAddRowColModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>类型 <span class="required">*</span></label>
              <select v-model="rowColForm.type">
                <option value="row">行</option>
                <option value="column">列</option>
              </select>
            </div>
            <div class="form-group">
              <label>{{ rowColForm.type === 'row' ? '行号' : '列号' }} <span class="required">*</span></label>
              <input type="number" v-model="rowColForm.number" :placeholder="rowColForm.type === 'row' ? '请输入行号，如：1' : '请输入列号，如：1'" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showAddRowColModal = false">取消</button>
            <button class="btn-confirm" @click="handleAddRowCol">确定</button>
          </div>
        </div>
      </div>

      <!-- 添加座位对话框 -->
      <div v-if="showAddSeatModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>添加座位</h3>
            <button class="close-btn" @click="showAddSeatModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>选择区域 <span class="required">*</span></label>
              <select v-model="seatForm.areaId">
                <option value="">请选择区域</option>
                <option v-for="area in areas" :key="area.id" :value="area.id">{{ area.classroomName }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>选择行 <span class="required">*</span></label>
              <select v-model="seatForm.rowId">
                <option value="">请选择行</option>
                <option v-for="row in rows" :key="row.id" :value="row.id">行 {{ row.rowNumber }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>选择列 <span class="required">*</span></label>
              <select v-model="seatForm.columnId">
                <option value="">请选择列</option>
                <option v-for="column in columns" :key="column.id" :value="column.id">列 {{ column.columnNumber }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>座位号</label>
              <input type="text" v-model="generatedSeatNumber" placeholder="自动生成" readonly />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showAddSeatModal = false">取消</button>
            <button class="btn-confirm" @click="handleAddSeat">确定</button>
          </div>
        </div>
      </div>

      <!-- 删除区域对话框 -->
      <div v-if="showDeleteAreaModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>删除区域</h3>
            <button class="close-btn" @click="showDeleteAreaModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="warning-message">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span>警告：删除区域将同时删除该区域下的所有座位！</span>
            </div>
            <div class="form-group">
              <label>选择要删除的区域 <span class="required">*</span></label>
              <select v-model="deleteAreaForm.areaId">
                <option value="">请选择区域</option>
                <option v-for="area in areas" :key="area.id" :value="area.id">{{ area.classroomName }}</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showDeleteAreaModal = false">取消</button>
            <button class="btn-delete-confirm" @click="handleDeleteArea">删除</button>
          </div>
        </div>
      </div>

      <!-- 删除行/列对话框 -->
      <div v-if="showDeleteRowColModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>删除行/列</h3>
            <button class="close-btn" @click="showDeleteRowColModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="warning-message">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span>警告：删除行/列将同时删除对应的座位！</span>
            </div>
            <div class="form-group">
              <label>类型 <span class="required">*</span></label>
              <select v-model="deleteRowColForm.type">
                <option value="row">行</option>
                <option value="column">列</option>
              </select>
            </div>
            <div class="form-group">
              <label>选择要删除的{{ deleteRowColForm.type === 'row' ? '行' : '列' }} <span class="required">*</span></label>
              <select v-model="deleteRowColForm.id">
                <option value="">请选择{{ deleteRowColForm.type === 'row' ? '行' : '列' }}</option>
                <option v-if="deleteRowColForm.type === 'row'" v-for="row in rows" :key="row.id" :value="row.id">行 {{ row.rowNumber }}</option>
                <option v-if="deleteRowColForm.type === 'column'" v-for="column in columns" :key="column.id" :value="column.id">列 {{ column.columnNumber }}</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showDeleteRowColModal = false">取消</button>
            <button class="btn-delete-confirm" @click="handleDeleteRowCol">删除</button>
          </div>
        </div>
      </div>

      <!-- 查看座位对话框 -->
      <div v-if="showEditSeatModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>查看座位</h3>
            <button class="close-btn" @click="showEditSeatModal = false">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>座位号</label>
              <input type="text" v-model="editSeatForm.seatNumber" readonly />
            </div>
            <div class="form-group">
              <label>区域名称</label>
              <input type="text" v-model="editSeatForm.classroomName" readonly />
            </div>
            <div class="form-group">
              <label>行号</label>
              <input type="number" v-model="editSeatForm.row" readonly />
            </div>
            <div class="form-group">
              <label>列号</label>
              <input type="number" v-model="editSeatForm.column" readonly />
            </div>
            <div class="form-group">
              <label>状态</label>
              <select v-model="editSeatForm.status" disabled>
                <option value="available">可用</option>
                <option value="reserved">已预约</option>
                <option value="used">使用中</option>
                <option value="maintenance">维护中</option>
              </select>
            </div>
            <div class="form-group">
              <label>描述</label>
              <input type="text" v-model="editSeatForm.description" readonly />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" @click="showEditSeatModal = false">关闭</button>

          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ref, computed, onMounted } from 'vue'
import SeatVisualization from '../components/SeatVisualization.vue'
import {
  getAllAreas,
  getAllRows,
  getAllColumns,
  getAllSeats,
  addArea,
  addRow,
  addColumn,
  deleteArea,
  deleteRow,
  deleteColumn,
  addSeat,
  deleteSeat,
  updateSeat
} from '../services/api'

const router = useRouter()
const userStore = useUserStore()
const showDropdown = ref(false)

// 对话框显示状态
const showAddAreaModal = ref(false)
const showAddRowColModal = ref(false)
const showAddSeatModal = ref(false)
const showDeleteAreaModal = ref(false)
const showDeleteRowColModal = ref(false)
const showEditSeatModal = ref(false)

// 搜索相关
const searchType = ref('seatNumber')
const searchKeyword = ref('')

// 可视化相关
const selectedVisualizationArea = ref('')


// 表单数据
const areaForm = ref({
  name: '',
  description: ''
})

const rowColForm = ref({
  type: 'row', // 'row' 或 'column'
  number: ''
})

const seatForm = ref({
  areaId: '',
  rowId: '',
  columnId: ''
})

const editSeatForm = ref({
  id: null,
  seatNumber: '',
  classroomName: '',
  row: null,
  column: null,
  status: 'available',
  description: ''
})

// 计算属性：根据选择的区域、行、列自动生成座位号
const generatedSeatNumber = computed(() => {
  const selectedArea = areas.value.find(a => a.id === parseInt(seatForm.value.areaId))
  const selectedRow = rows.value.find(r => r.id === parseInt(seatForm.value.rowId))
  const selectedColumn = columns.value.find(c => c.id === parseInt(seatForm.value.columnId))
  
  if (selectedArea && selectedRow && selectedColumn) {
    return `${selectedArea.classroomName}区${selectedRow.rowNumber}行${selectedColumn.columnNumber}列`
  }
  return ''
})

const deleteAreaForm = ref({
  areaId: ''
})

const deleteRowColForm = ref({
  type: 'row', // 'row' 或 'column'
  id: ''
})

// 列表数据
const areas = ref([])
const rows = ref([])
const columns = ref([])
const seats = ref([])

// 计算属性：统计数据
const totalSeats = computed(() => seats.value.length)
const availableSeats = computed(() => seats.value.filter(s => s.status === 'available').length)
const reservedSeats = computed(() => seats.value.filter(s => s.status === 'reserved').length)

// 计算属性：过滤后的座位列表
const filteredSeats = computed(() => {
  let result = [...seats.value]
  
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    switch (searchType.value) {
      case 'seatNumber':
        result = result.filter(s => s.seatNumber.toLowerCase().includes(keyword))
        break
      case 'area':
        result = result.filter(s => s.classroomName.toLowerCase().includes(keyword))
        break
      case 'status':
        result = result.filter(s => s.status.toLowerCase().includes(keyword))
        break
    }
  }
  
  return result
})



// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/login')
}

// 搜索座位
const handleSearch = () => {
  // 搜索处理
}

// 加载数据
const loadData = async () => {
  try {
    areas.value = await getAllAreas()
    rows.value = await getAllRows()
    columns.value = await getAllColumns()
    seats.value = await getAllSeats()
  } catch (error) {
    console.error('加载数据失败:', error)
  }
}

// 添加区域
const handleAddArea = async () => {
  if (!areaForm.value.name) {
    alert('请输入区域名称')
    return
  }
  try {
    await addArea({ classroomName: areaForm.value.name })
    alert('添加区域成功')
    showAddAreaModal.value = false
    areaForm.value = { name: '', description: '' }
    await loadData()
  } catch (error) {
    alert('添加区域失败: ' + (error.response?.data?.message || error.message))
  }
}

// 添加行/列
const handleAddRowCol = async () => {
  if (!rowColForm.value.number) {
    alert('请输入行号或列号')
    return
  }
  try {
    if (rowColForm.value.type === 'row') {
      await addRow({ rowNumber: parseInt(rowColForm.value.number) })
      alert('添加行成功')
    } else {
      await addColumn({ columnNumber: parseInt(rowColForm.value.number) })
      alert('添加列成功')
    }
    showAddRowColModal.value = false
    rowColForm.value = { type: 'row', number: '' }
    await loadData()
  } catch (error) {
    alert('添加失败: ' + (error.response?.data?.message || error.message))
  }
}

// 添加座位
const handleAddSeat = async () => {
  if (!seatForm.value.areaId || !seatForm.value.rowId || !seatForm.value.columnId) {
    alert('请完整填写座位信息')
    return
  }
  
  // 根据ID查找对应的行号和列号
  const selectedRow = rows.value.find(r => r.id === parseInt(seatForm.value.rowId))
  const selectedColumn = columns.value.find(c => c.id === parseInt(seatForm.value.columnId))
  
  if (!selectedRow || !selectedColumn) {
    alert('选择的行或列不存在')
    return
  }
  
  // 根据areaId查找区域名称
  const selectedArea = areas.value.find(a => a.id === parseInt(seatForm.value.areaId))
  
  if (!selectedArea) {
    alert('选择的区域不存在')
    return
  }
  
  // 自动生成座位号
  const seatNumber = `${selectedArea.classroomName}区${selectedRow.rowNumber}行${selectedColumn.columnNumber}列`
  
  try {
    await addSeat({
      classroomName: selectedArea.classroomName,
      row: selectedRow.rowNumber,
      column: selectedColumn.columnNumber,
      seatNumber: seatNumber,
      status: 'available'
    })
    alert('添加座位成功')
    showAddSeatModal.value = false
    seatForm.value = { areaId: '', rowId: '', columnId: '' }
    await loadData()
  } catch (error) {
    alert('添加座位失败: ' + (error.response?.data?.message || error.message))
  }
}

// 删除区域
const handleDeleteArea = async () => {
  if (!deleteAreaForm.value.areaId) {
    alert('请选择要删除的区域')
    return
  }
  if (!confirm('确定要删除该区域吗？删除区域将同时删除该区域下的所有座位！')) {
    return
  }
  try {
    await deleteArea(deleteAreaForm.value.areaId)
    alert('删除区域成功')
    showDeleteAreaModal.value = false
    deleteAreaForm.value = { areaId: '' }
    await loadData()
  } catch (error) {
    alert('删除区域失败: ' + (error.response?.data?.message || error.message))
  }
}

// 删除行/列
const handleDeleteRowCol = async () => {
  if (!deleteRowColForm.value.id) {
    alert('请选择要删除的行或列')
    return
  }
  if (!confirm('确定要删除该行/列吗？删除行/列将同时删除对应的座位！')) {
    return
  }
  try {
    if (deleteRowColForm.value.type === 'row') {
      await deleteRow(deleteRowColForm.value.id)
      alert('删除行成功')
    } else {
      await deleteColumn(deleteRowColForm.value.id)
      alert('删除列成功')
    }
    showDeleteRowColModal.value = false
    deleteRowColForm.value = { type: 'row', id: '' }
    await loadData()
  } catch (error) {
    alert('删除失败: ' + (error.response?.data?.message || error.message))
  }
}

// 查看座位
const handleViewSeat = (seat) => {
  editSeatForm.value = {
    id: seat.id,
    seatNumber: seat.seatNumber,
    classroomName: seat.classroomName,
    row: seat.row,
    column: seat.column,
    status: seat.status,
    description: seat.description || ''
  }
  showEditSeatModal.value = true
}



// 删除座位
const handleDeleteSeat = async (seatId) => {
  if (!confirm('确定要删除该座位吗？')) {
    return
  }
  try {
    await deleteSeat(seatId)
    alert('删除座位成功')
    await loadData()
  } catch (error) {
    alert('删除座位失败: ' + (error.response?.data?.message || error.message))
  }
}



// 状态文本映射
const statusText = {
  available: '可用',
  reserved: '已预约',
  used: '使用中',
  maintenance: '维护中'
}

// 页面加载时获取数据
onMounted(() => {
  loadData()
})
</script>

<style scoped>
.admin-container {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: #f0f2f5;
}

/* 侧边栏样式 */
.sidebar {
  width: 240px;
  background-color: #2c3e50;
  color: white;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #34495e;
}

.blockchain-icon {
  margin-bottom: 10px;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.nav-menu {
  flex: 1;
  padding: 20px 0;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  color: #bdc3c7;
  text-decoration: none;
  transition: all 0.3s ease;
}

.nav-item:hover {
  background-color: #34495e;
  color: white;
}

.nav-item.active {
  background-color: #4CAF50;
  color: white;
}

.nav-icon {
  margin-right: 10px;
}

/* 主内容区域 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 顶部导航栏 */
.top-nav {
  background-color: white;
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.top-nav h1 {
  margin: 0;
  font-size: 24px;
  color: #2c3e50;
}

.user-info {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 8px 16px;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.user-info:hover {
  background-color: #f5f5f5;
}

.username {
  font-weight: 500;
  color: #2c3e50;
}

.user-dropdown {
  position: absolute;
  top: 100%;
  right: 0;
  background-color: white;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  min-width: 150px;
  z-index: 1000;
  margin-top: 5px;
}

.dropdown-item {
  width: 100%;
  padding: 10px 15px;
  border: none;
  background: none;
  text-align: left;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #2c3e50;
  transition: background-color 0.2s;
}

.dropdown-item:hover {
  background-color: #f5f5f5;
}

/* 座位管理内容区域 */
.seats-management {
  flex: 1;
  padding: 20px 30px;
  overflow-y: auto;
}

/* 统计卡片 */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.stat-icon.total {
  background-color: #3498db;
}

.stat-icon.available {
  background-color: #2ecc71;
}

.stat-icon.reserved {
  background-color: #f39c12;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #7f8c8d;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #2c3e50;
}

/* 功能按钮区域 */
.action-buttons {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.action-btn svg {
  color: white;
}

.action-btn.add-area {
  background-color: #3498db;
}

.action-btn.add-area:hover {
  background-color: #2980b9;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.action-btn.add-row-col {
  background-color: #2ecc71;
}

.action-btn.add-row-col:hover {
  background-color: #27ae60;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.action-btn.add-seat {
  background-color: #9b59b6;
}

.action-btn.add-seat:hover {
  background-color: #8e44ad;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.action-btn.delete-area {
  background-color: #e74c3c;
}

.action-btn.delete-area:hover {
  background-color: #c0392b;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.action-btn.delete-row-col {
  background-color: #f39c12;
}

.action-btn.delete-row-col:hover {
  background-color: #e67e22;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

/* 座位列表 */
.seats-list {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.seats-table {
  width: 100%;
  border-collapse: collapse;
}

.seats-table thead {
  background-color: #f8f9fa;
}

.seats-table th {
  padding: 12px;
  text-align: left;
  font-weight: 600;
  color: #2c3e50;
  border-bottom: 2px solid #e9ecef;
}

.seats-table td {
  padding: 12px;
  border-bottom: 1px solid #e9ecef;
  color: #34495e;
}

.seats-table tbody tr:hover {
  background-color: #f8f9fa;
}

.status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.status.available {
  background-color: #d4edda;
  color: #155724;
}

.status.reserved {
  background-color: #fff3cd;
  color: #856404;
}

.btn-view {
  padding: 6px 12px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-right: 5px;
  transition: background-color 0.2s;
}

.btn-view:hover {
  background-color: #2980b9;
}

.btn-delete {
  padding: 6px 12px;
  background-color: #e74c3c;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-delete:hover {
  background-color: #c0392b;
}

/* 搜索栏 */
.search-bar {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  background-color: white;
  border-radius: 8px;
  padding: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.search-select {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-radius: 4px 0 0 4px;
  font-size: 14px;
  background-color: #fff;
  color: #2c3e50;
  min-width: 120px;
  cursor: pointer;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-select:focus {
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-left: none;
  border-right: none;
  font-size: 14px;
  width: 300px;
  color: #2c3e50;
  outline: none;
  transition: border-color 0.3s ease;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.search-input::placeholder {
  color: #bdc3c7;
}

.search-btn {
  padding: 8px 16px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  transition: background-color 0.3s ease;
}

.search-btn:hover {
  background-color: #2980b9;
}



/* 过渡动画 */
.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s ease-in;
}

.slide-fade-enter-from {
  transform: translateX(-20px);
  opacity: 0;
}

.slide-fade-leave-to {
  transform: translateX(20px);
  opacity: 0;
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background-color: white;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e0e0e0;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.close-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #6c757d;
  font-size: 24px;
  line-height: 1;
  transition: color 0.3s ease;
}

.close-btn:hover {
  color: #dc3545;
}

.modal-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group:last-child {
  margin-bottom: 0;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: #2c3e50;
}

.form-group .required {
  color: #e74c3c;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #dfe6e9;
  border-radius: 4px;
  font-size: 14px;
  color: #2c3e50;
  transition: border-color 0.2s;
}

.form-group input:focus,
.form-group select:focus {
  outline: none;
  border-color: #3498db;
}

.form-group input::placeholder {
  color: #bdc3c7;
}

.warning-message {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
  background-color: #fff3cd;
  border: 1px solid #ffc107;
  border-radius: 4px;
  margin-bottom: 20px;
  color: #856404;
  font-size: 14px;
}

.warning-message svg {
  flex-shrink: 0;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 20px;
  border-top: 1px solid #e0e0e0;
}

.btn-cancel,
.btn-confirm,
.btn-delete-confirm {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-cancel {
  background-color: #95a5a6;
  color: white;
}

.btn-cancel:hover {
  background-color: #7f8c8d;
}

.btn-confirm {
  background-color: #3498db;
  color: white;
}

.btn-confirm:hover {
  background-color: #2980b9;
}

.btn-delete-confirm {
  background-color: #e74c3c;
  color: white;
}

.btn-delete-confirm:hover {
  background-color: #c0392b;
}

/* 可视化区域样式 */
.visualization-section {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.visualization-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #e9ecef;
}

.visualization-header h2 {
  margin: 0;
  font-size: 18px;
  color: #2c3e50;
}

.area-selector {
  display: flex;
  align-items: center;
  gap: 10px;
}

.area-selector label {
  font-weight: 500;
  color: #2c3e50;
}

.area-select {
  padding: 8px 12px;
  border: 1px solid #dfe6e9;
  border-radius: 4px;
  font-size: 14px;
  background-color: #fff;
  color: #2c3e50;
  min-width: 150px;
  cursor: pointer;
  outline: none;
  transition: border-color 0.3s ease;
}

.area-select:focus {
  border-color: #3498db;
  box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.no-area-selected {
  text-align: center;
  padding: 60px 20px;
  color: #7f8c8d;
}

.no-area-selected p {
  margin: 0;
  font-size: 16px;
}
</style>





