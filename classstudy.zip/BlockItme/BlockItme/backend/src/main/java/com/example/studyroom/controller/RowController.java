package com.example.studyroom.controller;

import com.example.studyroom.model.Row;
import com.example.studyroom.service.RowService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rows") // 移除/api前缀，因为context-path已经配置了
@AllArgsConstructor
public class RowController {
    private final RowService rowService;

    // 获取所有行
    @GetMapping
    public ResponseEntity<List<Row>> getAllRows() {
        List<Row> rows = rowService.getAllRows();
        return new ResponseEntity<>(rows, HttpStatus.OK);
    }

    // 根据ID获取行
    @GetMapping("/{id}")
    public ResponseEntity<Row> getRowById(@PathVariable Long id) {
        Optional<Row> row = rowService.getRowById(id);
        return row.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // 根据行号获取行
    @GetMapping("/number/{rowNumber}")
    public ResponseEntity<Row> getRowByRowNumber(@PathVariable Integer rowNumber) {
        Optional<Row> row = rowService.getRowByRowNumber(rowNumber);
        return row.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // 添加行
    @PostMapping
    public ResponseEntity<Row> addRow(@RequestBody Row row) {
        // 检查行号是否已存在
        if (rowService.existsByRowNumber(row.getRowNumber())) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        Row savedRow = rowService.saveRow(row);
        return new ResponseEntity<>(savedRow, HttpStatus.CREATED);
    }

    // 更新行
    @PutMapping("/{id}")
    public ResponseEntity<Row> updateRow(@PathVariable Long id, @RequestBody Row row) {
        Optional<Row> existingRow = rowService.getRowById(id);
        if (existingRow.isPresent()) {
            row.setId(id);
            // 如果行号已更改，检查新行号是否已存在
            if (!row.getRowNumber().equals(existingRow.get().getRowNumber()) && 
                rowService.existsByRowNumber(row.getRowNumber())) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }
            Row updatedRow = rowService.saveRow(row);
            return new ResponseEntity<>(updatedRow, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // 删除行
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRow(@PathVariable Long id) {
        Optional<Row> row = rowService.getRowById(id);
        if (row.isPresent()) {
            rowService.deleteRow(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}