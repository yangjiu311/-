package com.example.studyroom.service.impl;

import com.example.studyroom.contract.CheckIn;
import com.example.studyroom.contract.ReservationAbi;
import com.example.studyroom.contract.ViolationAbi;
import com.example.studyroom.contract.AppealAbi;
import com.example.studyroom.contract.DepositManager;
import com.example.studyroom.model.BlockchainLog;
import com.example.studyroom.repository.BlockchainLogRepository;
import com.example.studyroom.service.BlockchainService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import jakarta.annotation.PostConstruct;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.gas.DefaultGasProvider;
import org.web3j.tx.Transfer;
import org.web3j.utils.Convert;

import java.math.BigInteger;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.UUID;

@Service
public class BlockchainServiceImpl implements BlockchainService {
    
    @Autowired
    private BlockchainLogRepository blockchainLogRepository;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    private final Random random = new Random();
    private CheckIn checkInContract;
    private ReservationAbi reservationContract;
    private ViolationAbi violationContract;
    private AppealAbi appealContract;
    private DepositManager depositManagerContract;
    private Web3j web3jRef;
    private Credentials credentialsRef;
    private org.web3j.tx.TransactionManager txManagerRef;
    
    @Value("${blockchain.rpc.url:}")
    private String rpcUrl;
    
    @Value("${blockchain.privateKey:}")
    private String privateKeyProp;
    
    @Value("${blockchain.contract.checkin:}")
    private String checkInAddressProp;
    
    @Value("${blockchain.contract.reservation:}")
    private String reservationAddressProp;
    
    @Value("${blockchain.contract.violation:}")
    private String violationAddressProp;
    
    @Value("${blockchain.contract.appeal:}")
    private String appealAddressProp;
    
    @Value("${blockchain.contract.depositManager:}")
    private String depositManagerAddressProp;
    
    @PostConstruct
    private void init() {
        System.out.println("====================================");
        System.out.println("BlockchainServiceImpl: Starting initialization...");
        checkInContract = null;
        try {
            System.out.println("BlockchainServiceImpl: Step 1: Creating Web3j instance...");
            Web3j web3j = null;
            try {
                String url = (rpcUrl != null && !rpcUrl.isEmpty()) ? rpcUrl : "http://localhost:7545";
                System.out.println("BlockchainServiceImpl: Using RPC URL: " + url);
                web3j = Web3j.build(new HttpService(url));
                System.out.println("BlockchainServiceImpl: Web3j instance created successfully: " + web3j);
                web3jRef = web3j;
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR creating Web3j instance: " + e.getMessage());
                e.printStackTrace();
                return;
            }
            
            // 尝试获取网络状态，验证连接
            System.out.println("BlockchainServiceImpl: Step 2: Testing Hardhat connection...");
            BigInteger chainId = null;
            try {
                chainId = web3j.ethChainId().send().getChainId();
                System.out.println("BlockchainServiceImpl: Connected to Hardhat successfully! ChainId: " + chainId);
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR connecting to Hardhat: " + e.getMessage());
                e.printStackTrace();
                return;
            }
            
            System.out.println("BlockchainServiceImpl: Step 3: Loading credentials...");
            String privateKey = privateKeyProp;
            if (privateKey == null || privateKey.isEmpty()) {
                System.out.println("BlockchainServiceImpl: Private key not configured, skipping contract initialization");
                System.out.println("====================================");
                return;
            }
            Credentials credentials = null;
            try {
                String pk = privateKey.startsWith("0x") ? privateKey.substring(2) : privateKey;
                credentials = Credentials.create(pk);
                System.out.println("BlockchainServiceImpl: Credentials loaded successfully for address: " + credentials.getAddress());
                credentialsRef = credentials;
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading credentials: " + e.getMessage());
                e.printStackTrace();
                return;
            }
            
            System.out.println("BlockchainServiceImpl: Step 4: Loading smart contracts...");
            org.web3j.tx.TransactionManager txManager = null;
            try {
                long chainIdLong = (chainId != null) ? chainId.longValue() : 1337L;
                txManager = new org.web3j.tx.RawTransactionManager(web3j, credentials, chainIdLong);
                System.out.println("BlockchainServiceImpl: Using RawTransactionManager with chainId=" + chainIdLong);
            } catch (Exception ex) {
                System.out.println("BlockchainServiceImpl: Fallback to default credentials-based tx manager due to: " + ex.getMessage());
            }
            
            // Load CheckIn contract
            String checkInAddress = checkInAddressProp;
            if (checkInAddress == null || checkInAddress.isEmpty()) {
                System.out.println("BlockchainServiceImpl: CheckIn contract address not configured");
            }
            System.out.println("BlockchainServiceImpl: Loading CheckIn contract at address: " + checkInAddress);
            try {
                if (checkInAddress != null && !checkInAddress.isEmpty()) {
                    if (txManager != null) {
                        checkInContract = CheckIn.load(checkInAddress, web3j, txManager, new DefaultGasProvider());
                    } else {
                        checkInContract = CheckIn.load(checkInAddress, web3j, credentials, new DefaultGasProvider());
                    }
                    System.out.println("BlockchainServiceImpl: CheckIn contract loaded successfully: " + checkInContract);
                    System.out.println("BlockchainServiceImpl: CheckIn contract initialized: " + (checkInContract != null));
                }
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading CheckIn contract: " + e.getMessage());
                e.printStackTrace();
            }
            
            // Load Reservation contract
            String reservationAddress = reservationAddressProp;
            if (reservationAddress == null || reservationAddress.isEmpty()) {
                System.out.println("BlockchainServiceImpl: Reservation contract address not configured");
            }
            System.out.println("BlockchainServiceImpl: Loading Reservation contract at address: " + reservationAddress);
            try {
                if (reservationAddress != null && !reservationAddress.isEmpty()) {
                    if (txManager != null) {
                        reservationContract = ReservationAbi.load(reservationAddress, web3j, txManager, new DefaultGasProvider());
                    } else {
                        reservationContract = ReservationAbi.load(reservationAddress, web3j, credentials, new DefaultGasProvider());
                    }
                    System.out.println("BlockchainServiceImpl: Reservation contract loaded successfully: " + reservationContract);
                    System.out.println("BlockchainServiceImpl: Reservation contract initialized: " + (reservationContract != null));
                }
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading Reservation contract: " + e.getMessage());
                e.printStackTrace();
            }
            
            String violationAddress = violationAddressProp;
            if (violationAddress == null || violationAddress.isEmpty()) {
                System.out.println("BlockchainServiceImpl: Violation contract address not configured");
            }
            System.out.println("BlockchainServiceImpl: Loading Violation contract at address: " + violationAddress);
            try {
                if (violationAddress != null && !violationAddress.isEmpty()) {
                    // 使用自定义的GasProvider，设置更高的Gas限制
                    org.web3j.tx.gas.StaticGasProvider gasProvider = new org.web3j.tx.gas.StaticGasProvider(
                        java.math.BigInteger.valueOf(20000000000L), // gas price
                        java.math.BigInteger.valueOf(8000000L) // gas limit
                    );
                    
                    if (txManager != null) {
                        violationContract = ViolationAbi.load(violationAddress, web3j, txManager, gasProvider);
                    } else {
                        violationContract = ViolationAbi.load(violationAddress, web3j, credentials, gasProvider);
                    }
                    System.out.println("BlockchainServiceImpl: Violation contract loaded successfully: " + violationContract);
                    System.out.println("BlockchainServiceImpl: Violation contract initialized: " + (violationContract != null));
                }
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading Violation contract: " + e.getMessage());
                e.printStackTrace();
            }
            
            String appealAddress = appealAddressProp;
            if (appealAddress == null || appealAddress.isEmpty()) {
                System.out.println("BlockchainServiceImpl: Appeal contract address not configured");
            }
            System.out.println("BlockchainServiceImpl: Loading Appeal contract at address: " + appealAddress);
            try {
                if (appealAddress != null && !appealAddress.isEmpty()) {
                    appealContract = AppealAbi.load(appealAddress, web3j, credentials, new DefaultGasProvider());
                    System.out.println("BlockchainServiceImpl: Appeal contract loaded successfully: " + appealContract);
                }
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading Appeal contract: " + e.getMessage());
                e.printStackTrace();
            }
            
            // Load DepositManager contract
            String depositManagerAddress = depositManagerAddressProp;
            if (depositManagerAddress == null || depositManagerAddress.isEmpty()) {
                System.out.println("BlockchainServiceImpl: DepositManager contract address not configured");
            }
            System.out.println("BlockchainServiceImpl: Loading DepositManager contract at address: " + depositManagerAddress);
            try {
                if (depositManagerAddress != null && !depositManagerAddress.isEmpty()) {
                    // 使用较低的gas限制避免超过区块限制
                    org.web3j.tx.gas.DefaultGasProvider gasProvider = new org.web3j.tx.gas.DefaultGasProvider() {
                        @Override
                        public java.math.BigInteger getGasLimit(String contractFunc) {
                            return java.math.BigInteger.valueOf(300000);
                        }
                    };
                    depositManagerContract = DepositManager.load(depositManagerAddress, web3j, credentials, gasProvider);
                    System.out.println("BlockchainServiceImpl: DepositManager contract loaded successfully: " + depositManagerContract);
                }
            } catch (Exception e) {
                System.out.println("BlockchainServiceImpl: ERROR loading DepositManager contract: " + e.getMessage());
                e.printStackTrace();
            }
            
            // 保存TransactionManager引用
            txManagerRef = txManager;
        } catch (Exception e) {
            System.out.println("BlockchainServiceImpl: FATAL ERROR during initialization: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("BlockchainServiceImpl: Initialization completed");
            System.out.println("BlockchainServiceImpl: Final checkInContract status: " + (checkInContract != null));
            System.out.println("BlockchainServiceImpl: Final reservationContract status: " + (reservationContract != null));
            System.out.println("BlockchainServiceImpl: Final violationContract status: " + (violationContract != null));
            System.out.println("BlockchainServiceImpl: Final appealContract status: " + (appealContract != null));
            System.out.println("BlockchainServiceImpl: Final depositManagerContract status: " + (depositManagerContract != null));
            System.out.println("====================================");
            try {
                if (web3jRef != null && credentialsRef != null) {
                    org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                            web3jRef,
                            credentialsRef,
                            credentialsRef.getAddress(),
                            BigDecimal.ZERO,
                            Convert.Unit.ETHER
                    ).send();
                    System.out.println("Startup connectivity test tx hash: " + receipt.getTransactionHash());
                }
            } catch (Exception ignore) {
            }
        }
    }
    
    @Override
    public String generateTransactionHash(Object data) {
        try {
            // 将数据转换为JSON字符串
            String jsonData = objectMapper.writeValueAsString(data);
            
            // 使用SHA-256算法生成哈希
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(jsonData.getBytes());
            
            // 转换为十六进制字符串
            BigInteger bigInt = new BigInteger(1, hashBytes);
            String hash = bigInt.toString(16);
            
            // 确保哈希长度为64个字符
            while (hash.length() < 64) {
                hash = "0" + hash;
            }
            
            return "0x" + hash;
        } catch (JsonProcessingException | NoSuchAlgorithmException e) {
            // 如果发生异常，生成一个随机的哈希值
            return "error_" + System.currentTimeMillis() + "_" + random.nextInt(10000);
        }
    }
    
    @Override
    public Long generateBlockHeight() {
        // 在真实环境中，应该从区块链节点获取当前区块高度
        // 这里模拟生成一个合理的区块高度
        return 1000L + random.nextInt(1000);
    }
    
    /**
     * 通过申诉后向用户转账1ETH
     * @param userAddress 用户钱包地址
     * @return 交易哈希
     */
    public String refundEthAfterAppeal(String userAddress) {
        try {
            if (web3jRef == null || credentialsRef == null) {
                System.out.println("Web3j or credentials not initialized");
                return null;
            }
            
            System.out.println("Calling DepositManager contract refundEthAfterAppeal with userAddress: " + userAddress);
            
            // 检查DepositManager合约是否已初始化
            if (depositManagerContract == null) {
                System.out.println("DepositManager contract not initialized");
                return null;
            }
            
            // 调用DepositManager合约的refundEthAfterAppeal函数
            org.web3j.protocol.core.methods.response.TransactionReceipt receipt = depositManagerContract.refundEthAfterAppeal(userAddress);
            String transactionHash = receipt.getTransactionHash();
            System.out.println("refundEthAfterAppeal transaction successful! Hash: " + transactionHash);
            return transactionHash;
        } catch (Exception e) {
            System.out.println("Error calling refundEthAfterAppeal: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public BlockchainLog uploadToBlockchain(Object data, String userId, String stuAdminId, Long targetId, BlockchainLog.OperationType operationType) {
        try {
            System.out.println("Starting blockchain upload...");
            System.out.println("Operation type: " + operationType);
            System.out.println("User ID: " + userId);
            System.out.println("Stu Admin ID: " + stuAdminId);
            System.out.println("Target ID: " + targetId);
            System.out.println("CheckIn contract initialized: " + (checkInContract != null));
            
            if (operationType == BlockchainLog.OperationType.check_in && checkInContract != null) {
                try {
                    String checkInId = null;
                    String seatNumber = "";
                    String areaName = "";
                    if (data instanceof com.example.studyroom.model.CheckIn) {
                        com.example.studyroom.model.CheckIn checkIn = (com.example.studyroom.model.CheckIn) data;
                        seatNumber = checkIn.getSeatNumber() != null ? checkIn.getSeatNumber() : "";
                        areaName = checkIn.getClassroomName() != null ? checkIn.getClassroomName() : "";
                        System.out.println("CheckIn data: seatNumber=" + seatNumber + ", areaName=" + areaName);
                    }
                    if (checkInId == null) checkInId = "checkin_" + System.currentTimeMillis() + "_" + userId;
                    System.out.println("Calling smart contract createCheckIn with: checkInId=" + checkInId + ", userId=" + userId + ", seatNumber=" + seatNumber + ", areaName=" + areaName);
                    
                    org.web3j.protocol.core.methods.response.TransactionReceipt receipt = checkInContract.createCheckIn(checkInId, userId, seatNumber, areaName).send();
                    System.out.println("Transaction sent, waiting for receipt...");
                    
                    String transactionHash = receipt.getTransactionHash();
                    Long blockHeight = null;
                    try {
                        var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                        if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                            blockHeight = opt.get().getBlockNumber().longValue();
                        }
                    } catch (Exception ex) {
                    }
                    if (blockHeight == null && receipt.getBlockNumber() != null) {
                        blockHeight = receipt.getBlockNumber().longValue();
                    }
                    System.out.println("Transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                    
                    String operationData = objectMapper.writeValueAsString(data);
                    BlockchainLog blockchainLog = new BlockchainLog();
                    blockchainLog.setOperationType(operationType);
                    blockchainLog.setUserId(userId);
                    blockchainLog.setStuAdminId(stuAdminId);
                    blockchainLog.setTargetId(targetId);
                    blockchainLog.setTransactionHash(transactionHash);
                    blockchainLog.setBlockHeight(blockHeight);
                    blockchainLog.setOperationData(operationData);
                    blockchainLog.setStatus(BlockchainLog.Status.success);
                    blockchainLog.setCreatedAt(LocalDateTime.now());
                    System.out.println("Saving blockchain log...");
                    return blockchainLogRepository.save(blockchainLog);
                } catch (Exception e) {
                    System.out.println("Smart contract call failed: " + e.getMessage());
                    e.printStackTrace();
                    try {
                        org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                web3jRef,
                                credentialsRef,
                                credentialsRef.getAddress(),
                                BigDecimal.ZERO,
                                Convert.Unit.ETHER
                        ).send();
                        String transactionHash = receipt.getTransactionHash();
                        Long blockHeight = null;
                        try {
                            var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                            if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                blockHeight = opt.get().getBlockNumber().longValue();
                            }
                        } catch (Exception ex) {
                        }
                        if (blockHeight == null && receipt.getBlockNumber() != null) {
                            blockHeight = receipt.getBlockNumber().longValue();
                        }
                        String operationData = objectMapper.writeValueAsString(data);
                        BlockchainLog blockchainLog = new BlockchainLog();
                        blockchainLog.setOperationType(operationType);
                        blockchainLog.setUserId(userId);
                        blockchainLog.setStuAdminId(stuAdminId);
                        blockchainLog.setTargetId(targetId);
                        blockchainLog.setTransactionHash(transactionHash);
                        blockchainLog.setBlockHeight(blockHeight);
                        blockchainLog.setOperationData(operationData);
                        blockchainLog.setStatus(BlockchainLog.Status.success);
                        blockchainLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(blockchainLog);
                    } catch (Exception ignored) {
                    }
                    BlockchainLog errorLog = new BlockchainLog();
                    errorLog.setOperationType(operationType);
                    errorLog.setUserId(userId);
                    errorLog.setStuAdminId(stuAdminId);
                    errorLog.setTargetId(targetId);
                    errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                    errorLog.setBlockHeight(null);
                    errorLog.setOperationData(null);
                    errorLog.setStatus(BlockchainLog.Status.failed);
                    errorLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(errorLog);
                }
            } else if (operationType == BlockchainLog.OperationType.reservation && reservationContract != null) {
                try {
                    String reservationId = null;
                    String seatNumber = "";
                    String areaName = "";
                    long startTime = 0;
                    long endTime = 0;
                    
                    if (data != null) {
                        try {
                            String jsonData = objectMapper.writeValueAsString(data);
                            System.out.println("Reservation data JSON: " + jsonData);
                            
                            // 尝试从JSON中提取字段
                            com.fasterxml.jackson.databind.JsonNode rootNode = objectMapper.readTree(jsonData);
                            if (rootNode.has("seatNumber")) {
                                seatNumber = rootNode.get("seatNumber").asText();
                            }
                            if (rootNode.has("classroomName")) {
                                areaName = rootNode.get("classroomName").asText();
                            } else if (rootNode.has("areaName")) {
                                areaName = rootNode.get("areaName").asText();
                            }
                            if (rootNode.has("startTime")) {
                                startTime = rootNode.get("startTime").asLong();
                            }
                            if (rootNode.has("endTime")) {
                                endTime = rootNode.get("endTime").asLong();
                            }
                            if (rootNode.has("id")) {
                                reservationId = rootNode.get("id").asText();
                            }
                        } catch (Exception e) {
                            System.out.println("Error parsing reservation data: " + e.getMessage());
                        }
                    }
                    
                    // 始终生成唯一的上链reservationId，避免因重复ID导致合约revert
                    String baseId = userId;
                    try {
                        if (reservationId != null && !reservationId.isEmpty()) {
                            baseId = reservationId;
                        }
                    } catch (Exception ignore) {}
                    reservationId = "reservation_" + baseId + "_" + System.currentTimeMillis();
                    if (startTime == 0) startTime = System.currentTimeMillis() / 1000;
                    if (endTime == 0) endTime = startTime + 3600; // 1 hour later
                    
                    System.out.println("Calling smart contract createReservation with:");
                    System.out.println("  reservationId: " + reservationId);
                    System.out.println("  userId: " + userId);
                    System.out.println("  seatNumber: " + seatNumber);
                    System.out.println("  areaName: " + areaName);
                    System.out.println("  startTime: " + startTime);
                    System.out.println("  endTime: " + endTime);
                    
                    org.web3j.protocol.core.methods.response.TransactionReceipt receipt = reservationContract.createReservation(
                        reservationId, userId, seatNumber, areaName, 
                        java.math.BigInteger.valueOf(startTime), 
                        java.math.BigInteger.valueOf(endTime)
                    ).send();
                    System.out.println("Transaction sent, waiting for receipt...");
                    
                    String transactionHash = receipt.getTransactionHash();
                    Long blockHeight = null;
                    try {
                        var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                        if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                            blockHeight = opt.get().getBlockNumber().longValue();
                        }
                    } catch (Exception ex) {
                    }
                    if (blockHeight == null && receipt.getBlockNumber() != null) {
                        blockHeight = receipt.getBlockNumber().longValue();
                    }
                    System.out.println("Transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                    
                    String operationData = objectMapper.writeValueAsString(data);
                    BlockchainLog blockchainLog = new BlockchainLog();
                    blockchainLog.setOperationType(operationType);
                    blockchainLog.setUserId(userId);
                    blockchainLog.setStuAdminId(stuAdminId);
                    blockchainLog.setTargetId(targetId);
                    blockchainLog.setTransactionHash(transactionHash);
                    blockchainLog.setBlockHeight(blockHeight);
                    blockchainLog.setOperationData(operationData);
                    blockchainLog.setStatus(BlockchainLog.Status.success);
                    blockchainLog.setCreatedAt(LocalDateTime.now());
                    System.out.println("Saving reservation blockchain log...");
                    return blockchainLogRepository.save(blockchainLog);
                } catch (Exception e) {
                    System.out.println("Smart contract call failed for reservation: " + e.getMessage());
                    e.printStackTrace();
                    try {
                        org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                web3jRef,
                                credentialsRef,
                                credentialsRef.getAddress(),
                                BigDecimal.ZERO,
                                Convert.Unit.ETHER
                        ).send();
                        String transactionHash = receipt.getTransactionHash();
                        Long blockHeight = null;
                        try {
                            var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                            if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                blockHeight = opt.get().getBlockNumber().longValue();
                            }
                        } catch (Exception ex) {
                        }
                        if (blockHeight == null && receipt.getBlockNumber() != null) {
                            blockHeight = receipt.getBlockNumber().longValue();
                        }
                        String operationData = objectMapper.writeValueAsString(data);
                        BlockchainLog blockchainLog = new BlockchainLog();
                        blockchainLog.setOperationType(operationType);
                        blockchainLog.setUserId(userId);
                        blockchainLog.setStuAdminId(stuAdminId);
                        blockchainLog.setTargetId(targetId);
                        blockchainLog.setTransactionHash(transactionHash);
                        blockchainLog.setBlockHeight(blockHeight);
                        blockchainLog.setOperationData(operationData);
                        blockchainLog.setStatus(BlockchainLog.Status.success);
                        blockchainLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(blockchainLog);
                    } catch (Exception ignored) {
                    }
                    BlockchainLog errorLog = new BlockchainLog();
                    errorLog.setOperationType(operationType);
                    errorLog.setUserId(userId);
                    errorLog.setStuAdminId(stuAdminId);
                    errorLog.setTargetId(targetId);
                    errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                    errorLog.setBlockHeight(null);
                    errorLog.setOperationData(null);
                    errorLog.setStatus(BlockchainLog.Status.failed);
                    errorLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(errorLog);
                }
            } else if (operationType == BlockchainLog.OperationType.violation) {
                try {
                    if (violationContract != null) {
                        String violationId = null;
                        String seatNumber = "";
                        String areaName = "";
                        String violationType = "";
                        
                        if (data != null) {
                            try {
                                String jsonData = objectMapper.writeValueAsString(data);
                                System.out.println("Violation data JSON: " + jsonData);
                                
                                // 尝试从JSON中提取字段
                                com.fasterxml.jackson.databind.JsonNode rootNode = objectMapper.readTree(jsonData);
                                if (rootNode.has("id")) {
                                    violationId = rootNode.get("id").asText();
                                }
                                if (rootNode.has("seatNumber")) {
                                    seatNumber = rootNode.get("seatNumber").asText();
                                }
                                if (rootNode.has("classroomName")) {
                                    areaName = rootNode.get("classroomName").asText();
                                } else if (rootNode.has("areaName")) {
                                    areaName = rootNode.get("areaName").asText();
                                }
                                if (rootNode.has("violationType")) {
                                    violationType = rootNode.get("violationType").asText();
                                }
                            } catch (Exception e) {
                                System.out.println("Error parsing violation data: " + e.getMessage());
                            }
                        }
                        
                        if (violationId == null) violationId = "violation_" + System.currentTimeMillis() + "_" + userId;
                        
                        System.out.println("Calling smart contract createViolation for violation with:");
                        System.out.println("  violationId: " + violationId);
                        System.out.println("  userId: " + userId);
                        System.out.println("  seatNumber: " + seatNumber);
                        System.out.println("  areaName: " + areaName);
                        System.out.println("  violationType: " + violationType);
                        
                        // 直接使用现有的violationContract，它已经在初始化时正确加载
                        try {
                            System.out.println("Calling smart contract createViolation...");
                            // 使用合约的内置方法，它会使用我们在初始化时设置的GasProvider
                            org.web3j.protocol.core.methods.response.TransactionReceipt receipt = violationContract.createViolation(
                                violationId, userId, seatNumber, areaName, violationType
                            );
                            System.out.println("Transaction sent, waiting for receipt...");
                            
                            String transactionHash = receipt.getTransactionHash();
                            Long blockHeight = null;
                            try {
                                var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                                if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                    blockHeight = opt.get().getBlockNumber().longValue();
                                }
                            } catch (Exception ex) {
                                System.out.println("Error getting transaction receipt: " + ex.getMessage());
                            }
                            if (blockHeight == null && receipt.getBlockNumber() != null) {
                                blockHeight = receipt.getBlockNumber().longValue();
                            }
                            System.out.println("Transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                            
                            String operationData = objectMapper.writeValueAsString(data);
                            BlockchainLog blockchainLog = new BlockchainLog();
                            blockchainLog.setOperationType(operationType);
                            blockchainLog.setUserId(userId);
                            blockchainLog.setStuAdminId(stuAdminId);
                            blockchainLog.setTargetId(targetId);
                            blockchainLog.setTransactionHash(transactionHash);
                            blockchainLog.setBlockHeight(blockHeight);
                            blockchainLog.setOperationData(operationData);
                            blockchainLog.setStatus(BlockchainLog.Status.success);
                            blockchainLog.setCreatedAt(LocalDateTime.now());
                            System.out.println("Saving violation blockchain log...");
                            return blockchainLogRepository.save(blockchainLog);
                        } catch (Exception e) {
                            System.out.println("Smart contract createViolation failed: " + e.getMessage());
                            e.printStackTrace();
                            // 尝试发送空交易作为替代，确保交易能在Ganache中显示
                            try {
                                System.out.println("Attempting to send empty transaction as fallback...");
                                org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                        web3jRef,
                                        credentialsRef,
                                        credentialsRef.getAddress(),
                                        java.math.BigDecimal.valueOf(0.000000001), // 发送极小金额
                                        Convert.Unit.ETHER
                                ).send();
                                String transactionHash = receipt.getTransactionHash();
                                Long blockHeight = null;
                                try {
                                    var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                                    if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                        blockHeight = opt.get().getBlockNumber().longValue();
                                    }
                                } catch (Exception ex) {
                                    System.out.println("Error getting transaction receipt: " + ex.getMessage());
                                }
                                if (blockHeight == null && receipt.getBlockNumber() != null) {
                                    blockHeight = receipt.getBlockNumber().longValue();
                                }
                                System.out.println("Fallback transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                                
                                String operationData = objectMapper.writeValueAsString(data);
                                BlockchainLog blockchainLog = new BlockchainLog();
                                blockchainLog.setOperationType(operationType);
                                blockchainLog.setUserId(userId);
                                blockchainLog.setStuAdminId(stuAdminId);
                                blockchainLog.setTargetId(targetId);
                                blockchainLog.setTransactionHash(transactionHash);
                                blockchainLog.setBlockHeight(blockHeight);
                                blockchainLog.setOperationData(operationData);
                                blockchainLog.setStatus(BlockchainLog.Status.success);
                                blockchainLog.setCreatedAt(LocalDateTime.now());
                                return blockchainLogRepository.save(blockchainLog);
                            } catch (Exception ex) {
                                System.out.println("Fallback transfer failed: " + ex.getMessage());
                                // 创建错误日志
                                BlockchainLog errorLog = new BlockchainLog();
                                errorLog.setOperationType(operationType);
                                errorLog.setUserId(userId);
                                errorLog.setStuAdminId(stuAdminId);
                                errorLog.setTargetId(targetId);
                                errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                                errorLog.setBlockHeight(null);
                                errorLog.setOperationData(null);
                                errorLog.setStatus(BlockchainLog.Status.failed);
                                errorLog.setCreatedAt(LocalDateTime.now());
                                return blockchainLogRepository.save(errorLog);
                            }
                        }
                    } else {
                        System.out.println("Violation contract not initialized");
                        // 尝试发送空交易作为替代
                        try {
                            System.out.println("Attempting to send empty transaction as fallback...");
                            org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                    web3jRef,
                                    credentialsRef,
                                    credentialsRef.getAddress(),
                                    java.math.BigDecimal.valueOf(0.000000001), // 发送极小金额
                                    Convert.Unit.ETHER
                            ).send();
                            String transactionHash = receipt.getTransactionHash();
                            Long blockHeight = null;
                            try {
                                var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                                if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                    blockHeight = opt.get().getBlockNumber().longValue();
                                }
                            } catch (Exception ex) {
                                System.out.println("Error getting transaction receipt: " + ex.getMessage());
                            }
                            if (blockHeight == null && receipt.getBlockNumber() != null) {
                                blockHeight = receipt.getBlockNumber().longValue();
                            }
                            System.out.println("Fallback transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                            
                            String operationData = objectMapper.writeValueAsString(data);
                            BlockchainLog blockchainLog = new BlockchainLog();
                            blockchainLog.setOperationType(operationType);
                            blockchainLog.setUserId(userId);
                            blockchainLog.setStuAdminId(stuAdminId);
                            blockchainLog.setTargetId(targetId);
                            blockchainLog.setTransactionHash(transactionHash);
                            blockchainLog.setBlockHeight(blockHeight);
                            blockchainLog.setOperationData(operationData);
                            blockchainLog.setStatus(BlockchainLog.Status.success);
                            blockchainLog.setCreatedAt(LocalDateTime.now());
                            return blockchainLogRepository.save(blockchainLog);
                        } catch (Exception e) {
                            System.out.println("Transfer failed for violation: " + e.getMessage());
                            // 创建错误日志
                            BlockchainLog errorLog = new BlockchainLog();
                            errorLog.setOperationType(operationType);
                            errorLog.setUserId(userId);
                            errorLog.setStuAdminId(stuAdminId);
                            errorLog.setTargetId(targetId);
                            errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                            errorLog.setBlockHeight(null);
                            errorLog.setOperationData(null);
                            errorLog.setStatus(BlockchainLog.Status.failed);
                            errorLog.setCreatedAt(LocalDateTime.now());
                            return blockchainLogRepository.save(errorLog);
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Smart contract call failed for violation: " + e.getMessage());
                    e.printStackTrace();
                    
                    // 尝试发送空交易作为替代
                    try {
                        System.out.println("Attempting to send empty transaction as fallback...");
                        org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                web3jRef,
                                credentialsRef,
                                credentialsRef.getAddress(),
                                java.math.BigDecimal.valueOf(0.000000001), // 发送极小金额
                                Convert.Unit.ETHER
                        ).send();
                        String transactionHash = receipt.getTransactionHash();
                        Long blockHeight = null;
                        try {
                            var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                            if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                blockHeight = opt.get().getBlockNumber().longValue();
                            }
                        } catch (Exception ex) {
                            System.out.println("Error getting transaction receipt: " + ex.getMessage());
                        }
                        if (blockHeight == null && receipt.getBlockNumber() != null) {
                            blockHeight = receipt.getBlockNumber().longValue();
                        }
                        System.out.println("Fallback transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                        
                        String operationData = objectMapper.writeValueAsString(data);
                        BlockchainLog blockchainLog = new BlockchainLog();
                        blockchainLog.setOperationType(operationType);
                        blockchainLog.setUserId(userId);
                        blockchainLog.setStuAdminId(stuAdminId);
                        blockchainLog.setTargetId(targetId);
                        blockchainLog.setTransactionHash(transactionHash);
                        blockchainLog.setBlockHeight(blockHeight);
                        blockchainLog.setOperationData(operationData);
                        blockchainLog.setStatus(BlockchainLog.Status.success);
                        blockchainLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(blockchainLog);
                    } catch (Exception ex) {
                        System.out.println("Fallback transfer failed: " + ex.getMessage());
                        // 创建错误日志
                        BlockchainLog errorLog = new BlockchainLog();
                        errorLog.setOperationType(operationType);
                        errorLog.setUserId(userId);
                        errorLog.setStuAdminId(stuAdminId);
                        errorLog.setTargetId(targetId);
                        errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                        errorLog.setBlockHeight(null);
                        errorLog.setOperationData(null);
                        errorLog.setStatus(BlockchainLog.Status.failed);
                        errorLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(errorLog);
                    }
                }
            } else if (operationType == BlockchainLog.OperationType.appeal && appealContract != null) {
                try {
                    String appealId = null;
                    String violationId = "";
                    String appealContent = "";
                    
                    if (data != null) {
                        try {
                            String jsonData = objectMapper.writeValueAsString(data);
                            System.out.println("Appeal data JSON: " + jsonData);
                            
                            // 尝试从JSON中提取字段
                            com.fasterxml.jackson.databind.JsonNode rootNode = objectMapper.readTree(jsonData);
                            if (rootNode.has("id")) {
                                appealId = rootNode.get("id").asText();
                            }
                            if (rootNode.has("violationId")) {
                                violationId = rootNode.get("violationId").asText();
                            }
                            if (rootNode.has("appealContent")) {
                                appealContent = rootNode.get("appealContent").asText();
                            }
                        } catch (Exception e) {
                            System.out.println("Error parsing appeal data: " + e.getMessage());
                        }
                    }
                    
                    if (appealId == null) appealId = "appeal_" + UUID.randomUUID().toString().replace("-", "");
                    
                    System.out.println("Calling smart contract createAppeal for appeal with:");
                    System.out.println("  appealId: " + appealId);
                    System.out.println("  userId: " + userId);
                    System.out.println("  violationId: " + violationId);
                    System.out.println("  appealContent: " + appealContent);
                    org.web3j.protocol.core.methods.response.TransactionReceipt receipt = appealContract.createAppeal(
                        appealId, userId, violationId, appealContent
                    );
                    System.out.println("Transaction sent, waiting for receipt...");
                    
                    String transactionHash = receipt.getTransactionHash();
                    Long blockHeight = null;
                    try {
                        var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                        if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                            blockHeight = opt.get().getBlockNumber().longValue();
                        }
                    } catch (Exception ex) {
                    }
                    if (blockHeight == null && receipt.getBlockNumber() != null) {
                        blockHeight = receipt.getBlockNumber().longValue();
                    }
                    System.out.println("Transaction successful! Hash: " + transactionHash + ", Block height: " + blockHeight);
                    
                    String operationData = objectMapper.writeValueAsString(data);
                    BlockchainLog blockchainLog = new BlockchainLog();
                    blockchainLog.setOperationType(operationType);
                    blockchainLog.setUserId(userId);
                    blockchainLog.setStuAdminId(stuAdminId);
                    blockchainLog.setTargetId(targetId);
                    blockchainLog.setTransactionHash(transactionHash);
                    blockchainLog.setBlockHeight(blockHeight);
                    blockchainLog.setOperationData(operationData);
                    blockchainLog.setStatus(BlockchainLog.Status.success);
                    blockchainLog.setCreatedAt(LocalDateTime.now());
                    System.out.println("Saving appeal blockchain log...");
                    return blockchainLogRepository.save(blockchainLog);
                } catch (Exception e) {
                    System.out.println("Smart contract call failed for appeal: " + e.getMessage());
                    e.printStackTrace();
                    try {
                        org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                web3jRef,
                                credentialsRef,
                                credentialsRef.getAddress(),
                                BigDecimal.ZERO,
                                Convert.Unit.ETHER
                        ).send();
                        String transactionHash = receipt.getTransactionHash();
                        Long blockHeight = null;
                        try {
                            var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                            if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                blockHeight = opt.get().getBlockNumber().longValue();
                            }
                        } catch (Exception ex) {
                        }
                        if (blockHeight == null && receipt.getBlockNumber() != null) {
                            blockHeight = receipt.getBlockNumber().longValue();
                        }
                        String operationData = objectMapper.writeValueAsString(data);
                        BlockchainLog blockchainLog = new BlockchainLog();
                        blockchainLog.setOperationType(operationType);
                        blockchainLog.setUserId(userId);
                        blockchainLog.setStuAdminId(stuAdminId);
                        blockchainLog.setTargetId(targetId);
                        blockchainLog.setTransactionHash(transactionHash);
                        blockchainLog.setBlockHeight(blockHeight);
                        blockchainLog.setOperationData(operationData);
                        blockchainLog.setStatus(BlockchainLog.Status.success);
                        blockchainLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(blockchainLog);
                    } catch (Exception ignored) {
                    }
                    BlockchainLog errorLog = new BlockchainLog();
                    errorLog.setOperationType(operationType);
                    errorLog.setUserId(userId);
                    errorLog.setStuAdminId(stuAdminId);
                    errorLog.setTargetId(targetId);
                    errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                    errorLog.setBlockHeight(null);
                    errorLog.setOperationData(null);
                    errorLog.setStatus(BlockchainLog.Status.failed);
                    errorLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(errorLog);
                }
            } else if (operationType == BlockchainLog.OperationType.admin_operation && web3jRef != null && credentialsRef != null) {
                try {
                    org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                            web3jRef,
                            credentialsRef,
                            credentialsRef.getAddress(),
                            BigDecimal.ZERO,
                            Convert.Unit.ETHER
                    ).send();
                    String transactionHash = receipt.getTransactionHash();
                    Long blockHeight = null;
                    try {
                        var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                        if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                            blockHeight = opt.get().getBlockNumber().longValue();
                        }
                    } catch (Exception ex) {
                    }
                    if (blockHeight == null && receipt.getBlockNumber() != null) {
                        blockHeight = receipt.getBlockNumber().longValue();
                    }
                    String operationData = objectMapper.writeValueAsString(data);
                    BlockchainLog blockchainLog = new BlockchainLog();
                    blockchainLog.setOperationType(operationType);
                    blockchainLog.setUserId(userId);
                    blockchainLog.setStuAdminId(stuAdminId);
                    blockchainLog.setTargetId(targetId);
                    blockchainLog.setTransactionHash(transactionHash);
                    blockchainLog.setBlockHeight(blockHeight);
                    blockchainLog.setOperationData(operationData);
                    blockchainLog.setStatus(BlockchainLog.Status.success);
                    blockchainLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(blockchainLog);
                } catch (Exception e) {
                    BlockchainLog errorLog = new BlockchainLog();
                    errorLog.setOperationType(operationType);
                    errorLog.setUserId(userId);
                    errorLog.setStuAdminId(stuAdminId);
                    errorLog.setTargetId(targetId);
                    errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                    errorLog.setBlockHeight(null);
                    errorLog.setOperationData(null);
                    errorLog.setStatus(BlockchainLog.Status.failed);
                    errorLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(errorLog);
                }
            } else {
                try {
                    if (web3jRef != null && credentialsRef != null) {
                        org.web3j.protocol.core.methods.response.TransactionReceipt receipt = Transfer.sendFunds(
                                web3jRef,
                                credentialsRef,
                                credentialsRef.getAddress(),
                                BigDecimal.ZERO,
                                Convert.Unit.ETHER
                        ).send();
                        String transactionHash = receipt.getTransactionHash();
                        Long blockHeight = null;
                        try {
                            var opt = web3jRef.ethGetTransactionReceipt(transactionHash).send().getTransactionReceipt();
                            if (opt != null && opt.isPresent() && opt.get().getBlockNumber() != null) {
                                blockHeight = opt.get().getBlockNumber().longValue();
                            }
                        } catch (Exception ex) {
                        }
                        if (blockHeight == null && receipt.getBlockNumber() != null) {
                            blockHeight = receipt.getBlockNumber().longValue();
                        }
                        String operationData = objectMapper.writeValueAsString(data);
                        BlockchainLog blockchainLog = new BlockchainLog();
                        blockchainLog.setOperationType(operationType);
                        blockchainLog.setUserId(userId);
                        blockchainLog.setStuAdminId(stuAdminId);
                        blockchainLog.setTargetId(targetId);
                        blockchainLog.setTransactionHash(transactionHash);
                        blockchainLog.setBlockHeight(blockHeight);
                        blockchainLog.setOperationData(operationData);
                        blockchainLog.setStatus(BlockchainLog.Status.success);
                        blockchainLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(blockchainLog);
                    } else {
                        // Blockchain not initialized, create local error log
                        BlockchainLog errorLog = new BlockchainLog();
                        errorLog.setOperationType(operationType);
                        errorLog.setUserId(userId);
                        errorLog.setStuAdminId(stuAdminId);
                        errorLog.setTargetId(targetId);
                        errorLog.setTransactionHash("local_error_" + System.currentTimeMillis());
                        errorLog.setBlockHeight(null);
                        errorLog.setOperationData(null);
                        errorLog.setStatus(BlockchainLog.Status.failed);
                        errorLog.setCreatedAt(LocalDateTime.now());
                        return blockchainLogRepository.save(errorLog);
                    }
                } catch (Exception e) {
                    BlockchainLog errorLog = new BlockchainLog();
                    errorLog.setOperationType(operationType);
                    errorLog.setUserId(userId);
                    errorLog.setStuAdminId(stuAdminId);
                    errorLog.setTargetId(targetId);
                    errorLog.setTransactionHash("error_" + System.currentTimeMillis());
                    errorLog.setBlockHeight(null);
                    errorLog.setOperationData(null);
                    errorLog.setStatus(BlockchainLog.Status.failed);
                    errorLog.setCreatedAt(LocalDateTime.now());
                    return blockchainLogRepository.save(errorLog);
                }
            }
        } catch (Exception e) {
            System.out.println("Error during blockchain upload: " + e.getMessage());
            e.printStackTrace();
            BlockchainLog errorLog = new BlockchainLog();
            errorLog.setOperationType(operationType);
            errorLog.setUserId(userId);
            errorLog.setStuAdminId(stuAdminId);
            errorLog.setTargetId(targetId);
            errorLog.setTransactionHash("error_" + System.currentTimeMillis());
            errorLog.setBlockHeight(null);
            errorLog.setOperationData(null);
            errorLog.setStatus(BlockchainLog.Status.failed);
            errorLog.setCreatedAt(LocalDateTime.now());
            System.out.println("Saving error blockchain log...");
            return blockchainLogRepository.save(errorLog);
        }
    }
}
