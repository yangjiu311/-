<template>
  <div class="seat-visualization">
    <div class="visualization-header">
      <h3>{{ areaName }} - 可视化座位表</h3>
      <div class="status-legend">
        <div class="legend-item">
          <div class="legend-color available"></div>
          <span>可用</span>
        </div>
        <div class="legend-item">
          <div class="legend-color reserved"></div>
          <span>已预约</span>
        </div>
        <div class="legend-item">
          <div class="legend-color used"></div>
          <span>已占用</span>
        </div>
        <div class="legend-item">
          <div class="legend-color maintenance"></div>
          <span>维护中</span>
        </div>
      </div>
    </div>
    
    <div class="seat-grid-container">
      <div class="seat-grid">
        <!-- 列标题 -->
        <div class="grid-header">
          <div class="header-cell empty"></div>
          <div 
            v-for="col in maxColumn" 
            :key="'col-' + col" 
            class="header-cell column-header"
          >
            {{ col }}
          </div>
        </div>
        
        <!-- 座位网格 -->
        <div 
          v-for="row in maxRow" 
          :key="'row-' + row" 
          class="grid-row"
        >
          <!-- 行标题 -->
          <div class="row-header">
            {{ String.fromCharCode(64 + row) }}
          </div>
          
          <!-- 座位 -->
          <div 
            v-for="col in maxColumn" 
            :key="'seat-' + row + '-' + col" 
            class="seat-cell"
          >
            <div 
              v-if="getSeatByPosition(row, col)" 
              :class="['seat', getSeatByPosition(row, col).status]"
              :title="getSeatTooltip(getSeatByPosition(row, col))"
              @click="handleSeatClick(getSeatByPosition(row, col))"
            >
              <span class="seat-number">{{ getSeatByPosition(row, col).seatNumber }}</span>
            </div>
            <div v-else class="seat empty-seat"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SeatVisualization',
  props: {
    areaName: {
      type: String,
      required: true
    },
    seats: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      maxRow: 0,
      maxColumn: 0
    };
  },
  computed: {
    // 按区域过滤座位
    areaSeats() {
      return this.seats.filter(seat => seat.classroomName === this.areaName);
    }
  },
  watch: {
    areaSeats: {
      handler() {
        this.updateGridSize();
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    // 更新网格大小
    updateGridSize() {
      if (this.areaSeats.length === 0) {
        this.maxRow = 0;
        this.maxColumn = 0;
        return;
      }
      
      this.maxRow = Math.max(...this.areaSeats.map(seat => seat.row));
      this.maxColumn = Math.max(...this.areaSeats.map(seat => seat.column));
    },
    
    // 根据行号和列号获取座位
    getSeatByPosition(row, column) {
      return this.areaSeats.find(seat => seat.row === row && seat.column === column);
    },
    
    // 获取座位提示信息
    getSeatTooltip(seat) {
      const statusMap = {
        available: '可用',
        reserved: '已预约',
        used: '已占用',
        maintenance: '维护中'
      };
      return `${seat.seatNumber} - ${statusMap[seat.status] || seat.status}`;
    },
    
    // 处理座位点击事件
    handleSeatClick(seat) {
      this.$emit('seat-click', seat);
    }
  }
};
</script>

<style scoped>
.seat-visualization {
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin: 20px 0;
}

.visualization-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #e0e0e0;
}

.visualization-header h3 {
  margin: 0;
  color: #333;
  font-size: 18px;
}

.status-legend {
  display: flex;
  gap: 20px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  color: #666;
}

.legend-color {
  width: 16px;
  height: 16px;
  border-radius: 2px;
}

.legend-color.available {
  background-color: #4CAF50;
}

.legend-color.reserved {
  background-color: #FF9800;
}

.legend-color.used {
  background-color: #F44336;
}

.legend-color.maintenance {
  background-color: #9E9E9E;
}

.seat-grid-container {
  overflow-x: auto;
  padding: 10px 0;
}

.seat-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.grid-header {
  display: flex;
  gap: 10px;
  margin-bottom: 5px;
}

.header-cell {
  min-width: 60px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 14px;
  color: #666;
}

.header-cell.empty {
  width: 40px;
  min-width: 40px;
}

.grid-row {
  display: flex;
  gap: 10px;
  align-items: center;
}

.row-header {
  width: 40px;
  min-width: 40px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 14px;
  color: #666;
  background-color: #f5f5f5;
  border-radius: 4px;
}

.seat-cell {
  width: 60px;
  min-width: 60px;
}

.seat {
  width: 100%;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
}

.seat:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.seat.available {
  background-color: #4CAF50;
  color: white;
}

.seat.reserved {
  background-color: #FF9800;
  color: white;
}

.seat.used {
  background-color: #F44336;
  color: white;
}

.seat.maintenance {
  background-color: #9E9E9E;
  color: white;
}

.seat.empty-seat {
  background-color: #f5f5f5;
  cursor: default;
  pointer-events: none;
}

.seat.available:hover {
  background-color: #45a049;
}

.seat.reserved:hover {
  background-color: #f57c00;
}

.seat.used:hover {
  background-color: #d32f2f;
}

.seat.maintenance:hover {
  background-color: #757575;
}

.seat-number {
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  line-height: 1.2;
}
</style>