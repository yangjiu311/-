package com.example.studyroom.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "seat")
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "seat_number", unique = true, nullable = false, length = 20)
    private String seatNumber;

    @Column(name = "classroom_name", nullable = false, length = 50)
    private String classroomName;

    @Column(name = "classroom_id", nullable = true)
    private Long classroomId;

    @Column(name = "`row`")
    private Integer row;

    @Column(name = "`column`")
    private Integer column;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(length = 200)
    private String description;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum Status {
        available, reserved, used, maintenance
    }
}